package com.example.tvmapp.slice;

import com.example.tvmapp.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.global.resource.Resource;
import ohos.media.image.common.Size;
import org.apache.tvm.Function;
import org.apache.tvm.Module;
import org.apache.tvm.NDArray;
import org.apache.tvm.Device;
import org.apache.tvm.TVMValue;
import org.apache.tvm.TVMType;
import com.example.tvmapp.slice.LogUtil;
import ohos.global.resource.RawFileEntry;

import ohos.media.image.*;

import java.io.*;
//import java.nio.IntBuffer;
import java.lang.reflect.Array;
import java.nio.*;
import java.util.Arrays;


public class MainAbilitySlice extends AbilitySlice {
    private static final String TAG = MainAbilitySlice.class.getName();
    private static final String FILE_PATH = "entry/resources/rawfile/JaiHanuman";
    private static final String FILE_NAME = "Jai Hanuman!!!";

    private static final String MODEL_GRAPH_FILE_PATH    = "entry/resources/rawfile/graph.json";
    private static final String MODEL_GRAPH_FILE_NAME    = "graph.json";

    private static final String MODEL_CPU_LIB_FILE_PATH    = "entry/resources/rawfile/deploy_lib.so";
    private static final String MODEL_CPU_LIB_FILE_NAME    = "deploy_lib.so";

    private static final String MODEL_PARAMS_FILE_PATH    = "entry/resources/rawfile/params.bin";
    private static final String MODEL_PARAMS_FILE_NAME    = "params.bin";

    private static final String MODEL_INPUT_IMAGE_PATH    = "entry/resources/rawfile/sign.jpg";
    private static final String MODEL_INPUT_IMAGE_NAME    = "sign.jpg";

    //private static final String MODEL_OUTPUT_IMAGE_PATH    = "entry/resources/base/media/out.jpg";
    private static final String MODEL_OUTPUT_IMAGE_PATH    = "/sdcard/Download/out.jpg";
    private static final String MODEL_OUTPUT_IMAGE_NAME    = "out.jpg";

    // TVM constants
    private static final int OUTPUT_INDEX           = 0;
    private static final int IMG_CHANNEL            = 3;
    private static final String INPUT_NAME          = "input_1";
    private static final int MODEL_INPUT_SIZE       = 224;

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);
        //Function runtimeCreFun = Function.getFunction("tvm.graph_executor.create");
        //LogUtil.info(TAG, runtimeCreFun.toString());
        //NDArray inputNdArray = NDArray.empty(new long[]{1, 3, 3, 3}, new TVMType("float32"));
        //LogUtil.info(TAG, String.valueOf(inputNdArray.size()));

        RawFileEntry rawFileEntry = getResourceManager().getRawFileEntry(FILE_PATH);
        try {
            File file = getFileFromRawFile(FILE_NAME, rawFileEntry, getCacheDir());
        } catch (IOException e) {
            LogUtil.error(TAG, e.getMessage());
        } catch (IllegalStateException e) {
            LogUtil.error(TAG, e.getMessage());
        }

        // load json graph
        String modelGraph = null;
        //String graphFilename = MODEL_GRAPH_FILE_PATH.split("file:///android_asset/")[1];
        LogUtil.info(TAG, "Reading json graph from: " + MODEL_GRAPH_FILE_PATH);
        RawFileEntry rawFileEntryModel = getResourceManager().getRawFileEntry(MODEL_GRAPH_FILE_PATH);
        try {
            modelGraph = new String(getBytesFromRawFile(rawFileEntryModel));
            //LogUtil.info(TAG, "Jai Hanuman!!! Json graph: " + modelGraph);
        } catch (IOException e) {
            LogUtil.error(TAG, "Problem reading json graph file!" + e);
            return;//failure
        }

        // create java tvm device
        Device tvmDev = Device.cpu();

        RawFileEntry rawFileEntryModelLib = getResourceManager().getRawFileEntry(MODEL_CPU_LIB_FILE_PATH);
        File file = null;
        try {
            file = getFileFromRawFile(MODEL_CPU_LIB_FILE_NAME, rawFileEntryModelLib, getCacheDir());
        } catch (IOException e) {
            LogUtil.error(TAG, e.getMessage());
        } catch (IllegalStateException e) {
            LogUtil.error(TAG, e.getMessage());
        }

        // tvm module for compiled functions
        LogUtil.info(TAG, "Jai Hanuman!!! Model File Path: " + file.getAbsolutePath());
        Module modelLib = Module.load(file.getAbsolutePath());
        //Module modelLib = Module.load(MODEL_CPU_LIB_FILE_PATH);

        // get global function module for graph executor
        Function runtimeCreFun = Function.getFunction("tvm.graph_executor.create");
        TVMValue runtimeCreFunRes = runtimeCreFun.pushArg(modelGraph)
                .pushArg(modelLib)
                .pushArg(tvmDev.deviceType)
                .pushArg(tvmDev.deviceId)
                .invoke();
        LogUtil.info(TAG, runtimeCreFun.toString());
        Module graphExecutorModule = runtimeCreFunRes.asModule();
        LogUtil.info(TAG, String.valueOf(graphExecutorModule.handle));

        // load parameters
        byte[] modelParams = null;
        LogUtil.info(TAG, "Reading model params from: " + MODEL_PARAMS_FILE_PATH);
        RawFileEntry rawFileEntryModelParams = getResourceManager().getRawFileEntry(MODEL_PARAMS_FILE_PATH);
        try {
            modelParams = getBytesFromRawFile(rawFileEntryModelParams);
            //LogUtil.info(TAG, "Jai Hanuman!!! Json graph: " + modelGraph);
        } catch (IOException e) {
            LogUtil.error(TAG, "Problem reading model param file!" + e);
            return;//failure
        }

        // get the function from the module(load parameters)
        Function loadParamFunc = graphExecutorModule.getFunction("load_params");
        loadParamFunc.pushArg(modelParams).invoke();

        RawFileEntry rawFileEntryImage = getResourceManager().getRawFileEntry(MODEL_INPUT_IMAGE_PATH);
        File fileImage = null;
        try {
            fileImage = getFileFromRawFile(MODEL_INPUT_IMAGE_NAME, rawFileEntryImage, getCacheDir());
        } catch (IOException e) {
            LogUtil.error(TAG, e.getMessage());
        } catch (IllegalStateException e) {
            LogUtil.error(TAG, e.getMessage());
        }

        // tvm module for compiled functions
        LogUtil.info(TAG, "Jai Hanuman!!! Input Image File Path: " + fileImage.getAbsolutePath());

        ImageSource imageSource = ImageSource.create(fileImage, null);
        ImageSource.DecodingOptions decodingOpts = new ImageSource.DecodingOptions();
        decodingOpts.desiredSize = new Size(224, 224);
        //decodingOpts.desiredRegion = new Rect(0, 0, 100, 100);
        //decodingOpts.rotateDegrees = 90;
        PixelMap pixelMap = imageSource.createPixelmap(decodingOpts);
        //PixelMap pixelMapNoOptions = imageSource.createPixelmap(null);
        //LogUtil.info(TAG, "Pixel Data: " + pixelMapNoOptions.getImageInfo().size.toString());
        LogUtil.info(TAG, "Pixel Data: " + pixelMap.getImageInfo().size.toString());

        IntBuffer imageBuffer = IntBuffer.allocate(pixelMap.getImageInfo().size.height * pixelMap.getImageInfo().size.width);
        pixelMap.readPixels(imageBuffer);
        LogUtil.info(TAG, "Image Buffer Data: " + imageBuffer.capacity());

        // image RGB float values
        float[] imgRgbValues = new float[MODEL_INPUT_SIZE * MODEL_INPUT_SIZE * IMG_CHANNEL];
        // image RGB transpose float values
        float[] imgRgbTranValues = new float[MODEL_INPUT_SIZE * MODEL_INPUT_SIZE * IMG_CHANNEL];

        // image pixel int values
        int[] pixelValues = imageBuffer.array();

        // pre-process the image data from 0-255 int to normalized float based on the
        // provided parameters.
        //cropImageBitmap.getPixels(pixelValues, 0, MODEL_INPUT_SIZE, 0, 0, MODEL_INPUT_SIZE, MODEL_INPUT_SIZE);
        for (int j = 0; j < pixelValues.length; ++j) {
            imgRgbValues[j * 3 + 0] = ((pixelValues[j] >> 16) & 0xFF)/255.0f;
            imgRgbValues[j * 3 + 1] = ((pixelValues[j] >> 8) & 0xFF)/255.0f;
            imgRgbValues[j * 3 + 2] = (pixelValues[j] & 0xFF)/255.0f;
        }

        // pre-process the image rgb data transpose based on the provided parameters.
        for (int k = 0; k < IMG_CHANNEL; ++k) {
            for (int l = 0; l < MODEL_INPUT_SIZE; ++l) {
                for (int m = 0; m < MODEL_INPUT_SIZE; ++m) {
                    int dst_index = m + MODEL_INPUT_SIZE*l + MODEL_INPUT_SIZE*MODEL_INPUT_SIZE*k;
                    int src_index = k + IMG_CHANNEL*m + IMG_CHANNEL*MODEL_INPUT_SIZE*l;
                    imgRgbTranValues[dst_index] = imgRgbValues[src_index];
                }
            }
        }

        // get the function from the module(set input data)
        LogUtil.info(TAG, "set input data");
        NDArray inputNdArray = NDArray.empty(new long[]{1, IMG_CHANNEL, MODEL_INPUT_SIZE, MODEL_INPUT_SIZE}, new TVMType("float32"));;
        inputNdArray.copyFrom(imgRgbTranValues);
        Function setInputFunc = graphExecutorModule.getFunction("set_input");
        setInputFunc.pushArg(INPUT_NAME).pushArg(inputNdArray).invoke();
        // release tvm local variables
        inputNdArray.release();
        setInputFunc.release();

        // get the function from the module(run it)
        LogUtil.info(TAG, "run function on target");
        Function runFunc = graphExecutorModule.getFunction("run");
        runFunc.invoke();
        // release tvm local variables
        runFunc.release();

        // get the function from the module(get output data)
        LogUtil.info(TAG, "get output data");
        NDArray outputNdArray = NDArray.empty(new long[]{1, 5, 7, 7}, new TVMType("float32"));
        Function getOutputFunc = graphExecutorModule.getFunction("get_output");
        getOutputFunc.pushArg(OUTPUT_INDEX).pushArg(outputNdArray).invoke();
        float[] output = outputNdArray.asFloatArray();
        // release tvm local variables
        outputNdArray.release();
        getOutputFunc.release();

        // display the result from extracted output data
        if (null != output) {
            LogUtil.info(TAG, "Output length: " + output.length + " , OutputNdArray: " + Arrays.toString(outputNdArray.shape()));
            LogUtil.info(TAG, "Output: " + Arrays.toString(output));
            int maxPosition = -1;
            float maxValue = 0;
            for (int j = 0; j < output.length; ++j) {
                if (output[j] > maxValue) {
                    maxValue = output[j];
                    maxPosition = j;
                }
            }
        }

        LogUtil.info(TAG, "prediction finished");

        /*ImagePacker imagePacker = ImagePacker.create();
        FileOutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(MODEL_OUTPUT_IMAGE_PATH);
        } catch (FileNotFoundException e) {
            LogUtil.error(TAG, e.getMessage());
        }
        ImagePacker.PackingOptions packingOptions = new ImagePacker.PackingOptions();
        packingOptions.format = "image/jpeg";
        packingOptions.quality = 90;
        boolean result = imagePacker.initializePacking(outputStream, packingOptions);
        result = imagePacker.addImage(pixelMap);
        long dataSize = imagePacker.finalizePacking();*/
    }

    private final String getTempLibFilePath(String fileName) throws IOException {
        File tempDir = File.createTempFile("tvm4j_demo_", "");
        if (!tempDir.delete() || !tempDir.mkdir()) {
            throw new IOException("Couldn't create directory " + tempDir.getAbsolutePath());
        }
        return (tempDir + File.separator + fileName);
    }

    private static File getFileFromRawFile(String filename, RawFileEntry rawFileEntry, File cacheDir)
        throws IOException {
        byte[] buf = null;
        File file;
        FileOutputStream output = null;

        try {
            file = new File(cacheDir, filename);
            output = new FileOutputStream(file);
            Resource resource = rawFileEntry.openRawFile();
            buf = new byte[(int) rawFileEntry.openRawFileDescriptor().getFileSize()];
            int bytesRead = resource.read(buf);
            if (bytesRead != buf.length) {
                throw new IOException("Jai Hanuman!!! Asset Read failed!!!");
            }

            //output = new FileOutputStream(file);
            output.write(buf, 0, bytesRead);

            return file;
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        } finally {
            output.close();
        }
    }

    private static byte[] getBytesFromRawFile(RawFileEntry rawFileEntry)
            throws IOException {
        byte[] buf = null;

        try {
            Resource resource = rawFileEntry.openRawFile();
            buf = new byte[(int) rawFileEntry.openRawFileDescriptor().getFileSize()];
            int bytesRead = resource.read(buf);
            if (bytesRead != buf.length) {
                throw new IOException("Jai Hanuman!!! Asset Read failed!!!");
            }
            return buf;
        } catch (IOException ex) {
            throw new IllegalStateException(ex);
        } finally {
        }
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
