# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=invalid-name, unused-argument
"""tinykernel library supported operators.
There are two ways to registering a function for an op to indicate if it is
supported by tinykernel.

- The first and simplest way is to use the helper so that
users only need to provide the operator name and a boolean value to indicate if
it is supported. For example:

    .. code-block:: python

      add = _register_external_op_helper("add")
      add = _register_external_op_helper("add", True)
      add = _register_external_op_helper("add", False)

- The other way is to implement the function by themselves to
check the attributes of the op and decide if it should be offloaded to tinykernel.
"""

import tvm
from ...dataflow_pattern import wildcard, is_op, is_constant
from .register import register_pattern_table
from ... import expr as _expr
from ... import op as _op
from ... import qnn as _qnn

def _register_external_op_helper(op_name, supported=True):
    """The helper function to indicate that a given operator can be supported
    by tinykernel.

    Paramters
    ---------
    op_name : Str
        The name of operator that will be registered.

    Returns
    -------
    f : callable
        A function that returns if the operator is supported by tinykernel.
    """
    @tvm.ir.register_op_attr(op_name, "target.tinykernel")
    def _func_wrapper(expr):
        return supported

    return _func_wrapper


_register_external_op_helper("nn.batch_norm")
_register_external_op_helper("nn.conv2d")
_register_external_op_helper("nn.dense")
_register_external_op_helper("nn.relu")
_register_external_op_helper("nn.max_pool2d")
_register_external_op_helper("nn.avg_pool2d")
_register_external_op_helper("nn.softmax")
_register_external_op_helper("add")
_register_external_op_helper("subtract")
_register_external_op_helper("multiply")
_register_external_op_helper("qnn.quantize")
_register_external_op_helper("qnn.conv2d")
_register_external_op_helper("nn.bias_add")
_register_external_op_helper("clip")
_register_external_op_helper("cast")
_register_external_op_helper("reshape")
_register_external_op_helper("take")
_register_external_op_helper("squeeze")
_register_external_op_helper("qnn.requantize")
_register_external_op_helper("qnn.dequantize")
_register_external_op_helper("qnn.dense")
_register_external_op_helper("nn.batch_flatten")

def make_pattern(with_bias=True):
    data = _expr.var("data")
    weight = _expr.var("weight")
    bias = _expr.var("bias")
    conv = _op.nn.conv2d(data, weight)
    if with_bias:
        conv_out = _op.add(conv, bias)
    else:
        conv_out = conv
    return _op.nn.relu(conv_out)

def make_quant_conv_pattern(with_bias=False):
    data = _expr.var("data", dtype="int8")
    weight = _expr.var("weight", dtype="int8")
    bias = _expr.var("bias", dtype="int")

    input_zero_point = _expr.var("input_zero_point", dtype="int")
    kernel_zero_point = _expr.var("kernel_zero_point", dtype="int")
    input_scale = _expr.var("input_scale", dtype="float32")
    kernel_scale = _expr.var("kernel_scale", dtype="float32")
    kernel_size = [3, 3]
    channels = 8

    qconv = _qnn.op.conv2d(data, weight, input_zero_point, kernel_zero_point, input_scale, kernel_scale, kernel_size, channels)
    if with_bias:
        qconv_out = _op.nn.bias_add(qconv, bias)
    else:
        qconv_out = qconv

    input_zero_point = _expr.var("new_input_zero_point", dtype="int")
    input_scale = _expr.var("new_input_scale", dtype="float32")
    output_scale = _expr.var("output_scale", dtype="float32")
    output_zero_point = _expr.var("output_zero_point", dtype="int")
    return _qnn.op.requantize(qconv_out, input_scale, input_zero_point, output_scale, output_zero_point)


def make_quant_dense_pattern(with_bias=False):
    data = _expr.var("data", dtype="uint8")
    weight = _expr.var("weight", dtype="uint8")
    bias = _expr.var("bias", dtype="int")

    input_zero_point = _expr.var("input_zero_point", dtype="int")
    input_scale = _expr.var("input_scale", dtype="float32")
    filter_zero_point = _expr.var("filter_zero_point", dtype="int")
    filter_scale = _expr.var("filter_scale", dtype="float32")
    out_features = 16
    qdense = _qnn.op.dense(data, weight,                               
                        input_zero_point=input_zero_point,
                        kernel_zero_point=filter_zero_point,
                        input_scale=input_scale,   
                        kernel_scale=filter_scale, 
                        units=out_features,
                        out_dtype='int32');

    if with_bias:
        qdense_out = _op.nn.bias_add(qdense, bias)
    else:
        qdense_out = qdense

    input_zero_point = _expr.var("new_input_zero_point", dtype="int")
    input_scale = _expr.var("new_input_scale", dtype="float32")
    output_scale = _expr.var("output_scale", dtype="float32")
    output_zero_point = _expr.var("output_zero_point", dtype="int")
    return _qnn.op.requantize(qdense_out, input_scale,
                              input_zero_point, output_scale,
                              output_zero_point,
                              out_dtype="uint8") 

def make_quant_softmax_pattern():
    data = _expr.var("data", dtype="uint8")
    input_zero_point = _expr.var("input_zero_point", dtype="int32")
    input_scale = _expr.var("input_scale", dtype="float32")
    res = _qnn.op.dequantize(data,input_scale,input_zero_point)

    softmax_out = _op.nn.softmax(res)

    input_zero_point = _expr.var("new_input_zero_point", dtype="int")
    input_scale = _expr.var("new_input_scale", dtype="float32")
    output_scale = _expr.var("output_scale", dtype="float32")
    output_zero_point = _expr.var("output_zero_point", dtype="int")
    return _qnn.op.quantize(softmax_out, output_scale, output_zero_point,out_dtype="uint8")

def make_take_reshape_squeeze_batch_flatten_pattern():
    data = _expr.var("input", dtype="float32")
    forward_indices = _expr.var("indices", dtype="int32")
    axis = [0]
    shape = (1, 1)

    take_output = _op.take(data, forward_indices)
    reshape_output = _op.reshape(take_output, shape)
    squeeze_output = _op.squeeze(reshape_output, axis)
    return _op.nn.batch_flatten(squeeze_output)

def make_take_reshape_batch_flatten_pattern():
    data = _expr.var("input", dtype="float32")
    forward_indices = _expr.var("indices", dtype="int32")
    axis = [0]
    shape = (1, 1)

    take_output = _op.take(data, forward_indices)
    reshape_output = _op.reshape(take_output, shape)
    return _op.nn.batch_flatten(reshape_output)

def make_dense_bias_add_relu_pattern():
    data = _expr.var("data", dtype="float32")
    weight = _expr.var("weight", dtype="float32")
    bias = _expr.var("bias", dtype="float32")

    dense = _op.nn.dense(data, weight, out_dtype="float32")
    bias_add = _op.nn.bias_add(dense, bias)
    return _op.nn.relu(bias_add)

def make_dense_bias_add_pattern():
    data = _expr.var("data", dtype="float32")
    weight = _expr.var("weight", dtype="float32")
    bias = _expr.var("bias", dtype="float32")

    dense = _op.nn.dense(data, weight, out_dtype="float32")
    return _op.nn.bias_add(dense, bias)

@register_pattern_table("tinykernel")
def pattern_table():
    conv2d_bias_relu_pat = ("tinykernel.conv2d_bias_relu", make_pattern(with_bias=True))
    conv2d_relu_pat = ("tinykernel.conv2d_relu", make_pattern(with_bias=False))

    qconv2d_bias_requant_pat = ("tinykernel.qconv2d_bias_requant",  make_quant_conv_pattern(with_bias=True))
    qconv2d_requant_pat = ("tinykernel.qconv2d_requant",  make_quant_conv_pattern(with_bias=False))

    dense_bias_requant_pat = ("tinykernel.dense_bias_requant",  make_quant_dense_pattern(with_bias=True))
    dense_requant_pat = ("tinykernel.dense_requant",  make_quant_dense_pattern(with_bias=False))

    # Disabled
    softmax_quant_pat  = ("tinykernel.softmax_quant",  make_quant_softmax_pattern())


    take_reshape_squeeze_batch_flatten_pat = ("tinykernel.take_reshape_squeeze_batch_flatten",  make_take_reshape_squeeze_batch_flatten_pattern())
    take_reshape_batch_flatten_pat = ("tinykernel.take_reshape_batch_flatten",  make_take_reshape_batch_flatten_pattern())

    dense_bias_add_relu_pattern = ("tinykernel.dense_bias_add_relu",  make_dense_bias_add_relu_pattern())
    dense_bias_add_pattern = ("tinykernel.dense_bias_add",  make_dense_bias_add_pattern())

    tinykernel_patterns = [conv2d_bias_relu_pat, conv2d_relu_pat, qconv2d_bias_requant_pat, qconv2d_requant_pat, dense_bias_requant_pat, dense_requant_pat, softmax_quant_pat, take_reshape_squeeze_batch_flatten_pat, take_reshape_batch_flatten_pat, dense_bias_add_relu_pattern, dense_bias_add_pattern]

    return tinykernel_patterns
