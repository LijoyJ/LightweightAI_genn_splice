/*
 * Copyright (c) 2021 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*!
 * \file src/relay/backend/contrib/tinykernel/codegen.cc
 * \brief Implementation of TINYKERNEL codegen APIs.
 */

#include <tvm/relay/attrs/nn.h>
#include <tvm/relay/expr_functor.h>
#include <tvm/relay/qnn/attrs.h>
#include <tvm/relay/transform.h>
#include <tvm/relay/type.h>
#include <tvm/runtime/module.h>
#include <tvm/runtime/registry.h>

#include <tvm/ir/attrs.h>
#include <tvm/relay/base.h>
#include <tvm/relay/expr.h>

#include <string>
#include <fstream>
#include <numeric>
#include <sstream>
#include <dlfcn.h>
#include <iterator>
#include <streambuf>

#include "../../utils.h"
#include "../codegen_c/codegen_c.h"
#include "./codegen.h"
#include "./codegen_config.h"
#include "kernels/src/tinykernel_constants.h"

#define PDBG 0

#define KERNEL_ROUTE_CONFIG 1

namespace tvm {
namespace relay {
namespace contrib {

using namespace qnn;
using namespace backend;

char *config = 0;

//update the variable from config json
std::string TVM_HOME = std::string(std::getenv(TVM_HOME_ENV_VAR));

//TODO::Config file path needs to be passed as a build parameter or it needs to be set in cmake
std::string CONFG_JSON_FILE_PATH = TVM_HOME + DEFAULT_KERNEL_CFG_RELATIVE_PATH;

std::string GetDtypeString(DLDataType dtype_code) {
  std::string dtype;
  if (runtime::TypeMatch(dtype_code, kDLFloat, 32)) {
    dtype = "float";
  } else if (runtime::TypeMatch(dtype_code, kDLInt, 32)) {
    dtype = "int";
  } else if (runtime::TypeMatch(dtype_code, kDLInt, 64)) {
    dtype = "int64_t";
  } else if (runtime::TypeMatch(dtype_code, kDLInt, 8)) {
    dtype = "int8_t";
  } else if (runtime::TypeMatch(dtype_code, kDLUInt, 8)) {
    dtype = "uint8_t";
  } else {
    LOG(FATAL) << "Unsupported dtype";
  }

  return dtype;
}

inline size_t GetShape1DSize (const Type& type) {
  const auto shape = GetShape(type);
  return std::accumulate(shape.begin(), shape.end(), 1, std::multiplies<int>());
}

void CodegenTINYKERNEL::ClearNeedTranspose(){
  need_transpose = 0;
}

CodegenTINYKERNEL::CodegenTINYKERNEL(const std::string &id) { this->ext_func_id_ = id; }

  std::vector<Output> CodegenTINYKERNEL::VisitExprDefault_(const Object *op){
    LOG(FATAL) << "TINYKERNEL codegen doesn't support: " << op->GetTypeKey();
    return {};
  }

  std::vector<Output> CodegenTINYKERNEL::VisitExpr_(const VarNode *node){
    ext_func_args_.push_back(GetRef<Var>(node));
    Output output;
    output.name = node->name_hint();
    return {output};
  }

  std::vector<Output> CodegenTINYKERNEL::VisitExpr_(const TupleGetItemNode *op){
    auto res = VisitExpr(op->tuple);
    ICHECK_GT(res.size(), static_cast<size_t>(op->index));

    // Only keep the item we want for the child node.
    // FIXME(@comaniac): The other items should still be requried for the
    // primary outputs.
    return {res[op->index]};
  }

  template <typename T>
  void CodegenTINYKERNEL::TransposeHWIO2OHWI(const T *in_data, T *out_data,
                          std::vector<int64_t> shape) {
    if (PDBG)
      std::cout << "Shape:" << shape[0] << " " << shape[1] << " " << shape[2]
                << " " << shape[3] << std::endl;

    int data_size = shape[0] * shape[1];

    if (shape.size() != 4) {
      for (int i = 0; i < data_size; i++) {
        out_data[i] = in_data[i];
      }
      return;
    }

    if (PDBG)
      std::cout << "TransposeHWIO2OHWI data shape size:" << shape.size()
                << std::endl;
    int count = 0;
    for (int l = 0; l < shape[3]; l++) {
      for (int i = 0; i < shape[0]; i++) {
        for (int j = 0; j < shape[1]; j++) {
          for (int k = 0; k < shape[2]; k++) {
            *(out_data + count) = static_cast<T>(
                in_data[(l + i * shape[1] * shape[2] * shape[3]) +
                        (j * shape[2] * shape[3]) + (k * shape[3])]);
            count++;
          }
          if (PDBG)
            std::cout << std::endl;
        }
      }
    }

    if (PDBG)
      std::cout << "Final output:" << std::endl;
    int size = shape[0] * shape[1] * shape[2] * shape[3];
    int break_count = 0;
    for (int i = 0; i < size; i++) {
      if (PDBG)
        std::cout << *(out_data + i) + 0 << " ";
      break_count++;
      if (break_count == 30) {
        break_count = 0;
        if (PDBG)
          std::cout << std::endl;
      }
    }
  }

  std::vector<Output> CodegenTINYKERNEL::VisitExpr_(const ConstantNode *cn){

    if (PDBG)
      std::cout << "CodegenTINYKERNEL, VisitExpr_ ConstantNode" << std::endl;
    Output output;
    output.name = "const_" + std::to_string(const_idx_++);

    runtime::NDArray array = cn->data;

    // Get the number of elements.
    int64_t num_elems = 1;
    for (auto i : array.Shape())
      num_elems *= i;

    const auto *type_node = cn->checked_type().as<TensorTypeNode>();
    ICHECK(type_node);
    output.dtype = GetDtypeString(type_node);

    std::ostringstream buf_stream;
    if (runtime::TypeMatch(type_node->dtype, kDLFloat, 32)) {
      const float *ptr = static_cast<float *>(array->data);
      // Allocate large arrays on the static section to avoid stakc overflow.
      // Note that this would probably increase compilation time as the source
      // file could be really large.
      buf_stream << "static const " << GetDtypeString(type_node) << " "
                 << output.name << "[" << num_elems << "] = {";
      for (int64_t i = 0; i < num_elems - 1; i++) {
        buf_stream << ptr[i] << ",";
      }
      if (num_elems > 0)
        buf_stream << ptr[num_elems - 1];
      buf_stream << "};\n";

      ext_func_body_.insert(ext_func_body_.begin(), buf_stream.str());
    } else if (runtime::TypeMatch(type_node->dtype, kDLInt, 32)) {
      const int *ptr = static_cast<int *>(array->data);
      // Allocate large arrays on the static section to avoid stakc overflow.
      // Note that this would probably increase compilation time as the source
      // file could be really large.
      buf_stream << "static const " << GetDtypeString(type_node) << " "
                 << output.name << "[" << num_elems << "] = {";
      for (int64_t i = 0; i < num_elems - 1; i++) {
        buf_stream << ptr[i] << ",";
      }
      if (num_elems > 0)
        buf_stream << ptr[num_elems - 1];
      buf_stream << "};\n";

      ext_func_body_.insert(ext_func_body_.begin(), buf_stream.str());
    } else if (runtime::TypeMatch(type_node->dtype, kDLInt, 8)) {
      const int8_t *ptr = static_cast<int8_t *>(array->data);
      // Allocate large arrays on the static section to avoid stakc overflow.
      // Note that this would probably increase compilation time as the source
      // file could be really large.

      // HWIO to OHWI for tinykernel
      int8_t *new_data = (int8_t *)malloc(sizeof(int8_t) * num_elems);
      TransposeHWIO2OHWI<int8_t>(ptr, new_data, array.Shape());

      buf_stream << "static const " << GetDtypeString(type_node) << " "
                 << output.name << "[" << num_elems << "] = {";
      for (int64_t i = 0; i < num_elems - 1; i++) {
        if (PDBG)
          std::cout << "Weight data:" << (ptr[i] + 0) << std::endl;
        buf_stream << (int)(new_data[i] + 0) << ",";
      }
      if (num_elems > 0)
        buf_stream << (int)(new_data[num_elems - 1] + 0);
      buf_stream << "};\n";

      ext_func_body_.insert(ext_func_body_.begin(), buf_stream.str());
    } else if (runtime::TypeMatch(type_node->dtype, kDLUInt, 8)) {
      const uint8_t *ptr = static_cast<uint8_t *>(array->data);
      // Allocate large arrays on the static section to avoid stakc overflow.
      // Note that this would probably increase compilation time as the source
      // file could be really large.

      if (PDBG)
        std::cout << "TINYKERNEL need_transpose:" << need_transpose
                  << std::endl;
      const uint8_t *param = ptr;
      // HWIO to OHWI for TINYKERNEL
      if (need_transpose) {
        uint8_t *new_data = (uint8_t *)malloc(sizeof(uint8_t) * num_elems);
        TransposeHWIO2OHWI<uint8_t>(ptr, new_data, array.Shape());
        param = new_data;
      }

      buf_stream << "static const " << GetDtypeString(type_node) << " "
                 << output.name << "[" << num_elems << "] = {";
      for (int64_t i = 0; i < num_elems - 1; i++) {
        if (PDBG)
          std::cout << "Weight data:" << (ptr[i] + 0) << std::endl;
        buf_stream << (int)(param[i] + 0) << ",";
      }
      if (num_elems > 0)
        buf_stream << (int)(param[num_elems - 1] + 0);
      buf_stream << "};\n";

      ext_func_body_.insert(ext_func_body_.begin(), buf_stream.str());
    } else {
      std::cout << "UNSUPPORTED TYPE!!!!! VisitExpr_" << std::endl;
    }

    return {output};
  }

  void CodegenTINYKERNEL::SetConv2DTraspose(const CallNode *call) {
    const auto *conv2d_attr = call->attrs.as<Conv2DAttrs>();
    int groups = conv2d_attr->groups;

    if (PDBG)
      std::cout << "TINYKERNEL SetConv2DTraspose, groups:" << groups
                << std::endl;
    if (groups != 1) {
      need_transpose = 0;
    }
  }

  std::vector<Output> CodegenTINYKERNEL::VisitExpr_(const CallNode *call){
    GenerateBodyOutput ret;
    if (const auto *func = call->op.as<FunctionNode>()) {
      ret = GenerateCompositeFunctionCall(func, call);
    } else {
      ret = GenerateOpCall(call);
    }

    buf_decl_.insert(buf_decl_.end(), ret.buffers.begin(), ret.buffers.end());
    ext_func_body_.push_back(ret.decl);

    src_files_ = ret.source_files;
    header_files_ = ret.header_files;

    return ret.outputs;
  }

  std::string CodegenTINYKERNEL::JIT(const std::vector<Output> &out) {
    return JitImpl(ext_func_id_, ext_func_args_, buf_decl_, ext_func_body_, const_array_name_, out);
  }

  std::vector<std::string> CodegenTINYKERNEL::GetSourceFiles() {
    return src_files_;
  }

  std::vector<std::string> CodegenTINYKERNEL::GetHeaderFiles() {
    return header_files_;
  }

  Array<String> CodegenTINYKERNEL::GetConstantVars() {
    return const_vars_;
  }

  std::string CodegenTINYKERNEL::GetQuantizationType(std::string func_name,
                                  const CallNode *call) {
    std::string arg0_type =
        GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>());
    std::string ret_type =
        GetDtypeString(call->checked_type().as<TensorTypeNode>());
    std::string quant_type = "";

    if (PDBG)
      std::cout << "GetQuantizationType func_name:" << func_name << std::endl;
    if (!ret_type.compare("uint8_t")) {
      quant_type = "uint8";
    } else if (!ret_type.compare("int8_t")) {
      quant_type = "int8";
    } else if (!arg0_type.compare("uint8_t")) {
      quant_type = "uint8";
    } else if (!arg0_type.compare("int8_t")) {
      quant_type = "int8";
    } else {
      if (PDBG)
        std::cout << "Quant not supported...." << arg0_type << " " << ret_type
                  << std::endl;
    }

    if (!func_name.compare("cast")) {
      quant_type = "";
    } else if (!func_name.compare("clip")) {
      quant_type = "";
    } else if (!func_name.compare("reshape")) {
      quant_type = "";
    } else if (!func_name.compare("qnn.dequantize")) {
      quant_type = "";
    } else if (!func_name.compare("qnn.quantize")) {
      quant_type = "";
    } else if (!func_name.compare("nn.max_pool2d")) {
      quant_type = "";
    } else if (!func_name.compare("tinykernel.dense_bias_requant")) {
      quant_type = "";
    } else if (!func_name.compare("tinykernel.softmax_quant")) {
      quant_type = "";
    } else if (!func_name.compare("tinykernel.take_reshape_squeeze_batch_flatten")) {
      quant_type = "";
    } else if (!func_name.compare("tinykernel.take_reshape_batch_flatten")) {
      quant_type = "";
    }

    if (PDBG)
      std::cout << "Quant type:" << quant_type << std::endl;

    return quant_type;
  }

  std::vector<std::string> CodegenTINYKERNEL::GetArgumentNames(const CallNode *call) {
    std::vector<std::string> arg_names;
    for (size_t i = 0; i < call->args.size(); ++i) {
      auto res = VisitExpr(call->args[i]);

      for (const auto &out : res) {
        arg_names.push_back(out.name);
      }
    }
    return arg_names;
  }

  GenerateBodyOutput CodegenTINYKERNEL::GenerateOpCall(const CallNode *call) {
    const auto *op_node = call->op.as<OpNode>();
    ICHECK(op_node) << "Expect OpNode, but got " << call->op->GetTypeKey();

    std::string op_name = GetRef<Op>(op_node)->name;
    if (PDBG) std::cout<<"TINYKERNEL codegen OP parsing, op_name:"<<op_name<<std::endl;
    std::string quant_type = GetQuantizationType(op_name, call);
    if (!quant_type.empty()) {
      op_name = op_name + "_" + quant_type;
    }

    string func_name = CodegenConfig::GetConfig(config, op_name, OP_KERNEL_FUNCTION_NAME_CONFIG);
    if (func_name.empty()){
      LOG(FATAL) << "func name not configured for op_name: " << op_name;
      return {};
    }

    string libPath = CodegenConfig::GetConfig(config, op_name, KERNEL_SHARED_LIBRARY_PATH_CONFIG);
    if (libPath.empty()){
      LOG(FATAL) << "lib path not configured for op_name: " << op_name;
      return {};
    }
    libPath = TVM_HOME + libPath;

    void* lib=dlopen(libPath.c_str(), RTLD_LAZY);
    if(lib == NULL){
      LOG(FATAL) << "unable to load shared library for op_name: " << op_name;
      return {};
    }

    string fnName = CodegenConfig::GetConfig(config, op_name, GENERATE_KERNEL_FUNCTIONS_ARGUMENTS_CFG);
    if (fnName.empty()){
      LOG(FATAL) << "kernel generate funtion not configured for op_name: " << op_name;
      return {};
    }

    void* pfn = dlsym(lib, fnName.c_str());
    if(pfn == NULL){
      LOG(FATAL) << "unable to load kernel generate function for op_name: " << op_name;
      return {};
    }

    //TODO: validate the function signature
    ArgFunType argFun = (ArgFunType)pfn;


    CodegenConfig cfgHandler = CodegenConfig(config); //TODO: remove the dependency due to stream parser
    std::vector<std::string>cfg;
    cfg.push_back(op_name);
    cfg.push_back(KERNEL_IMPL_C_FILE_CFG); //TODO change the files to array of files
    string file = cfgHandler.GetConfig(cfg);
    std::vector<std::string> source_files;
    if (!file.empty()){
     source_files = std::vector<std::string>{(file)};
    }

    cfgHandler = CodegenConfig(config); //TODO: remove the dependency due to stream parser
    cfg.clear();
    cfg.push_back(op_name);
    cfg.push_back(KERNEL_FUNCTION_DECL_H_FILE_CFG); //TODO change the files to array of files
    file = cfgHandler.GetConfig(cfg);
    std::vector<std::string> header_files;
    if (!file.empty()){
     header_files = std::vector<std::string>{(file)};
    }

    return GenerateBodyComposite(call, func_name, argFun(call, this), source_files, header_files);

    LOG(FATAL) << "Unsupported op: " << AsText(call->op, false);
    return {};
  }

  std::string CodegenTINYKERNEL::GetCompositeFunctionName(std::string pattern_name) {
    std::replace(pattern_name.begin(), pattern_name.end(), '.', ' ');

    std::stringstream ss(pattern_name);
    std::vector<std::string> array;
    std::string temp;
    while (ss >> temp) {
      array.push_back(temp);
      if (PDBG)
        std::cout << "Composite func name... " << temp << std::endl;
    }

    return "";
  }

  GenerateBodyOutput CodegenTINYKERNEL::GenerateCompositeFunctionCall(const FunctionNode *callee,
                                                   const CallNode *caller) {
    const auto pattern_name =
        callee->GetAttr<runtime::String>(attr::kComposite);
    ICHECK(pattern_name.defined())
        << "Only functions with composite attribute supported";
    std::string pattern = pattern_name.value();
    std::string quant_type = GetQuantizationType(pattern, caller);
    if (!quant_type.empty()) {
      pattern = pattern + "_" + quant_type;
    }

    string libPath = CodegenConfig::GetConfig(config, pattern, KERNEL_SHARED_LIBRARY_PATH_CONFIG);
    if (libPath.empty()){
      LOG(FATAL) << "lib path not configured for pattern: " << pattern;
      return {};
    }
    libPath = TVM_HOME + libPath;

    void* lib=dlopen(libPath.c_str(), RTLD_LAZY);
    if(lib == NULL){
      LOG(FATAL) << "unable to load shared library for pattern: " << pattern;
      return {};
    }

    string fnName = CodegenConfig::GetConfig(config, pattern, GENERATE_KERNEL_FUNCTION_BODY_CFG);
    if (fnName.empty()){
      LOG(FATAL) << "kernel generate funtion not configured for pattern: " << pattern;
      return {};
    }

    void* pfn = dlsym(lib, fnName.c_str());
    if(pfn == NULL){
      LOG(FATAL) << "unable to load kernel generate function for pattern: " << pattern;
      return {};
    }

    //TODO: validate the function signature
    pfnGenerateCompositeFunctionCall genFun = (pfnGenerateCompositeFunctionCall)pfn;


    CodegenConfig cfgHandler = CodegenConfig(config); //TODO: remove the dependency due to stream parser
    std::vector<std::string>cfg;
    cfg.push_back(pattern);
    cfg.push_back(KERNEL_IMPL_C_FILE_CFG); //TODO change the files to array of files
    string file = cfgHandler.GetConfig(cfg);
    std::vector<std::string> source_files;
    if (!file.empty()){
     source_files = std::vector<std::string>{(file)};
    }

    cfgHandler = CodegenConfig(config); //TODO: remove the dependency due to stream parser
    cfg.clear();
    cfg.push_back(pattern);
    cfg.push_back(KERNEL_FUNCTION_DECL_H_FILE_CFG); //TODO change the files to array of files
    file = cfgHandler.GetConfig(cfg);
    std::vector<std::string> header_files;
    if (!file.empty()){
     header_files = std::vector<std::string>{(file)};
    }

    return genFun(callee, caller, source_files, header_files, this);

    LOG(FATAL) << "Unknown composite function:" << pattern;
    return {};
  }

  GenerateBodyOutput
  CodegenTINYKERNEL::GenerateBody(const CallNode *root_call, const std::string &func_name,
                                  const std::vector<std::string> &attribute_args) {
    return GenerateBody(root_call, func_name, GetArgumentNames(root_call), attribute_args);
  }

  GenerateBodyOutput
  CodegenTINYKERNEL::GenerateBodyComposite(const CallNode *root_call, const std::string &func_name,
                                           const std::vector<std::string> &attribute_args) {
    return GenerateBodyComposite(root_call, func_name, GetArgumentNames(root_call), attribute_args,
                                 std::vector<std::string>(), std::vector<std::string>());//TODO handle the file paths
  }

  GenerateBodyOutput
  CodegenTINYKERNEL::GenerateBodyComposite(const CallNode *root_call, const std::string &func_name,
                                           const std::vector<std::string> &attribute_args,
                                           const std::vector<std::string> source_files,
                                           const std::vector<std::string> header_files) {
    return GenerateBodyComposite(root_call, func_name, GetArgumentNames(root_call), attribute_args,
                                 source_files, header_files);//TODO handle the file paths
  }

  GenerateBodyOutput
  CodegenTINYKERNEL::GenerateBodyComposite(const CallNode *root_call,
                                           const std::string &func_name,
                                           const std::vector<std::string> &func_args,
                                           const std::vector<std::string> &attribute_args,
                                           const std::vector<std::string> source_files,
                                           const std::vector<std::string> header_files) {
    // Make function call with input buffers when visiting arguments
    ICHECK_GT(func_args.size(), 0);
    std::ostringstream decl_stream;
    decl_stream << "(" << func_args[0];
    for (size_t i = 1; i < func_args.size(); ++i) {
      decl_stream << ", " << func_args[i];
    }

    // Analyze the output buffers
    std::vector<Type> out_types;
    if (root_call->checked_type()->IsInstance<TupleTypeNode>()) {
      auto type_node = root_call->checked_type().as<TupleTypeNode>();
      for (auto field : type_node->fields) {
        ICHECK(field->IsInstance<TensorTypeNode>());
        out_types.push_back(field);
      }
    } else if (root_call->checked_type()->IsInstance<TensorTypeNode>()) {
      ICHECK(root_call->checked_type()->IsInstance<TensorTypeNode>());
      out_types.push_back(root_call->checked_type());
    } else {
      LOG(FATAL) << "Unrecognized type node: "
                 << AsText(root_call->checked_type(), false);
    }

    GenerateBodyOutput ret;
    this->PrintIndents();
    const std::string out = "out";
    const auto out_size = GetShape1DSize(out_types[0]);
    decl_stream << ", " << out;

    Output output;
    output.name = out;
    output.size = out_size;
    output.dtype = GetDtypeString(out_types[0].as<TensorTypeNode>());
    output.need_copy = false;
    ret.outputs.push_back(output);

    // Attach attribute arguments
    for (size_t i = 0; i < attribute_args.size(); ++i) {
      decl_stream << ", " << attribute_args[i];
    }
    decl_stream << ", out_type_code);";

    std::string fname = func_name;

    for (auto itr : source_files){
      ret.source_files.push_back(itr);
    }
    for (auto itr : header_files){
      ret.header_files.push_back(itr);
    }

    if (PDBG)
      std::cout << "composit Function name......................:" << fname
                << std::endl;
    ret.decl = fname + decl_stream.str();
    return ret;
  }

  GenerateBodyOutput
  CodegenTINYKERNEL::GenerateBody(const CallNode* root_call, const std::string &func_name,
                                  const std::vector<std::string> &func_args,
                                  const std::vector<std::string> &attribute_args) {
    // Make function call with input buffers when visiting arguments
    ICHECK_GT(func_args.size(), 0);
    std::ostringstream decl_stream;
    decl_stream << "(" << func_args[0];
    for (size_t i = 1; i < func_args.size(); ++i) {
      decl_stream << ", " << func_args[i];
    }

    // Analyze the output buffers
    std::vector<Type> out_types;
    if (root_call->checked_type()->IsInstance<TupleTypeNode>()) {
      auto type_node = root_call->checked_type().as<TupleTypeNode>();
      for (auto field : type_node->fields) {
        ICHECK(field->IsInstance<TensorTypeNode>());
        out_types.push_back(field);
      }
    } else if (root_call->checked_type()->IsInstance<TensorTypeNode>()) {
      ICHECK(root_call->checked_type()->IsInstance<TensorTypeNode>());
      out_types.push_back(root_call->checked_type());
    } else {
      LOG(FATAL) << "Unrecognized type node: "
                 << AsText(root_call->checked_type(), false);
    }

    GenerateBodyOutput ret;
    for (const auto &out_type : out_types) {
      this->PrintIndents();
      const std::string out = "buf_" + std::to_string(buf_idx_++);
      const auto out_size = GetShape1DSize(out_type);
      decl_stream << ", " << out;

      Output output;
      output.name = out;
      output.size = out_size;
      output.dtype = GetDtypeString(out_type.as<TensorTypeNode>());
      output.need_copy = true;

      const auto *type_node = out_type.as<TensorTypeNode>();

      if (runtime::TypeMatch(type_node->dtype, kDLFloat, 32)) {
        ret.buffers.push_back("float* " + out + " = (float*)std::malloc(4 * " +
                              std::to_string(out_size) + ");");
      } else if (runtime::TypeMatch(type_node->dtype, kDLInt, 32)) {
        ret.buffers.push_back("int* " + out + " = (int*)std::malloc(4 * " +
                              std::to_string(out_size) + ");");
      } else if (runtime::TypeMatch(type_node->dtype, kDLInt, 8)) {
        ret.buffers.push_back("int8_t* " + out +
                              " = (int8_t*)std::malloc(1 * " +
                              std::to_string(out_size) + ");");
      } else if (runtime::TypeMatch(type_node->dtype, kDLUInt, 8)) {
        ret.buffers.push_back("uint8_t* " + out +
                              " = (uint8_t*)std::malloc(1 * " +
                              std::to_string(out_size) + ");");
      } else {
        std::cout << "UNSUPPORTED TYPE!!!!! GenerateBody" << std::endl;
      }

      ret.outputs.push_back(output);
    }

    // Attach attribute arguments
    for (size_t i = 0; i < attribute_args.size(); ++i) {
      decl_stream << ", " << attribute_args[i];
    }
    decl_stream << ");";

    std::string fname = func_name;
    std::string quant_type = GetQuantizationType(func_name, root_call);
    if (!quant_type.empty()) {
      fname = func_name + "_" + quant_type;
    }

    if (PDBG)
      std::cout << "Function name......................:" << fname << std::endl;
    ret.decl = fname + decl_stream.str();
    return ret;
  }


/*!
 * \brief The tinykernel codegen helper to generate wrapepr function calls of
 * tinykernel libraries. The code is a CSourceModule that can be compiled
 * separately and linked together with a DSOModule.
 */
class TINYKERNELModuleCodegen : public CSourceModuleCodegenBase {
public:
  // Create a corresponding tinykernel function for the given relay Function.
  std::pair<std::string, Array<String>>  GenTINYKERNELFunc(const Function &func) {
    ICHECK(func.defined()) << "Input error: expect a Relay function.";

    // Record the external symbol for runtime lookup.
    auto sid = GetExtSymbol(func);
    symbol_names_.push_back(sid);

    if (PDBG)
      std::cout << "TINYKERNELModuleCodegen, creating CodegenTINYKERNEL"
                << std::endl;
    CodegenTINYKERNEL *builder = GetCodeGenImpl(sid);
    auto out = builder->VisitExpr(func->body);

    auto src_files = builder->GetSourceFiles();
    for(auto it = src_files.begin(); it != src_files.end(); it++) {
      if (find(src_files_.begin(), src_files_.end(), *it) == src_files_.end()) {
        if (PDBG) std::cout<<"TINYKERNEL kernel source files found "<<*it<<std::endl;
        src_files_.push_back(*it);
      }
    }

    auto header_files = builder->GetHeaderFiles();
    for(auto it = header_files.begin(); it != header_files.end(); it++) {
      if (find(header_files_.begin(), header_files_.end(), *it) == header_files_.end()) {
        if (PDBG) std::cout<<"TINYKERNEL kernel header files found "<<*it<<std::endl;
        header_files_.push_back(*it);
      }
    }

    src_code_stream_ << builder->JIT(out);
    return {sid, builder->GetConstantVars()};
  }

  std::string AddRegisterOperatorFunction() {
    std::ostringstream header_stream;

    // Add header
    header_stream << "void add_operator_func(std::vector<OHOS::AI::OperatorFunction>* operator_funcs, std::string func_name, void* func_ptr) {\n";
    header_stream << "  OHOS::AI::OperatorFunction operatorFunction;\n";
    header_stream << "  operatorFunction.func_name = func_name;\n";
    header_stream << "  operatorFunction.func_ptr = func_ptr;\n";
    header_stream << "  operator_funcs->push_back(operatorFunction);\n";
    header_stream << "}\n";
    header_stream << "\n";

    header_stream << "extern \"C\" void get_operator_funcs(std::vector<OHOS::AI::OperatorFunction>* operator_funcs) {\n";
    for(auto it = symbol_names_.begin(); it != symbol_names_.end(); it++) {
      header_stream << "  add_operator_func(operator_funcs, \"";
      header_stream << *it;
      header_stream << "\", (void*)&";
      header_stream << *it;
      header_stream << ");\n";
    }
    header_stream << "}\n";
    header_stream << "\n";
    return header_stream.str();
  }

  /*!
   * \brief The overridden function that will create a CSourceModule. In order
   * to compile the generated C source code, users need to specify the paths to
   * some libraries, including some TVM required and tinykernel specific ones.
   * To make linking simpiler, the tiny kernels are wrapped in a TVM compatible
   * manner and live under tvm/src/runtime/contrib/tinykernel folder.
   *
   * \param ref An object ref that could be either a Relay function or module.
   *
   * \return The runtime module that contains C source code.
   */
  runtime::Module CreateCSourceModule(const ObjectRef &ref) override {
    // Create headers
    code_stream_ << "#include <cstdint>\n";
    code_stream_ << "#include <cstdlib>\n";
    code_stream_ << "#include <cstring>\n";
    code_stream_ << "#include <vector>\n";
    code_stream_ << "#include <runtime.h>\n";
    code_stream_ << "#include <external/packed_func.h>\n";

    std::pair<std::string, Array<String>> res;

    if (ref->IsInstance<FunctionNode>()) {
      if (PDBG)
        std::cout << "tinykernel GenTINYKERNELFunc called with FunctionNode"
                  << std::endl;
      res = GenTINYKERNELFunc(Downcast<Function>(ref));
    } else if (ref->IsInstance<IRModuleNode>()) {
      IRModule mod = Downcast<IRModule>(ref);
      for (const auto &it : mod->functions) {
        if (PDBG)
          std::cout << "tinykernel GenTINYKERNELFunc called with IRModuleNode"
                    << std::endl;
        res = GenTINYKERNELFunc(Downcast<Function>(it.second));
      }
    } else {
      LOG(FATAL) << "The input ref is expected to be a Relay function or module"
                 << "\n";
    }

    for (auto header_file = header_files_.begin(); header_file < header_files_.end(); header_file++) {
        code_stream_ << "#include <tinykernel/"<<*header_file<<">\n";
    }

    std::vector<std::string> src_files;
    for(auto it = src_files_.begin(); it != src_files_.end(); it++) {
      auto src_file = "src/relay/backend/contrib/tinykernel/kernels/src/" + *it + "";
      src_files.push_back(src_file);
    }

    std::ofstream output_file("./tinykernel_files.txt");
    std::ostream_iterator<std::string> output_iterator(output_file, "\n");
    std::copy(src_files.begin(), src_files.end(), output_iterator);

    code_stream_ << "using namespace OHOS::AI;\n";
    code_stream_ << "\n";

    code_stream_ << src_code_stream_.str();

    code_stream_ << "\n";
    code_stream_ << AddRegisterOperatorFunction();
    code_stream_ << "\n";

    // Create a CSource module
    const auto* pf = runtime::Registry::Get("runtime.CSourceModuleCreate");
    ICHECK(pf != nullptr) << "Cannot find csource module to create the external runtime module";
    std::string code = code_stream_.str();
    String sym = std::get<0>(res);
    Array<String> variables = std::get<1>(res);
    return (*pf)(code, "c", Array<String>{sym}, variables);
  }

private:
  /*!
   * \brief The code stream that prints the code that will be compiled using
   * external codegen tools.
   */
  std::ostringstream code_stream_;
  std::ostringstream src_code_stream_;

  std::vector<std::string> src_files_;
  std::vector<std::string> header_files_;
  std::vector<std::string> symbol_names_;

  CodegenTINYKERNEL* GetCodeGenImpl(const std::string &id) {

    string libPath = CodegenConfig::GetConfig(config, CONSTRUCT_TINY_KERNEL_CODE_GEN_OBJ_CFG, TINYKERNEL_GENERATOR_LIB_PATH_CFG);
    if (libPath.empty()){
      LOG(FATAL) << "lib path not configured for ConstructCodegenImpl";
      return {};
    }
    libPath = TVM_HOME + libPath;

    void* lib=dlopen(libPath.c_str(), RTLD_LAZY);
    if(lib == NULL){
      LOG(FATAL) << "unable to load shared library for ConstructCodegenImpl";
      return {};
    }

    string fnName = CodegenConfig::GetConfig(config, CONSTRUCT_TINY_KERNEL_CODE_GEN_OBJ_CFG, TINYKERNEL_GENERATOR_CONSTRUCTOR_CFG);
    if (fnName.empty()){
      LOG(FATAL) << "Code gen constructor funtion not configured ConstructCodegenImpl";
      return {};
    }

    void* pfn = dlsym(lib, fnName.c_str());
    if(pfn == NULL){
      LOG(FATAL) << "unable to load kernel generate function for pattern: ";
      return {};
    }

    //TODO: validate the function signature
    pfnConstructCodegenImpl getImpl = (pfnConstructCodegenImpl)pfn;

    return getImpl(id);

  }
};

/*!
 * \brief The external compiler/codegen tool. It takes a Relay expression/module
 * and compile it into a runtime module.
 */
runtime::Module TINYKERNELCompiler(const ObjectRef &ref) {

  std::ifstream file(CONFG_JSON_FILE_PATH);
  std::string str((std::istreambuf_iterator<char>(file)),
                        std::istreambuf_iterator<char>());

  config = const_cast<char *>(str.c_str());

  TINYKERNELModuleCodegen tinykernel;
  return tinykernel.CreateCSourceModule(ref);
}

TVM_REGISTER_GLOBAL("relay.ext.tinykernel").set_body_typed(TINYKERNELCompiler);

} // namespace contrib
} // namespace relay
} // namespace tvm
