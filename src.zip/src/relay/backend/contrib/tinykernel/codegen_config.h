/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*!
 * \file src/relay/backend/contrib/tinykernel/codegen_config.h
 * \brief config management for code gen.
 */

#ifndef CODEGEN_CONFIG_H_
#define CODEGEN_CONFIG_H_

#include <vector>
#include <string>
#include "rapidjson/document.h"     // rapidjson's DOM-style API

namespace tvm {
namespace relay {
namespace contrib {

/**
 *
 * @brief Declares functions in the codegen config management class.
 *{
 *  "nacll": {
 *    "NCHW": {
 *      "conv1d": {
 *        "kernelFn": "neonNCHWConv1d",
 *        "filename": "nacl/nchw/neonconv.cpp"
 *      },
 *      "conv2d": {
 *        "kernelFn": "neonNCHWConv2d",
 *        "filename": "nacl/nchw/neonconv2d.cpp"
 *      },
 *      "avgpool": {
 *        "kernelFn": "NCHWavgpool",
 *        "filename": "nacl/nchw/avgpool.cpp"
 *      }
 *    },
 *    "default": {
 *      "conv1d": {
 *        "kernelFn": "neonConv1d",
 *        "filename": "nacl/neonconv.cpp"
 *      },
 *      "conv2d": {
 *        "kernelFn": "neonConv2d",
 *        "filename": "nacl/neonconv2d.cpp"
 *      },
 *      "avgpool": {
 *        "kernelFn": "avgpool",
 *        "filename": "nacl/avgpool.cpp"
 *      }
 *    }
 *  },
 *  "default": {
 *    "default": {
 *      "conv1d": {
 *        "kernelFn": "defaultConv1d",
 *        "filename": "tiny/conv.cpp"
 *      },
 *      "conv2d": {
 *        "kernelFn": "defaultConv2d",
 *        "filename": "tiny/conv.cpp"
 *      },
 *      "avgpool": {
 *        "kernelFn": "avgpool",
 *        "filename": "tiny/avgpool.cpp"
 *      }
 *    }
 *  }
 *}
 *
 *
 * @since 1.0
 * @version 1.0
 */
class CodegenConfig{
    public:
        /**
         * @brief Constructor, initializes the config reader with the json string.
         *
         * @param graph_json json string containing the configuration.
         *
         */
        explicit CodegenConfig(const char* graph_json);

        /**
         * @brief get the required config.
         *
         * @param options AI runtime options.
         *
         */
        std::string GetConfig(std::vector<std::string> tags);

        /**
         * @brief get the required config.
         *
         * @param options AI runtime options.
         */
        static std::string GetConfig(const char* graph_json, std::string tag1, std::string tag2);

    private:
        rapidjson::Document document;
};



}  // namespace contrib
}  // namespace relay
}  // namespace tvm
#endif // CODEGEN_CONFIG_H_
