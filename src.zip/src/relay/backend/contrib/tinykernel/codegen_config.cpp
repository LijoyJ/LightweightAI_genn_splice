
#include "codegen_config.h"


namespace tvm {
namespace relay {
namespace contrib {


CodegenConfig::CodegenConfig(const char* graph_json){
    if (document.Parse(graph_json).HasParseError()){
        throw new std::exception(); // TODO exception to be defined
    }
}

std::string CodegenConfig::GetConfig(std::vector<std::string> configs) {

    int noOfCfgs = configs.size();
    int i = 0;
    int cfgPos = noOfCfgs -1;
    rapidjson::Value& curObj = document;
    while (i < noOfCfgs){
        std::string curCfg = configs[i];
        auto cfgStr = curCfg.c_str();
        if (!curObj.HasMember(cfgStr)){
            return {};
        }

        if (i == cfgPos){
            if(!curObj[cfgStr].IsString()){
                return {};
            }
            return curObj[cfgStr].GetString();
        } else{

            if (!curObj[cfgStr].IsObject()){
               return {};
            }

            curObj = curObj[cfgStr].GetObject();
        }

        i++;
    }

    return {};
}

std::string CodegenConfig::GetConfig(const char* graph_json, std::string tag1, std::string tag2) {
    CodegenConfig cfgHandler = CodegenConfig(graph_json);
    std::vector<std::string> cfg;
    cfg.push_back(tag1);
    cfg.push_back(tag2);
    std::string cfgStr = cfgHandler.GetConfig(cfg);
    if (cfgStr.empty()){
      //TODO: use Logger framework
      return {};
    }

    return cfgStr;
}


}  // namespace contrib
}  // namespace relay
}  // namespace tvm