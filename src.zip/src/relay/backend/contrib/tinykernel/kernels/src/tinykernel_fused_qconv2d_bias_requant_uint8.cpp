/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_fused_qconv2d_bias_requant_uint8.h"
#include <algorithm>
#include <cmath>

#include "utils.h"
#include "quantize.h"

namespace OHOS {
namespace AI {

template <typename T>
void TransposeHWIO2OHWI(const T* in_data, T* out_data,
                        int p_O, int p_H, int p_W, int p_C) {
  int count = 0;
  for (int l = 0; l < p_O; l++) {
    for (int i = 0; i < p_H; i++) {
      for (int j = 0; j < p_W; j++) {
        for (int k = 0; k < p_C; k++) {
          *(out_data+count) = static_cast<T>\
                              (in_data[(l + i*p_O*p_W*p_C) + \
                                       (j*p_C*p_O) + \
                                       (k * p_O)]);
          count++;
        }
      }
    }
  }
}

void DepthConvolutionRequantize(
            uint8_t* data, const uint8_t* weight, const int* input_zero_point,
            const int* weight_zero_point, const float* input_scale,
            const float* weight_scale, const int* bias, const float* bias_scale,
            const int* bias_zero_point, const float* output_scale,
            const int* output_zero_point, uint8_t* out, int batches,
            int input_height, int input_width, int input_depth,
            int output_depth, int groups, int pad_height, int pad_width,
            int filter_height, int filter_width, int stride_height,
            int stride_width, uint32_t multiplier, int shift) {
  int32_t input_offset = -(*input_zero_point);
  int32_t filter_offset = -(*weight_zero_point);
  int32_t output_offset = *output_zero_point;
  int32_t output_multiplier = multiplier;
  int output_shift = shift;
  int dilation_height_factor = 1;
  int dilation_width_factor = 1;
  int32_t output_activation_min = 0;
  int32_t output_activation_max = 255;

  //TODO::Transpose NHWC to NCHW weight, this must move to codegen
  /*int num_elem = output_depth * filter_height * filter_width * input_depth;
  uint8_t* new_data = (uint8_t*)malloc(sizeof(uint8_t) * num_elem);
  TransposeHWIO2OHWI<uint8_t>(weight, new_data, output_depth, filter_height, filter_width, input_depth);
  weight = new_data;*/

  //TODO(SUMAN) - calculation of activation range need to get review
  /*CalcQuantizedActivationRange<uint8_t>(Activations::kTfLiteActRelu, *bias_scale,
                               *bias_zero_point, &output_activation_min,
                               &output_activation_max);*/
  CalcQuantizedActivationRange<uint8_t>(Activations::kTfLiteActRelu, *output_scale,
                               *output_zero_point, &output_activation_min,
                               &output_activation_max);

  output_depth = groups;
  int depth_multiplier = output_depth / input_depth;

  bool enable_padding = false;
  if ((pad_width != 0) || (pad_height != 0)) {
    enable_padding = true;
  }

  int output_height = ComputeOutSize(input_height, filter_height,
                                     stride_height, enable_padding);
  int output_width = ComputeOutSize(input_width, filter_width,
                                    stride_width, enable_padding);

  int offset = 0;
  pad_height =
      ComputePaddingWithOffset(stride_height, 1, input_height,
                               filter_height, output_height, &offset);
  pad_width =
      ComputePaddingWithOffset(stride_width, 1, input_width,
                               filter_width, output_width, &offset);
  for (int b = 0; b < batches; ++b) {
    for (int out_y = 0; out_y < output_height; ++out_y) {
      for (int out_x = 0; out_x < output_width; ++out_x) {
        for (int ic = 0; ic < input_depth; ++ic) {
          for (int m = 0; m < depth_multiplier; m++) {
            const int oc = m + ic * depth_multiplier;
            const int in_x_origin = (out_x * stride_width) - pad_width;
            const int in_y_origin = (out_y * stride_height) - pad_height;
            int32_t acc = 0;
            for (int filter_y = 0; filter_y < filter_height; ++filter_y) {
              for (int filter_x = 0; filter_x < filter_width; ++filter_x) {
                const int in_x =
                    in_x_origin + dilation_width_factor * filter_x;
                const int in_y =
                    in_y_origin + dilation_height_factor * filter_y;
                // If the location is outside the bounds of the input image,
                // use zero as a default value.
                if ((in_x >= 0) && (in_x < input_width) && (in_y >= 0) &&
                    (in_y < input_height)) {
                  int32_t input_val =
                      data[Offset(input_height, input_width, input_depth,
                                  b, in_y, in_x, ic)];
                  int32_t filter_val =
                      weight[Offset(filter_height, filter_width, input_depth,
                                    0, filter_y, filter_x, oc)];
                  acc += (filter_val + filter_offset) *
                         (input_val + input_offset);
                }
              }
            }
            if (bias) {
              acc += bias[oc];
            }
            acc = Requantize(acc, output_multiplier, output_shift);
            acc += output_offset;
            acc = std::max(acc, output_activation_min);
            acc = std::min(acc, output_activation_max);

            out[Offset(output_height, output_width, output_depth,
                       b, out_y, out_x, oc)] = static_cast<uint8_t>(acc);
          }
        }
      }
    }
  }
}

void ConvolutionRequantize(
                uint8_t* data, const uint8_t* weight,
                const int* input_zero_point, const int* weight_zero_point,
                const float* input_scale, const float* weight_scale,
                const int* bias, const float* bias_scale,
                const int* bias_zero_point, const float* output_scale,
                const int* output_zero_point, uint8_t* out, int batches,
                int input_height, int input_width, int input_depth,
                int output_depth, int pad_height, int pad_width,
                int filter_height, int filter_width, int stride_height,
                int stride_width, uint32_t multiplier, int shift) {
  int32_t input_offset = -(*input_zero_point);
  int32_t filter_offset = -(*weight_zero_point);
  int32_t output_offset = *output_zero_point;
  int32_t output_multiplier = multiplier;
  int output_shift = shift;
  int dilation_height_factor = 1;
  int dilation_width_factor = 1;
  int32_t output_activation_min = 0;
  int32_t output_activation_max = 255;

  //TODO::Transpose NHWC to NCHW weight, this must move to codegen
  /*int num_elem = output_depth * filter_height * filter_width * input_depth;
  uint8_t* new_data = (uint8_t*)malloc(sizeof(uint8_t) * num_elem);
  TransposeHWIO2OHWI<uint8_t>(weight, new_data, output_depth, filter_height, filter_width, input_depth);
  weight = new_data;*/

  CalcQuantizedActivationRange<uint8_t>(Activations::kTfLiteActRelu, *bias_scale,
                               *bias_zero_point, &output_activation_min,
                               &output_activation_max);

  bool enable_padding = false;
  if ((pad_width != 0) || (pad_height != 0)) {
    enable_padding = true;
  }

  int output_height = ComputeOutSize(input_height, filter_height,
                                     stride_height, enable_padding);
  int output_width = ComputeOutSize(input_width, filter_width,
                                    stride_width, enable_padding);

  int offset = 0;
  pad_height =
      ComputePaddingWithOffset(stride_height, 1, input_height,
                               filter_height, output_height, &offset);
  pad_width =
      ComputePaddingWithOffset(stride_width, 1, input_width,
                               filter_width, output_width, &offset);

  for (int batch = 0; batch < batches; ++batch) {
    for (int out_y = 0; out_y < output_height; ++out_y) {
      for (int out_x = 0; out_x < output_width; ++out_x) {
        for (int out_channel = 0; out_channel < output_depth; ++out_channel) {
          const int in_x_origin = (out_x * stride_width) - pad_width;
          const int in_y_origin = (out_y * stride_height) - pad_height;
          int32_t acc = 0;
          for (int filter_y = 0; filter_y < filter_height; ++filter_y) {
            for (int filter_x = 0; filter_x < filter_width; ++filter_x) {
              for (int in_channel = 0; in_channel < input_depth; ++in_channel) {
                const int in_x = in_x_origin + dilation_width_factor * filter_x;
                const int in_y =
                    in_y_origin + dilation_height_factor * filter_y;
                // If the location is outside the bounds of the input image,
                // use zero as a default value.
                if ((in_x >= 0) && (in_x < input_width) && (in_y >= 0) &&
                    (in_y < input_height)) {
                  int32_t input_val = data[Offset(input_height, input_width,
                                                  input_depth, batch, in_y,
                                                  in_x, in_channel)];
                  int32_t filter_val =
                      weight[Offset(filter_height, filter_width,
                                    input_depth, out_channel, filter_y,
                                    filter_x, in_channel)];
                  acc +=
                      (filter_val + filter_offset) * (input_val + input_offset);
                }
              }
            }
          }
          if (bias) {
            acc += bias[out_channel];
          }
          acc = Requantize(acc, output_multiplier, output_shift);
          acc += output_offset;
          acc = std::max(acc, output_activation_min);
          acc = std::min(acc, output_activation_max);
          out[Offset(output_height, output_width, output_depth, batch, out_y,
                     out_x, out_channel)] =  static_cast<uint8_t>(acc);
        }
      }
    }
  }
}

/**
 * @brief TinyTVM fused Conv2D kernel with UINT8 quantized input.
 *
 * @param data Input data to be convolved.
 * @param weights filter parameter to convolve over the input data.
 * @param z_I_ Quantized input data zero point.
 * @param z_W_ Quantized filter parameter zero point.
 * @param s_I_ Quantized input data scale.
 * @param s_W_ Quantized filter parameter scale.
 * @param bias Bias data.
 * @param s_NI_ New input scale formed for requantization.
 * @param z_NI_ New input zero point formed for requantization.
 * @param s_O_ Quantized output data scale.
 * @param z_O_ Quantized output data zero point.
 * @param out UINT8 quantized convolution output as an output parameter.
 * @param p_N_ Input data batch size (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channel (part of input shape).
 * @param p_O_ Output channel.
 * @param p_G_ Groups for convolution.
 * @param p_PH_ Input padding height.
 * @param p_PW_ Input padding width.
 * @param p_KH_ Filter parameter height.
 * @Param p_KW_ Filter parameter width.
 * @Param p_SH_ Stride height.
 * @Param p_SW_ Stride Weight.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_fused_qconv2d_bias_requant_uint8(
                        uint8_t* data, const uint8_t* weights, const int* z_I_,
                        const int* z_W_, const float* s_I_, const float* s_W_,
                        const int* bias, const float* s_NI_, const int* z_NI_,
                        const float* s_O_, const int* z_O_, uint8_t* out,
                        int p_N_, int p_H_, int p_W_, int p_C_, int p_O_,
                        int p_G_, int p_PH_, int p_PW_, int p_KH_, int p_KW_,
                        int p_SH_, int p_SW_, void* out_type_code) {
  int32_t per_channel_multiplier[p_O_];
  int  per_channel_shift[p_O_];

  int shift;
  int32_t multiplier;
  CalcQuantizationParams(s_I_[0], s_O_[0], s_W_, p_O_,
                         per_channel_multiplier, per_channel_shift,
                         &multiplier, &shift, false/*per_channel*/);
  shift = -shift;

  // Check for convolution attribute groups
  if (p_G_ == 1) {
    ConvolutionRequantize(data, weights, z_I_, z_W_,
                          s_I_, s_W_, bias, s_NI_,
                          z_NI_, s_O_, z_O_,
                          out, p_N_, p_H_, p_W_, p_C_, p_O_, p_PH_, p_PW_,
                          p_KH_, p_KW_, p_SH_, p_SW_, multiplier, shift);
  } else {
    DepthConvolutionRequantize(data, weights, z_I_, z_W_,
                               s_I_, s_W_, bias, s_NI_,
                               z_NI_, s_O_, z_O_,
                               out, p_N_, p_H_, p_W_, p_C_, p_O_, p_G_, p_PH_, p_PW_,
                               p_KH_, p_KW_, p_SH_, p_SW_, multiplier, shift);
  }
}

}  // namespace AI
}  // namespace OHOS
