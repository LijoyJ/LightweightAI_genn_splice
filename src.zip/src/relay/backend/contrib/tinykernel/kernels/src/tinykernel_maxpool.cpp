/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_maxpool.h"
#include "tinykernel_constants.h"

#include <stdint.h>
#include <cmath>
#include <algorithm>
#include <limits>

#include "utils.h"

namespace OHOS {
namespace AI {

template <typename T>
void MaxPool(T* data, T* out, int batches, int input_height,
             int input_width, int depth, int filter_height, int filter_width,
             int stride_height, int stride_width, int pad_height, int pad_width,
             int activation_min, int activation_max) {
  int dilation_height = 1;
  int dilation_width = 1;
  int output_height = 0;
  int output_width = 0;

  output_height = floor(((input_height + 2 * pad_height -
                          dilation_height * (filter_height - 1) - 1)
                         / stride_height) + 1);
  output_width = floor(((input_width + 2 * pad_width -
                          dilation_width * (filter_width - 1) - 1)
                         / stride_width) + 1);

  //padding calculate from four dimension so divide by 2 is required
  // refer https://github.com/apache/tvm/blob/main/src/relay/op/nn/pooling.cc#L91
  pad_height = floor(pad_height/2);
  pad_width = floor(pad_width/2);

  T* input_data = data;
  T* output_data = out;

  for (int batch = 0; batch < batches; ++batch) {
    for (int out_y = 0; out_y < output_height; ++out_y) {
      for (int out_x = 0; out_x < output_width; ++out_x) {
        for (int channel = 0; channel < depth; ++channel) {
          const int in_x_origin =
              (out_x * stride_width) - pad_width;
          const int in_y_origin =
              (out_y * stride_height) - pad_height;
          // Compute the boundaries of the filter region clamped so as to
          // ensure that the filter window fits in the input array.
          const int filter_x_start = std::max(0, -in_x_origin);
          const int filter_x_end =
              std::min(filter_width, input_width - in_x_origin);
          const int filter_y_start = std::max(0, -in_y_origin);
          const int filter_y_end =
              std::min(filter_height, input_height - in_y_origin);
          //(SUMAN) Change begin
          //TODO(SUMAN) - check this declaration for all types, currently working for uint8 and int8
          //T max = 0;
          T max = std::numeric_limits<T>::lowest();
          //(SUMAN) Change end
          for (int filter_y = filter_y_start; filter_y < filter_y_end;
               ++filter_y) {
            for (int filter_x = filter_x_start; filter_x < filter_x_end;
                 ++filter_x) {
              const int in_x = in_x_origin + filter_x;
              const int in_y = in_y_origin + filter_y;
              max = std::max(
                  max,
                  input_data[Offset(input_height, input_width, depth,
                                    batch, in_y, in_x, channel)]);
            }
          }
          max = std::max<T>(max, activation_min);
          max = std::min<T>(max, activation_max);
          output_data[Offset(output_height, output_width, depth,
                             batch, out_y, out_x, channel)] =
              static_cast<T>(max);
        }
      }
    }
  }
}

/**
 * @brief TinyTVM MaxPool kernel with UINT8 quantized input.
 *
 * @param data UINT8 Input data.
 * @param out UINT8 quantized output parameter.
 * @param p_N_ Input data batch (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channels (part of input shape).
 * @param p_KH_ Filter height.
 * @Param p_KW_ Filter width.
 * @Param p_SH_ Stride height.
 * @Param p_SW_ Stride Weight.
 * @param p_PH_ Input padding height.
 * @param p_PW_ Input padding width.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_maxpool(void* data, void* out, int data_type, int p_N_, int p_H_,
                   int p_W_, int p_C_, int p_KH_, int p_KW_, int p_SH_,
                   int p_SW_, int p_PH_, int p_PW_, void* out_type_code) {
  switch (data_type) {
    case tinyKernelInt:
      return MaxPool<int>((int*)data, (int*)out, p_N_, p_H_, p_W_, p_C_, p_KH_, p_KW_,
          p_SH_, p_SW_, p_PH_, p_PW_, 0, 255);
    case tinyKernelFloat:
      return MaxPool<float>((float*)data, (float*)out, p_N_, p_H_, p_W_, p_C_, p_KH_, p_KW_,
          p_SH_, p_SW_, p_PH_, p_PW_, 0, 255);
    case tinyKernelInt8:
      return MaxPool<int8_t>((int8_t*)data, (int8_t*)out, p_N_, p_H_, p_W_, p_C_, p_KH_, p_KW_,
          p_SH_, p_SW_, p_PH_, p_PW_, -128, 127);
    case tinyKernelUInt8:
      return MaxPool<uint8_t>((uint8_t*)data, (uint8_t*)out, p_N_, p_H_, p_W_, p_C_, p_KH_, p_KW_,
          p_SH_, p_SW_, p_PH_, p_PW_, 0, 255);
  }
}

}  // namespace AI
}  // namespace OHOS
