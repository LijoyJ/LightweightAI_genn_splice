/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_fused_dense_requant.h"
#include "tinykernel_constants.h"
#include <algorithm>
#include <cmath>

#include "utils.h"
#include "quantize.h"

namespace OHOS {
namespace AI {

template <typename T>
void tinykernel_dense_quant_tensor(const T* input_data, const T* filter_data,
                    const int* bias_data, T* output_data,
                    int32_t input_offset, int32_t filter_offset,
                    int32_t output_offset, int32_t output_multiplier,
                    int output_shift, int32_t output_activation_min,
                    int32_t output_activation_max, int output_depth,
                    int accum_depth, int batches) {
  for (int b = 0; b < batches; ++b) {
    for (int out_c = 0; out_c < output_depth; ++out_c) {
      int32_t acc = 0;
      for (int d = 0; d < accum_depth; ++d) {
        int32_t input_val = input_data[b * accum_depth + d];
        int32_t filter_val = filter_data[out_c * accum_depth + d];
        acc += (filter_val + filter_offset) * (input_val + input_offset);
      }
      if (bias_data) {
        acc += bias_data[out_c];
      }
      acc = Requantize(acc, output_multiplier, output_shift);
      acc += output_offset;
      acc = std::max(acc, output_activation_min);
      acc = std::min(acc, output_activation_max);
      output_data[out_c + output_depth * b] = static_cast<T>(acc);
    }
  }
}

/**
 * @brief TinyTVM fused Dense kernel with UINT8 quantized input.
 *
 * @param data UINT8 Input data.
 * @param weights UINT8 filter parameter.
 * @param z_I_ Quantized input data zero point.
 * @param z_W_ Quantized filter parameter zero point.
 * @param s_I_ Quantized input data scale.
 * @param s_W_ Quantized filter parameter scale.
 * @param bias Input bias.
 * @param s_NI_ New input scale formed for requantization.
 * @param z_NI_ New input zero point formed for requantization.
 * @param s_O_ Quantized output data scale.
 * @param z_O_ Quantized output data zero point.
 * @param out UINT8 quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param uinits Number of output features.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_gemm_relu(
                     void* data, const void* weights, const float* bias,
                        const float* s_NI_, const int* z_NI_,
                        const float* s_O_, const int* z_O_, void* out,
                        int data_type, int p_H_, int p_W_, int uinits,
                        void* out_type_code) {
  double input_multiplier = 0.0;
  CalQuantizedMultiplerConv(*s_I_, *s_O_, s_W_, &input_multiplier);

  int exponent;
  int output_shift;
  int32_t output_multiplier;
  CalcQuantizedMultiplier(input_multiplier, &output_multiplier, &exponent);
  output_shift = -exponent;
  int32_t output_activation_min = 0;
  int32_t output_activation_max = 255;

  switch (data_type) {
    case tinyKernelInt8:
      output_activation_min = -128;
      output_activation_max = 127;
      CalcQuantizedActivationRange<int8_t>(Activations::kTfLiteActRelu, *s_O_,
                                   *z_O_, &output_activation_min,
                                   &output_activation_max);
      return tinykernel_dense_quant_tensor<int8_t>((int8_t*)data,
          (int8_t*)weights, bias, (int8_t*)out, -(*z_I_), -(*z_W_), *z_O_,
          output_multiplier, -output_shift, output_activation_min, output_activation_max, uinits, p_W_, p_H_);
    case tinyKernelUInt8:
      // TODO(Albin) :- Dynamically identify the activation range.
      return tinykernel_dense_quant_tensor<uint8_t>((uint8_t*)data,
          (uint8_t*)weights, bias, (uint8_t*)out, -(*z_I_), -(*z_W_), *z_O_,
          output_multiplier, -output_shift, output_activation_min, output_activation_max, uinits, p_W_, p_H_);
  }
}

}  // namespace AI
}  // namespace OHOS
