/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_splice.h"
#include "tinykernel_constants.h"
#include <algorithm>
#include <cmath>

namespace OHOS {
namespace AI {

template <typename T>
void tinykernel_splice_tensor(T* input_data, const int* forward_index, T* output_data, int I_H_, int I_W_, int index_length) {
   T* pout = output_data;
   T* pdata = input_data;
   for(int i=0;i<index_length;i++)
   {
     memcpy((pout+(i*I_W_)),pdata+(forward_index[i]*I_W_),(I_W_*sizeof(T)));
   }
}

/**
 * @brief TinyTVM splice input.
 *
 * @param data Input data.
 * @param forward_index forward_index parameter.
 * @param out quantized output parameter.
 * @param I_H_ Input data height (part of input shape).
 * @param I_W_ Input data width (part of input shape).
 * @Param output_depth Number of output features.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_splice(void* data, const int* forward_index,
                     void* out,int data_type, int channel, int I_H_, int I_W_, int index_length, void* out_type_code) {
  switch (data_type) {
    case tinyKernelFloat:
      return tinykernel_splice_tensor<float>((float*)data,forward_index, (float*)out, I_H_, I_W_, index_length);
  }
}

}  // namespace AI
}  // namespace OHOS
