/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_gemm_relu.h"
#include "tinykernel_constants.h"
#include <algorithm>
#include <cmath>
namespace OHOS {
namespace AI {

template <typename T>
void tinykernel_gemm_relu_tensor( T* input_data, T* weights,
                    float* bias, T* output_data, int I_H_, int I_W_, int output_depth) {
  T* pout = output_data;
  T* pdata = input_data;
  T* pweights = weights;

  for (int b = 0; b < I_H_; ++b) {
    for (int out_c = 0; out_c < output_depth; ++out_c) {
      float total = 0.f;
      for (int d = 0; d < I_W_; ++d) {
        total += pdata[b * I_W_ + d] * pweights[out_c * I_W_ + d];
      }
      float bias_value = 0.0f;
      if (bias) {
        bias_value = bias[out_c];
      }
      total = total + bias_value;
      pout[out_c+ output_depth * b] = std::max(total, 0.f);
    }
  }
}

/**
 * @brief TinyTVM fused gemm relu input.
 *
 * @param data Input data.
 * @param weights filter parameter.
 * @param bias Input bias.
 * @param out quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param output_depth Number of output features.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_gemm_relu(void* data, const void* weights, const float* bias,
                     void* out,int data_type, int I_H_, int I_W_, int output_depth, void* out_type_code) {
  switch (data_type) {
    case tinyKernelFloat:
      return tinykernel_gemm_relu_tensor<float>((float*)data,(float*)weights,(float*) bias, (float*)out, I_H_, I_W_, output_depth);
  }
}

}  // namespace AI
}  // namespace OHOS
