/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_UTILS_H
#define AI_RUNTIME_LITE_UTILS_H

#include <stdint.h>

using namespace std;

namespace OHOS {
namespace AI {

static int Offset(int dim1, int dim2, int dim3, int i0, int i1, int i2, int i3) {
  return ((i0 * dim1 + i1) * dim2 + i2) * dim3 + i3;
}

// Matching GetWindowedOutputSize in TensorFlow.
static int ComputeOutSize(int image_size, int filter_size, int stride,
                          bool enable_padding, int dilation_rate = 1) {
  int out_size = 0;
  int effective_filter_size = (filter_size - 1) * dilation_rate + 1;

  // SAME
  if (enable_padding) {
    out_size = (image_size + stride - 1) / stride;
  } else {
  // VALID
    out_size = (image_size + stride - effective_filter_size) / stride;
  }

  return out_size;
}

static int ComputePaddingWithOffset(int stride, int dilation_rate, int in_size,
                                    int filter_size, int out_size,
                                    int* offset) {
  int effective_filter_size = (filter_size - 1) * dilation_rate + 1;
  int total_padding =
      ((out_size - 1) * stride + effective_filter_size - in_size);
  total_padding = total_padding > 0 ? total_padding : 0;
  *offset = total_padding % 2;
  return total_padding / 2;
}

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_UTILS_H
