/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_reshape.h"
#include "tinykernel_constants.h"

#include <stdint.h>
#include <cmath>
#include <algorithm>
#include <limits>

namespace OHOS {
namespace AI {

template <typename T> void
tinykernel_reshape_tensor(T* data, T* out, int num_elem) {
  if (out != data) {
    memcpy(out, data, sizeof(T) * num_elem);
  }
}

/**
 * @brief TinyTVM Reshape kernel with UINT8 quantized input.
 *
 * @param data UINT8 Input data.
 * @param out UINT8 quantized output parameter.
 * @param p_N_ Input data batches (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channels (part of input shape).
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_reshape(void* data, void* out, int data_type, int p_N_, int p_H_,
                   int p_W_, int p_C_, void* out_type_code) {
  int num_elem = p_N_ * p_H_ * p_W_ * p_C_;

  switch (data_type) {
    case tinyKernelInt:
      return tinykernel_reshape_tensor<int>((int*)data, (int*)out, num_elem);
    case tinyKernelFloat:
      return tinykernel_reshape_tensor<float>((float*)data, (float*)out, num_elem);
    case tinyKernelInt8:
      return tinykernel_reshape_tensor<int8_t>((int8_t*)data, (int8_t*)out, num_elem);
    case tinyKernelUInt8:
      return tinykernel_reshape_tensor<uint8_t>((uint8_t*)data, (uint8_t*)out, num_elem);
  }
}

}  // namespace AI
}  // namespace OHOS
