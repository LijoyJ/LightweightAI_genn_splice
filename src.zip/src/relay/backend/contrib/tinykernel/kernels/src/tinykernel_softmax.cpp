/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_softmax.h"
#include "tinykernel_constants.h"

#include <stdint.h>
#include <cmath>
#include <algorithm>
#include <limits>

namespace OHOS {
namespace AI {

template <typename T>
void tinykernel_softmax_tensor(T* data, T* out, int p_H_, int p_W_) {
  // TODO(Lijoy) :- To be read from the Softmax attribute
  int beta = 1;

  const int outer_size = 1;
  const int depth = p_W_;
  for (int i = 0; i < outer_size; ++i) {
    T max = std::numeric_limits<T>::lowest();
    for (int c = 0; c < depth; ++c) {
      max = std::max(max, data[i * depth + c]);
    }

    // Compute sum.
    T sum = 0;
    for (int c = 0; c < depth; ++c) {
      sum += std::exp((data[i * depth + c] - max) *
                      static_cast<T>(beta));
    }

    // Compute result.
    for (int c = 0; c < depth; ++c) {
      out[i * depth + c] = std::exp((data[i * depth + c] - max) *
                                    static_cast<T>(beta)) / sum;
    }
  }
}

/**
 * @brief TinyTVM Softmax kernel with non-quantized input.
 *
 * @param data Input data.
 * @param out Non-quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_softmax(void* data, void* out, int data_type, int p_H_, int p_W_, void* out_type_code) {
  switch (data_type) {
    case tinyKernelInt:
      return tinykernel_softmax_tensor<int>((int*)data, (int*)out, p_H_, p_W_);
    case tinyKernelFloat:
      return tinykernel_softmax_tensor<float>((float*)data, (float*)out, p_H_, p_W_);
  }
}

}  // namespace AI
}  // namespace OHOS
