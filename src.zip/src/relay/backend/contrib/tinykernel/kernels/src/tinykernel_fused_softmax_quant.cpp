/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_fused_softmax_quant.h"
#include "tinykernel_constants.h"
#include "fixedpoint.h"
#include "utils.h"
#include "quantize.h"

namespace OHOS {
namespace AI {

static int32_t MultiplyByQuantizedMultiplierGreaterThanOne(
    int32_t x, int32_t quantized_multiplier, int left_shift) {
  return SatDoublingHighMult(x * (1 << left_shift),
                             quantized_multiplier);
}

template <typename T>
int CountLeadingZeros(T integer_input) {
  static_assert(std::is_unsigned<T>::value,
                "Only unsigned integer types handled.");
#if defined(__GNUC__)
  return integer_input ? __builtin_clz(integer_input)
                       : std::numeric_limits<T>::digits;
#else
  if (integer_input == 0) {
    return std::numeric_limits<T>::digits;
  }

  const T one_in_leading_positive = static_cast<T>(1)
                                    << (std::numeric_limits<T>::digits - 1);
  int leading_zeros = 0;
  while (integer_input < one_in_leading_positive) {
    integer_input <<= 1;
    ++leading_zeros;
  }
  return leading_zeros;
#endif
}

int32_t GetReciprocal(int32_t x, int x_integer_digits,
                             int* num_bits_over_unit) {
  int headroom_plus_one = CountLeadingZeros(static_cast<uint32_t>(x));
  // This is the number of bits to the left of the binary point above 1.0.
  // Consider x=1.25.  In that case shifted_scale=0.8 and
  // no later adjustment will be needed.
  *num_bits_over_unit = x_integer_digits - headroom_plus_one;
  const int32_t shifted_sum_minus_one =
      static_cast<int32_t>((static_cast<uint32_t>(x) << headroom_plus_one) -
                           (static_cast<uint32_t>(1) << 31));

  gemmlowp::FixedPoint<int32_t, 0> shifted_scale =
      gemmlowp::one_over_one_plus_x_for_x_in_0_1(
          gemmlowp::FixedPoint<int32_t, 0>::FromRaw(shifted_sum_minus_one));
  return shifted_scale.raw();
}

void PreprocessSoftmaxScaling(double beta, double input_scale,
                              int input_integer_bits,
                              int32_t* quantized_multiplier, int* left_shift) {
  //TODO:- Eliminate FLOAT operation to be done
  const double input_beta_real_multiplier = std::min<double>(
      beta * input_scale * (1 << (31 - input_integer_bits)), (1ll << 31) - 1.0);

 CalcQuantizedMultiplier(input_beta_real_multiplier,
                                   quantized_multiplier, left_shift);
}

int CalculateInputRadius(int input_integer_bits, int input_left_shift,
                         int total_signed_bits) {
  int64_t result = (1 << input_integer_bits) - 1;
  result <<= (total_signed_bits - input_integer_bits);
  result >>= input_left_shift;
  return result;
  const double max_input_rescaled =
      1.0 * ((1 << input_integer_bits) - 1) *
      (1ll << (total_signed_bits - input_integer_bits)) /
      (1ll << input_left_shift);
  return static_cast<int>(std::floor(max_input_rescaled));
}

template <typename T>
void tinykernel_softmax_quant_tensor(T* input_data, const float* p_Is_, const int* p_Iz_,
                        const float* p_Os_, const int* p_Oz_,T* output_data,
                        int p_H_, int p_W_, void* out_type_code) {
  vector<int> shape{p_H_, p_W_};
  //TODO:- To be read from the Softmax attribute
  int beta = 1;

  static const int kScaledDiffIntegerBits = 5;
  int32_t input_left_shift;
  int32_t input_multiplier;
  PreprocessSoftmaxScaling(
      static_cast<double>(beta),
      static_cast<double>(*p_Is_), kScaledDiffIntegerBits,
      &input_multiplier, &input_left_shift);
  int32_t diff_min =
      -1.0 * CalculateInputRadius(kScaledDiffIntegerBits,
                                          input_left_shift,32);
  const int32_t input_beta_multiplier = input_multiplier;
  const int32_t input_beta_left_shift = input_left_shift;
  //const int diff_min = diff_min;
  // The representation chosen for the input to the exp() function is Q5.26.
  // We need to leave extra space since values that we skip might be as large as
  // -32 before multiplying by input_beta_multiplier, and therefore as large as
  // -16 afterwards.  Note that exp(-8) is definitely not insignificant to
  // accumulation, but exp(-16) definitely is.
  static const int kAccumulationIntegerBits = 12;
  using FixedPointScaledDiff =
      gemmlowp::FixedPoint<int32_t, kScaledDiffIntegerBits>;
  using FixedPointAccum = gemmlowp::FixedPoint<int32_t, kAccumulationIntegerBits>;
  using FixedPoint0 = gemmlowp::FixedPoint<int32_t, 0>;

  const int outer_size = p_H_;
  const int depth = p_W_;


  for (int i = 0; i < outer_size; ++i) {
    T max_in_row = std::numeric_limits<T>::min();
    for (int c = 0; c < depth; ++c) {
      max_in_row = std::max(max_in_row, input_data[i * depth + c]);
    }

    FixedPointAccum sum_of_exps = FixedPointAccum::Zero();
    for (int c = 0; c < depth; ++c) {
      int32_t input_diff =
          static_cast<int32_t>(input_data[i * depth + c]) - max_in_row;
      if (input_diff >= diff_min) {
        const int32_t input_diff_rescaled =
            MultiplyByQuantizedMultiplierGreaterThanOne(
                input_diff, input_beta_multiplier, input_beta_left_shift);
        const FixedPointScaledDiff scaled_diff_f8 =
            FixedPointScaledDiff::FromRaw(input_diff_rescaled);
        sum_of_exps = sum_of_exps + gemmlowp::Rescale<kAccumulationIntegerBits>(
                                        exp_on_negative_values(scaled_diff_f8));
      }
    }

    int num_bits_over_unit;
    FixedPoint0 shifted_scale = FixedPoint0::FromRaw(GetReciprocal(
        sum_of_exps.raw(), kAccumulationIntegerBits, &num_bits_over_unit));

    for (int c = 0; c < depth; ++c) {
      int32_t input_diff =
          static_cast<int32_t>(input_data[i * depth + c]) - max_in_row;
      if (input_diff >= diff_min) {
        const int input_diff_rescaled =
            MultiplyByQuantizedMultiplierGreaterThanOne(
                input_diff, input_beta_multiplier, input_beta_left_shift);
        const FixedPointScaledDiff scaled_diff_f8 =
            FixedPointScaledDiff::FromRaw(input_diff_rescaled);

        FixedPoint0 exp_in_0 = exp_on_negative_values(scaled_diff_f8);
        int unsat_output = gemmlowp::RoundingDivideByPOT(
            (shifted_scale * exp_in_0).raw(),
            num_bits_over_unit + 31 - (sizeof(T) * 8));

        const int shifted_output =
            unsat_output +
            static_cast<int32_t>(std::numeric_limits<T>::min());

        output_data[i * depth + c] = static_cast<T>(std::max(
            std::min(shifted_output,
                     static_cast<int32_t>(std::numeric_limits<T>::max())),
            static_cast<int32_t>(std::numeric_limits<T>::min())));
      } else {
        output_data[i * depth + c] = std::numeric_limits<T>::min();
      }
    }
  }
}

extern "C" void
tinykernel_fused_softmax_quant(
                        void* data, const float* p_Is_, const int* p_Iz_,
                        const float* p_Os_, const int* p_Oz_, void* out,
                        int data_type, int p_H_, int p_W_, void* out_type_code) {
  switch (data_type) {
    case tinyKernelInt8:
      return tinykernel_softmax_quant_tensor<int8_t>((int8_t*)data, p_Is_,
              p_Iz_, p_Os_, p_Oz_, (int8_t*)out, p_H_, p_W_,out_type_code);
    case tinyKernelUInt8:
      return tinykernel_softmax_quant_tensor<uint8_t>((uint8_t*)data, p_Is_,
              p_Iz_, p_Os_, p_Oz_, (uint8_t*)out, p_H_, p_W_,out_type_code);
  }
}

}  // namespace AI
}  // namespace OHOS
