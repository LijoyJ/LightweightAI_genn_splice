/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_quantize.h"
#include "tinykernel_constants.h"

#include <vector>
#include <limits>
#include <cmath>

namespace OHOS {
namespace AI {

template <typename T>
void Quantize(float* data, const float* p_Os_, const int* p_Oz_,
              T* out, const vector<int> &shape) {
  // TODO
  /*As of now considered only two dim, Consider different dimensions as well
   */
  const int32_t min = std::numeric_limits<T>::min();
  const int32_t max = std::numeric_limits<T>::max();
  for (int b = 0; b < shape[0]; b++) {
    for (int d = 0; d < shape[1]; d++) {
      int idx = b*shape[1] + d;
      data[idx] = data[idx] / *p_Os_;
      data[idx] = std::round(data[idx] + static_cast<float>(*p_Oz_));
      int32_t in_data = static_cast<int32_t>(data[idx]);
      int32_t a_min = std::min(in_data, (int32_t)min);
      int32_t a_max = std::max(in_data, (int32_t)max);
      out[idx] =
          static_cast<T>(std::max(std::min(in_data, a_max), a_min));
    }
  }
}

/**
 * @brief TinyTVM Quantize kernel with non-quantized input.
 *
 * Quantize the input data to a UINT8 quantized format.
 *
 * @param data Input data.
 * @param s_O_ Quantized output data scale.
 * @param z_O_ Quantized output data zero point.
 * @param out UINT8 quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_quantize(float* data, const float* s_O_, const int* z_O_,
                    void* out, int data_type, int p_H_, int p_W_, void* out_type_code) {
  vector<int> shape{p_H_, p_W_};
  switch (data_type) {
    case tinyKernelInt8:
      return Quantize<int8_t>(data, s_O_, z_O_, (int8_t*)out, shape);
    case tinyKernelUInt8:
      return Quantize<uint8_t>(data, s_O_, z_O_, (uint8_t*)out, shape);
  }
}

}  // namespace AI
}  // namespace OHOS
