/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_QUANTIZE_H
#define AI_RUNTIME_LITE_QUANTIZE_H

#include <stdint.h>
#include <cmath>
#include <algorithm>
#include <limits>
#include <vector>

using namespace std;

namespace OHOS {
namespace AI {

#ifndef MAX
#define MAX(A, B) (A) < (B) ? (B) : (A)
#endif
#define MIN(A, B) ((A) < (B) ? (A) : (B))

#define Q32_MAX   ((int32_t)(0x7FFFFFFFL))
#define Q32_MIN   ((int32_t)(0x80000000L))

#define LEFT_SHIFT(_shift)  (_shift > 0 ? _shift : 0)
#define RIGHT_SHIFT(_shift) (_shift > 0 ? 0 : -_shift)

const uint64_t g_SignMask = 0x8000000000000000LL;
const uint64_t g_ExponentMask = 0x7ff0000000000000LL;
const int32_t g_ExponentShift = 52;
const int32_t g_ExponentBias = 1023;
const uint32_t g_ExponentIsBadNum = 0x7ff;
const uint64_t g_FractionMask = 0x000fffffffc00000LL;
const uint32_t g_FractionShift = 22;
const uint32_t g_FractionRoundingMask = 0x003fffff;
const uint32_t g_FractionRoundingThreshold = 0x00200000;

typedef enum {
  kTfLiteActRelu,
} Activations;

static int64_t IntegerFixed(double input, int* shift) {
  union {
    double double_value;
    uint64_t double_as_uint;
  } cast_union;
  cast_union.double_value = input;
  const uint64_t u = cast_union.double_as_uint;

  if ((u & ~g_SignMask) == 0) {
    *shift = 0;
    return 0;
  }

  const uint32_t exponent_part = ((u & g_ExponentMask) >> g_ExponentShift);
  if (exponent_part == g_ExponentIsBadNum) {
    *shift = std::numeric_limits<int>::max();
    if (u & g_FractionMask) {
      return 0;
    } else {
      if (u & g_SignMask) {
        return std::numeric_limits<int64_t>::min();
      } else {
        return std::numeric_limits<int64_t>::max();
      }
    }
  }
  *shift = (exponent_part - g_ExponentBias) + 1;

  int64_t fraction = 0x40000000 + ((u & g_FractionMask) >> g_FractionShift);

  if ((u & g_FractionRoundingMask) > g_FractionRoundingThreshold) {
    fraction += 1;
  }

  if (u & g_SignMask) {
    fraction *= -1;
  }

  return fraction;
}

static void CalcQuantizedMultiplier(double input_multiplier,
                             int32_t* quantized_multiplier, int* shift) {
  if (input_multiplier == 0.) {
    *quantized_multiplier = 0;
    *shift = 0;
    return;
  }
  int64_t q_fixed = IntegerFixed(input_multiplier, shift);
  if (q_fixed == (1ll << 31)) {
    q_fixed /= 2;
    ++*shift;
  }

  if (*shift < -31) {
    *shift = 0;
    q_fixed = 0;
  }
  *quantized_multiplier = static_cast<int32_t>(q_fixed);
}

static void CalQuantizedMultiplerConv(float input_scale, float output_scale,
                               const float* filter_scale,
                               double* multiplier) {
  const double input_product_scale =
      static_cast<double>(input_scale * (*filter_scale));
  *multiplier = input_product_scale / static_cast<double>(output_scale);
}

static void CalcQuantizationParams(float input_scale, float output_scale,
                            const float* filter_scales, int num_channels,
                            int32_t* per_channel_multiplier,
                            int32_t* per_channel_shift, int32_t* multiplier,
                            int* shift, bool is_per_channel) {
  for (int i = 0; i < num_channels; i++) {
    const float scale = is_per_channel ? filter_scales[i] : filter_scales[0];
    const double filter_scale = static_cast<double>(scale);
    double effective_output_scale = static_cast<double>(input_scale) *
                                    filter_scale /
                                    static_cast<double>(output_scale);

    int32_t significand;
    int32_t channel_shift;
    CalcQuantizedMultiplier(effective_output_scale,
                            &significand, &channel_shift);
    per_channel_multiplier[i] = significand;
    per_channel_shift[i] = channel_shift;
  }

  if (!is_per_channel) {
    double input_multiplier = 0.0;
    CalQuantizedMultiplerConv(input_scale, output_scale,
                              filter_scales, &input_multiplier);

    int exponent;
    CalcQuantizedMultiplier(input_multiplier, multiplier, &exponent);
    *shift = -exponent;
  }
}

/*static void CalcQuantizedMultiplierSoftMax(double input_multiplier,
                                    int32_t* quantized_multiplier,
                                    int* left_shift) {
  CalcQuantizedMultiplier(input_multiplier, quantized_multiplier, left_shift);
}*/

/*static void Quantize(float* data, const float* p_Os_, const int* p_Oz_,
              uint8_t* out, const vector<int> &shape) {
  // TODO(Albin)
  //As of now considered only two dim, Consider different dimensions as well
  const int32_t min = std::numeric_limits<uint8_t>::min();
  const int32_t max = std::numeric_limits<uint8_t>::max();
  for (int b = 0; b < shape[0]; b++) {
    for (int d = 0; d < shape[1]; d++) {
      int idx = b*shape[1] + d;
      data[idx] = data[idx] / *p_Os_;
      data[idx] = std::round(data[idx] + static_cast<float>(*p_Oz_));
      int32_t in_data = static_cast<int32_t>(data[idx]);
      int32_t a_min = std::min(in_data, (int32_t)min);
      int32_t a_max = std::max(in_data, (int32_t)max);
      out[idx] =
          static_cast<uint8_t>(std::max(std::min(in_data, a_max), a_min));
    }
  }
}*/

/*static void DequantizeUint8(uint8_t* data, const float* p_Is_, const int* p_Iz_,
                     float* out, const vector<int> &shape) {
  for (int b = 0; b < shape[0]; b++) {
    for (int d = 0; d < shape[1]; d++) {
      int idx = b*shape[1] + d;
      int32_t in_data = static_cast<int32_t>(data[idx]);
      auto shift = in_data - *p_Iz_;
      out[idx] = (static_cast<float>(shift)) * (*p_Is_);
    }
  }
}*/

static void CalcQuantizedActivationRangeImpl(Activations activation, int32_t qmin,
                                      int32_t qmax, float scale, int zero_point,
                                      int32_t* act_min, int32_t* act_max) {
  auto quantize = [scale, zero_point](float f) {
    return zero_point + static_cast<int32_t>(std::round(f / scale));
  };

  if (activation == kTfLiteActRelu) {
    *act_min = std::max(qmin, quantize(0.0));
    *act_max = qmax;
  } else {
    *act_min = qmin;
    *act_max = qmax;
  }
}

template <typename T>
static void CalcQuantizedActivationRange(Activations activation,
                                  float scale, int zero_point,
                                  int32_t* act_min, int32_t* act_max) {
  int32_t qmin = std::numeric_limits<T>::min();
  int32_t qmax = std::numeric_limits<T>::max();
  CalcQuantizedActivationRangeImpl(activation, qmin, qmax, scale,
                                   zero_point, act_min, act_max);
}

static int32_t DivideByPowerOf2(const int32_t dividend,
                                const int32_t exponent) {
    int32_t result = 0;
    const int32_t remainder_mask = (1l << exponent) - 1;
    int32_t remainder = remainder_mask & dividend;

    // Basic division
    result = dividend >> exponent;

    // Adjust 'result' for rounding (mid point away from zero)
    int32_t threshold = remainder_mask >> 1;
    if (result < 0) {
        threshold++;
    }

    if (remainder > threshold) {
        result++;
    }

    return result;
}

static int32_t SatDoublingHighMult(const int32_t m1, const int32_t m2) {
    int32_t result = 0;
    int64_t mult = 1 << 30;

    if ((m1 < 0) ^ (m2 < 0)) {
        mult = 1 - mult;
    }

    mult = mult + (int64_t)m1 * m2;

    result = mult / (1UL << 31);

    if ((m1 == m2) && (m1 == (int32_t)Q32_MIN)) {
        result = Q32_MAX;
    }
    return result;
}


static int32_t Requantize(const int32_t val,
                   const int32_t multiplier, const int32_t shift) {
  return DivideByPowerOf2(
             SatDoublingHighMult(val * (1 << LEFT_SHIFT(shift)), multiplier),
                                 RIGHT_SHIFT(shift));
}

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_QUANTIZE_H
