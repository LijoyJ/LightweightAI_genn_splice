/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_cast.h"
#include "tinykernel_constants.h"

#include <stdint.h>
#include <cmath>
#include <algorithm>
#include <limits>

namespace OHOS {
namespace AI {

template <typename FromT, typename ToT> void
tinykernel_copy_cast(FromT* data, ToT* out, int num_elem) {
  for (int elm = 0; elm < num_elem; elm++) {
    *(out+elm) = static_cast<ToT>(*(data+elm));
  }
}

template <typename FromT> void
tinykernel_copy_tensor(FromT* data, void* out, int dest_data_type, int num_elem) {
  switch (dest_data_type) {
    case tinyKernelInt:
      return tinykernel_copy_cast(data, (int*)out, num_elem);
    case tinyKernelFloat:
      return tinykernel_copy_cast(data, (float*)out, num_elem);
    case tinyKernelInt8:
      return tinykernel_copy_cast(data, (int8_t*)out, num_elem);
    case tinyKernelUInt8:
      return tinykernel_copy_cast(data, (uint8_t*)out, num_elem);
  }
}

/**
 * @brief TinyTVM Cast kernel with UINT8 quantized input.
 *
 * Cast the input data to INT
 *
 * @param data UINT8 Input data.
 * @param out INT quantized output parameter.
 * @param p_N_ Input data batch (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channels (part of input shape).
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_cast(void* data, void* out, int src_data_type, int dest_data_type,
                int p_N_, int p_H_, int p_W_, int p_C_, void* out_type_code) {
  int num_elem = p_N_ * p_H_ * p_W_ * p_C_;

  switch (src_data_type) {
    case tinyKernelInt:
      return tinykernel_copy_tensor<int>((int*)data, out, dest_data_type, num_elem);
    case tinyKernelFloat:
      return tinykernel_copy_tensor<float>((float*)data, out, dest_data_type, num_elem);
    case tinyKernelInt8:
      return tinykernel_copy_tensor<int8_t>((int8_t*)data, out, dest_data_type, num_elem);
    case tinyKernelUInt8:
      return tinykernel_copy_tensor<uint8_t>((uint8_t*)data, out, dest_data_type, num_elem);
  }
}

}  // namespace AI
}  // namespace OHOS
