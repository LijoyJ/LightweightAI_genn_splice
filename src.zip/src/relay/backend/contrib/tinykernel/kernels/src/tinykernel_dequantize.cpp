/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_dequantize.h"
#include "tinykernel_constants.h"

#include <vector>

namespace OHOS {
namespace AI {

template <typename T> void
Dequantize(T* data, const float* p_Is_, const int* p_Iz_,
                     float* out, const vector<int> &shape) {
  for (int b = 0; b < shape[0]; b++) {
    for (int d = 0; d < shape[1]; d++) {
      int idx = b*shape[1] + d;
      int32_t in_data = static_cast<int32_t>(data[idx]);
      auto shift = in_data - *p_Iz_;
      out[idx] = (static_cast<float>(shift)) * (*p_Is_);
    }
  }
}

/**
 * @brief TinyTVM Dequantize kernel with UINT8 quantized input.
 *
 * Dequantize the input data to a non-quantized format.
 *
 * @param data Input data.
 * @param s_I_ Quantized input data scale.
 * @param z_I_ Quantized input data zero point.
 * @param out Non-quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_dequantize(void* data, const float* s_I_,
                            const int* z_I_, float* out, int data_type, int p_H_,
                            int p_W_, void* out_type_code) {
  vector<int> shape{p_H_, p_W_};

  switch (data_type) {
    case tinyKernelInt:
      return Dequantize<int>((int*)data, s_I_, z_I_, out, shape);
    case tinyKernelFloat:
      return Dequantize<float>((float*)data, s_I_, z_I_, out, shape);
    case tinyKernelInt8:
      return Dequantize<int8_t>((int8_t*)data, s_I_, z_I_, out, shape);
    case tinyKernelUInt8:
      return Dequantize<uint8_t>((uint8_t*)data, s_I_, z_I_, out, shape);
  }
}

}  // namespace AI
}  // namespace OHOS
