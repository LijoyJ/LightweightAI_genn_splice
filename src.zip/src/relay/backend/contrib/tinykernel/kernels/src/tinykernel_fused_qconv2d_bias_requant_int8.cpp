/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "tinykernel/tinykernel_fused_qconv2d_bias_requant_int8.h"
#include <algorithm>
#include <cmath>

#include "utils.h"
#include "quantize.h"

namespace OHOS {
namespace AI {

void conv2d_perchannel(
    int8_t* layerinput, int in_h, int in_w, int in_dpth, const int* in_offst,
    const int8_t* kernel_data, int krnl_h, int krnl_w, int8_t* output_data,
    int out_dpth, const int* out_offst, const float* out_scale,
    const int32_t* bias, int stride_height, int stride_width, int pad_h,
    int pad_w, int batches, int32_t* out_multiplier, int32_t* out_shift) {

  // Get parameters.
  const int32_t input_offset = -(*in_offst);

  int pad_width = pad_w;
  int pad_height = pad_h;
  const int32_t output_offset = *out_offst;

  // Set min and max value of the output.
  int32_t output_activation_min = -128;
  int32_t output_activation_max = 127;

  CalcQuantizedActivationRange<int8_t>(Activations::kTfLiteActRelu, *out_scale,
                               *out_offst, &output_activation_min,
                               &output_activation_max);  

  bool enable_padding = false;
  if ((pad_w != 0) || (pad_h != 0)) {
    enable_padding = true;
  }

  int dilation_height_factor = 1;
  int dilation_width_factor = 1;

  int output_height = ComputeOutSize(in_h, krnl_h,
                                     stride_height, enable_padding);
  int output_width = ComputeOutSize(in_w, krnl_w,
                                    stride_width, enable_padding);

  //const int batches = batches;
  const int input_depth = in_dpth;
  const int output_depth = out_dpth;

  // Check dimensions of the tensors.
  const int input_height = in_h;
  const int input_width = in_w;
  const int filter_height = krnl_h;
  const int filter_width = krnl_w;

  int offset = 0;
  pad_height =
      ComputePaddingWithOffset(stride_height, 1, input_height,
                               filter_height, output_height, &offset);
  pad_width =
      ComputePaddingWithOffset(stride_width, 1, input_width,
                               filter_width, output_width, &offset);

  const int8_t* input_data = layerinput;
  const int8_t* filter_data = kernel_data;
  //int8_t* output_data = layerout_data;
  for (int batch = 0; batch < batches; ++batch) {
    for (int out_y = 0; out_y < output_height; ++out_y) {
      const int in_y_origin = (out_y * stride_height) - pad_height;
      for (int out_x = 0; out_x < output_width; ++out_x) {
        const int in_x_origin = (out_x * stride_width) - pad_width;
        for (int out_channel = 0; out_channel < output_depth; ++out_channel) {
          int32_t acc = 0;
          for (int filter_y = 0; filter_y < filter_height; ++filter_y) {
            const int in_y = in_y_origin + dilation_height_factor * filter_y;
            for (int filter_x = 0; filter_x < filter_width; ++filter_x) {
              const int in_x = in_x_origin + dilation_width_factor * filter_x;

              // Zero padding by omitting the areas outside the image.
              const bool is_point_inside_image =
                  (in_x >= 0) && (in_x < input_width) && (in_y >= 0) && (in_y < input_height);

              if (!is_point_inside_image) {
                continue;
              }

              for (int in_channel = 0; in_channel < input_depth; ++in_channel) {

                int32_t input_val = input_data[Offset(input_height, input_width,
                                                input_depth, batch, in_y,
                                                in_x, in_channel)];
                int32_t filter_val = filter_data[Offset(filter_height, filter_width,
                                                input_depth, out_channel, filter_y,
                                                filter_x, in_channel)];

                // Accumulate with 32 bits accumulator.
                // In the nudging process during model quantization, we force
                // real value of 0.0 be represented by a quantized value. This
                // guarantees that the input_offset is a int8_t, even though
                // it is represented using int32_t. int32_t += int8_t *
                // (int8_t - int8_t) so the highest value we can get from each
                // accumulation is [-127, 127] * ([-128, 127] -
                // [-128, 127]), which is [-32512, 32512]. log2(32512)
                // = 14.98, which means we can accumulate at least 2^16
                // multiplications without overflow. The accumulator is
                // applied to a filter so the accumulation logic will hold as
                // long as the filter size (filter_y * filter_x * in_channel)
                // does not exceed 2^16, which is the case in all the models
                // we have seen so far.
                // TODO(b/174275578): Add a check to make sure the
                // accumulator depth is smaller than 2^16.
                acc += filter_val * (input_val + input_offset);
              }
            }
          }

          if (bias) {
            acc += bias[out_channel];
          }
          //acc = MultiplyByQuantizedMultiplier(
          //    acc, output_multiplier[out_channel], output_shift[out_channel]);
          acc = Requantize(acc, out_multiplier[out_channel], out_shift[out_channel]);
          acc += output_offset;
          acc = std::max(acc, output_activation_min);
          acc = std::min(acc, output_activation_max);
          output_data[Offset(output_height, output_width, output_depth, batch, out_y,
                          out_x, out_channel)] = static_cast<int8_t>(acc);
        }
      }
    }
  }
}

/**
 * @brief TinyTVM fused Conv2D kernel with UINT8 quantized input.
 *
 * @param data Input data to be convolved.
 * @param weights filter parameter to convolve over the input data.
 * @param z_I_ Quantized input data zero point.
 * @param z_W_ Quantized filter parameter zero point.
 * @param s_I_ Quantized input data scale.
 * @param s_W_ Quantized filter parameter scale.
 * @param bias Bias data.
 * @param s_NI_ New input scale formed for requantization.
 * @param z_NI_ New input zero point formed for requantization.
 * @param s_O_ Quantized output data scale.
 * @param z_O_ Quantized output data zero point.
 * @param out UINT8 quantized convolution output as an output parameter.
 * @param p_N_ Input data batch size (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channel (part of input shape).
 * @param p_O_ Output channel.
 * @param p_G_ Groups for convolution.
 * @param p_PH_ Input padding height.
 * @param p_PW_ Input padding width.
 * @param p_KH_ Filter parameter height.
 * @Param p_KW_ Filter parameter width.
 * @Param p_SH_ Stride height.
 * @Param p_SW_ Stride Weight.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_fused_qconv2d_bias_requant_int8(
                        int8_t* data, const int8_t* weights, const int* z_I_,
                        const int* z_W_, const float* s_I_, const float* s_W_,
                        const int* bias, const float* s_NI_, const int* z_NI_,
                        const float* s_O_, const int* z_O_, int8_t* out,
                        int p_N_, int p_H_, int p_W_, int p_C_, int p_O_,
                        int p_G_, int p_PH_, int p_PW_, int p_KH_, int p_KW_,
                        int p_SH_, int p_SW_, void* out_type_code) {
  int32_t per_channel_multiplier[p_O_];
  int32_t per_channel_shift[p_O_];
  int32_t multiplier;
  int shift;

  CalcQuantizationParams(s_I_[0], s_O_[0], s_W_, p_O_,
                         per_channel_multiplier, per_channel_shift,
                         &multiplier, &shift, true/*per_channel*/);
  //TODO(Lijoy)::TVM conv and depthwiseconv both will same interface,
  // solution need to support here
  conv2d_perchannel(data, p_H_, p_W_, p_C_, z_I_, weights, p_KH_, p_KW_, out,
                    p_O_, z_O_, s_O_, bias, p_SH_, p_SW_, p_PH_, p_PW_, p_N_,
                    per_channel_multiplier, per_channel_shift);
}

}  // namespace AI
}  // namespace OHOS
