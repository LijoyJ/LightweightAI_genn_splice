/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_TINY_KERNEL_GEMM_H
#define AI_RUNTIME_LITE_TINY_KERNEL_GEMM_H

#include <stdint.h>

namespace OHOS {
namespace AI {

/**
 * @brief TinyTVM fused gemm relu input.
 *
 * @param data Input data.
 * @param weights filter parameter.
 * @param bias Input bias.
 * @param out quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param output_depth Number of output features.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_gemm(void* data, const void* weights, const float* bias,
                     void* out,int data_type, int I_H_, int I_W_, int output_depth, void* out_type_code);

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_TINY_KERNEL_GEMM_RELU_H
