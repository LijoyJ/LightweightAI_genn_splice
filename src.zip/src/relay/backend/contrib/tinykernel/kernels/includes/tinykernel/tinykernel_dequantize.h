/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_TINY_KERNEL_DEQUANTIZE_H
#define AI_RUNTIME_LITE_TINY_KERNEL_DEQUANTIZE_H

#include <stdint.h>

namespace OHOS {
namespace AI {

/**
 * @brief TinyTVM Dequantize kernel with UINT8 quantized input.
 *
 * Dequantize the input data to a non-quantized format.
 *
 * @param data Input data.
 * @param s_I_ Quantized input data scale.
 * @param z_I_ Quantized input data zero point.
 * @param out Non-quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_dequantize(void* data, const float* s_I_,
                            const int* z_I_, float* out, int data_type, int p_H_,
                            int p_W_, void* out_type_code);

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_TINY_KERNEL_DEQUANTIZE_H
