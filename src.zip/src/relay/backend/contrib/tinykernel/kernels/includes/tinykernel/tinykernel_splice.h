/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_TINY_KERNEL_SPLICE_H
#define AI_RUNTIME_LITE_TINY_KERNEL_SPLICE_H

#include <stdint.h>

namespace OHOS {
namespace AI {

/**
 * @brief TinyTVM splice input.
 *
 * @param data Input data.
 * @param forward_index forward_index parameter.
 * @param out quantized output parameter.
 * @param I_H_ Input data height (part of input shape).
 * @param I_W_ Input data width (part of input shape).
 * @Param output_depth Number of output features.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_splice(void* data, const int* forward_index,
                     void* out,int data_type, int channel, int I_H_, int I_W_, int index_length, void* out_type_code);

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_TINY_KERNEL_SPLICE_H
