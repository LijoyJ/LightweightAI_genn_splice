/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_TINY_KERNEL_QDENSE_H
#define AI_RUNTIME_LITE_TINY_KERNEL_QDENSE_H

#include <stdint.h>

namespace OHOS {
namespace AI {

/**
 * @brief TinyTVM fused Dense kernel with UINT8 quantized input.
 *
 * @param data UINT8 Input data.
 * @param weights UINT8 filter parameter.
 * @param z_I_ Quantized input data zero point.
 * @param z_W_ Quantized filter parameter zero point.
 * @param s_I_ Quantized input data scale.
 * @param s_W_ Quantized filter parameter scale.
 * @param bias Input bias.
 * @param s_NI_ New input scale formed for requantization.
 * @param z_NI_ New input zero point formed for requantization.
 * @param s_O_ Quantized output data scale.
 * @param z_O_ Quantized output data zero point.
 * @param out UINT8 quantized output parameter.
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @Param uinits Number of output features.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_fused_dense_requant(
                        void* data, const void* weights, const int* z_I_,
                        const int* z_W_, const float* s_I_,
                        const float* s_W_, const int* bias,
                        const float* s_NI_, const int* z_NI_,
                        const float* s_O_, const int* z_O_, void* out,
                        int data_type, int p_H_, int p_W_, int uinits,
                        void* out_type_code);

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_TINY_KERNEL_QDENSE_H
