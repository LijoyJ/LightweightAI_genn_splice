/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_TINY_KERNEL_AVGPOOL_H
#define AI_RUNTIME_LITE_TINY_KERNEL_AVGPOOL_H

#include <stdint.h>

namespace OHOS {
namespace AI {

/**
 * @brief TinyTVM AvgPool kernel with non-quantized input.
 *
 * @param data INT Input data.
 * @param out Non-quantized output parameter.
 * @param p_N_ Input data batch (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channels (part of input shape).
 * @param p_KH_ Filter height.
 * @Param p_KW_ Filter width.
 * @Param p_SH_ Stride height.
 * @Param p_SW_ Stride Weight.
 * @param p_PH_ Input padding height.
 * @param p_PW_ Input padding width.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_avgpool(int* data, int* out, int p_N_, int p_H_, int p_W_, int p_C_,
                   int p_KH_, int p_KW_, int p_SH_, int p_SW_, int p_PH_,
                   int p_PW_, void* out_type_code);

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_TINY_KERNEL_AVGPOOL_H
