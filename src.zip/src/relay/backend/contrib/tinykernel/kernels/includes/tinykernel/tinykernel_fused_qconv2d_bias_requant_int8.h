/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef AI_RUNTIME_LITE_TINY_KERNEL_QCONV2D_BIAS_INT8_H
#define AI_RUNTIME_LITE_TINY_KERNEL_QCONV2D_BIAS_INT8_H

#include <stdint.h>

namespace OHOS {
namespace AI {

/**
 * @brief TinyTVM fused Conv2D kernel with UINT8 quantized input.
 *
 * @param data Input data to be convolved.
 * @param weights filter parameter to convolve over the input data.
 * @param z_I_ Quantized input data zero point.
 * @param z_W_ Quantized filter parameter zero point.
 * @param s_I_ Quantized input data scale.
 * @param s_W_ Quantized filter parameter scale.
 * @param bias Bias data.
 * @param s_NI_ New input scale formed for requantization.
 * @param z_NI_ New input zero point formed for requantization.
 * @param s_O_ Quantized output data scale.
 * @param z_O_ Quantized output data zero point.
 * @param out UINT8 quantized convolution output as an output parameter.
 * @param p_N_ Input data batch size (part of input shape).
 * @param p_H_ Input data height (part of input shape).
 * @param p_W_ Input data width (part of input shape).
 * @param p_C_ Input data channel (part of input shape).
 * @param p_O_ Output channel.
 * @param p_G_ Groups for convolution.
 * @param p_PH_ Input padding height.
 * @param p_PW_ Input padding width.
 * @param p_KH_ Filter parameter height.
 * @Param p_KW_ Filter parameter width.
 * @Param p_SH_ Stride height.
 * @Param p_SW_ Stride Weight.
 * @Param out_type_code kernel handler.
 * @return Returns void.
 * @since 1.0
 * @version 1.0
 */
extern "C" void
tinykernel_fused_qconv2d_bias_requant_int8(
                        int8_t* data, const int8_t* weights, const int* z_I_,
                        const int* z_W_, const float* s_I_, const float* s_W_,
                        const int* bias, const float* s_NI_, const int* z_NI_,
                        const float* s_O_, const int* z_O_, int8_t* out,
                        int p_N_, int p_H_, int p_W_, int p_C_, int p_O_,
                        int p_G_, int p_PH_, int p_PW_, int p_KH_, int p_KW_,
                        int p_SH_, int p_SW_, void* out_type_code);

}  // namespace AI
}  // namespace OHOS

#endif  // AI_RUNTIME_LITE_TINY_KERNEL_QCONV2D_BIAS_INT8_H
