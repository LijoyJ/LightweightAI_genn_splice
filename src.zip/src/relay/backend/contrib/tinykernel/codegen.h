/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*!
 * \file src/relay/backend/contrib/tinykernel/codegen.h
 * \brief code gen include file.
 */

#ifndef CODEGEN_H_
#define CODEGEN_H_

// #include <string>
#include <string>
#include <vector>
#include "../../utils.h"
#include "../codegen_c/codegen_c.h"


namespace tvm {
namespace relay {
namespace contrib {

#define TVM_HOME_ENV_VAR "TVM_HOME"
#define DEFAULT_KERNEL_CFG_RELATIVE_PATH "/src/relay/backend/contrib/tinykernel/default_codegen_config.json"
#define OP_KERNEL_FUNCTION_NAME_CONFIG "func_name"
#define KERNEL_SHARED_LIBRARY_PATH_CONFIG "libpath"
#define GENERATE_KERNEL_FUNCTIONS_ARGUMENTS_CFG "arg_fn"
#define KERNEL_IMPL_C_FILE_CFG "cfile"
#define KERNEL_FUNCTION_DECL_H_FILE_CFG "headerfile"
#define GENERATE_KERNEL_FUNCTION_BODY_CFG "kernelFn"
#define CONSTRUCT_TINY_KERNEL_CODE_GEN_OBJ_CFG "ConstructCodegenImpl"
#define TINYKERNEL_GENERATOR_LIB_PATH_CFG  "libpath"
#define TINYKERNEL_GENERATOR_CONSTRUCTOR_CFG "constructor"

struct GenerateBodyOutput {
  std::string decl;
  std::vector<std::string> buffers;
  std::vector<Output> outputs;
  std::vector<std::string> source_files;
  std::vector<std::string> header_files;
};

// TODO(@zhiics, @comaniac): This is a basic implementation. We should implement
// all utilities and make a base class for users to implement.
class CodegenTINYKERNEL : public tvm::relay::backend::MemoizedExprTranslator<std::vector<Output>>, public CodegenCBase {
 public:
  explicit CodegenTINYKERNEL(const std::string& id);

  std::vector<Output> VisitExprDefault_(const Object* op) final;

  std::vector<Output> VisitExpr_(const VarNode* node) final;

  std::vector<Output> VisitExpr_(const TupleGetItemNode* op) final;

  template <typename T>
  void TransposeHWIO2OHWI(const T* in_data, T* out_data,
                          std::vector<int64_t> shape);

  std::vector<Output> VisitExpr_(const ConstantNode* cn) final;

  void SetConv2DTraspose(const CallNode* call);

  std::vector<Output> VisitExpr_(const CallNode* call) final;

  std::string JIT(const std::vector<Output>& out);

  std::vector<std::string> GetSourceFiles();

  std::vector<std::string> GetHeaderFiles();

  Array<String> GetConstantVars();

  std::vector<std::string> GetArgumentNames(const CallNode* call);

  GenerateBodyOutput GenerateBodyComposite(const CallNode* root_call,
                            const std::string& func_name,
                            const std::vector<std::string>& func_args,
                            const std::vector<std::string>& attribute_args,
                            const std::vector<std::string> source_files,
                            const std::vector<std::string> header_files);

  void ClearNeedTranspose();

 private:

  std::string GetQuantizationType(std::string func_name,
                                  const CallNode* call);

  GenerateBodyOutput GenerateOpCall(const CallNode* call);

  std::string GetCompositeFunctionName(std::string pattern_name);

  GenerateBodyOutput GenerateCompositeFunctionCall(const FunctionNode* callee,
                                                    const CallNode* caller);

  GenerateBodyOutput GenerateBody(const CallNode* root_call, const std::string& func_name,
                                  const std::vector<std::string>& attribute_args);

  GenerateBodyOutput GenerateBodyComposite(const CallNode* root_call, const std::string& func_name,
                                  const std::vector<std::string>& attribute_args);

  GenerateBodyOutput GenerateBodyComposite(const CallNode* root_call, const std::string& func_name,
                                  const std::vector<std::string>& attribute_args,
                              const std::vector<std::string> source_files,
                              const std::vector<std::string> header_files);

  GenerateBodyOutput GenerateBodyComposite(const CallNode* root_call,
                              const std::string& func_name,
                              const tvm::relay::CallNode* caller,
                              const std::vector<std::string>& attribute_args,
                              const std::vector<std::string> source_files,
                              const std::vector<std::string> header_files);

  GenerateBodyOutput GenerateBody(const CallNode* root_call, const std::string& func_name,
                                  const std::vector<std::string>& func_args,
                                  const std::vector<std::string>& attribute_args);


  /*! \brief The id of the external tinykernel ext_func. */
  std::string ext_func_id_{""};
  /*!
   * \brief The index to track the output buffer. Each kernel will redirect the
   * output to a buffer that may be consumed by other kernels.
   */
  int buf_idx_{0};
  /*! \brief The index of global constants. */
  int const_idx_{0};
  /*! \brief The arguments used by a wrapped function that calls tiny kernels. */
  Array<Var> ext_func_args_;
  /*! \brief statement of the function that will be compiled using tiny kernels. */
  std::vector<std::string> ext_func_body_;
  /*! \brief The array declared to store the constant values. */
  std::string const_array_name_;
  /*! \brief The declaration of intermeidate buffers. */
  std::vector<std::string> buf_decl_;
  /*! \brief The variable name to constant mapping. */
  Array<String> const_vars_;

  std::vector<std::string> src_files_;
  std::vector<std::string> header_files_;

  int need_transpose = 1;
}; //class CodegenTINYKERNEL

typedef CodegenTINYKERNEL* (*pfnConstructCodegenImpl)(const std::string& id);

//TODO: Temp Solution
typedef GenerateBodyOutput (*pfnGenerateCompositeFunctionCall)(
                                    const FunctionNode* callee,
                                    const CallNode* caller,
                                    std::vector<std::string> source_files,
                                    std::vector<std::string> header_files,
                                    tvm::relay::contrib::CodegenTINYKERNEL *codeGen);

typedef std::vector<std::string> (*ArgFunType)(const CallNode* call,
                                    tvm::relay::contrib::CodegenTINYKERNEL *codeGen);

typedef std::vector<std::string> (*ArgFunType1)(const CallNode* call);
struct GenerateOpCallConfig {
  ArgFunType1 genFun;
  std::vector<std::string> source_files;
  std::vector<std::string> header_files;
};



}  // namespace contrib
}  // namespace relay
}  // namespace tvm


#endif //CODEGEN_H_
