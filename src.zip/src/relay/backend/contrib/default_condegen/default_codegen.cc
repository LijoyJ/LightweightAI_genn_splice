#include <tvm/relay/attrs/nn.h>
#include <tvm/relay/expr_functor.h>
#include <tvm/relay/transform.h>
#include <tvm/relay/type.h>
#include <tvm/runtime/module.h>
#include <tvm/runtime/registry.h>
#include <tvm/relay/qnn/attrs.h>

#include <tvm/ir/attrs.h>
#include <tvm/relay/base.h>
#include <tvm/relay/expr.h>
#include <numeric>
#include <utils.h>

#include "./default_codegen.h"

#include "tinykernel_constants.h" //TODO optimize the import

#define PDBG 0



using namespace qnn;
using namespace tvm::relay;
using namespace tvm::relay::backend;

namespace tvm {
namespace relay {
namespace contrib {

//TODO: remove this duplicate and refer in codegen base
std::string DefaultCodegenTINYKERNEL::GetDtypeString(DLDataType dtype_code) {
  std::string dtype;
  if (runtime::TypeMatch(dtype_code, kDLFloat, 32)) {
    dtype = "float";
  } else if (runtime::TypeMatch(dtype_code, kDLInt, 32)) {
    dtype = "int";
  } else if (runtime::TypeMatch(dtype_code, kDLInt, 64)) {
    dtype = "int64_t";
  } else if (runtime::TypeMatch(dtype_code, kDLInt, 8)) {
    dtype = "int8_t";
  } else if (runtime::TypeMatch(dtype_code, kDLUInt, 8)) {
    dtype = "uint8_t";
  } else {
    LOG(FATAL) << "Unsupported dtype";
  }

  return dtype;
}


DefaultCodegenTINYKERNEL::DefaultCodegenTINYKERNEL(const std::string& id):CodegenTINYKERNEL(id){}
//TODO: delete implemnetation from codegen.cc and change name
void DefaultCodegenTINYKERNEL::SetConv2DTraspose(const CallNode* call) {
  const auto* conv2d_attr = call->attrs.as<Conv2DAttrs>();
  int groups = conv2d_attr->groups;

  if (PDBG) std::cout<<"TINYKERNEL SetConv2DTraspose, groups:"<<groups<<std::endl;
  if (groups != 1) { //TODO support for need_transpose
    ClearNeedTranspose();
  }
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Relu_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, C, H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Add_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Requantize_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  const auto* req_attr = call->attrs.as<RequantizeAttrs>();

  args.push_back(std::to_string(req_attr->axis));
  if (PDBG) std::cout<<"Requantizing rounding:"<<req_attr->rounding<<std::endl;

  auto ishape = GetShape(call->args[0]->checked_type());
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

//TODO: To be verified
std::vector<std::string> DefaultCodegenTINYKERNEL::Quantize_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  if (PDBG) std::cout<<"Quantize_TINYKERNEL called...."<<std::endl;

  std::string out_arg_type = GetDtypeString(call->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(out_arg_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

//TODO: To be verified
std::vector<std::string> DefaultCodegenTINYKERNEL::Dequantize_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  if (PDBG) std::cout<<"Dequantize_TINYKERNEL called...."<<std::endl;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
    if (PDBG) std::cout<<"shape:"<<std::to_string(s)<<std::endl;
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::BiasAdd_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Clip_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  const auto* clip_attr = call->attrs.as<ClipAttrs>();
  args.push_back(std::to_string(clip_attr->a_min));
  args.push_back(std::to_string(clip_attr->a_max));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, H, W, C
  int size = 0;
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
    size++;
  }
  for (int idx = size; idx < 4 ; idx++) {
    args.push_back(std::to_string(1));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Cast_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  std::string ret_type = GetDtypeString(call->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(ret_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::QConv2d_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  // Support only NHWC format
  const auto* conv2d_attr = call->attrs.as<Conv2DAttrs>();
  CHECK(conv2d_attr);

  auto ishape = GetShape(call->args[0]->checked_type());
  auto wshape = GetShape(call->args[1]->checked_type());

  // Args: N, C, H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  //Filter shape is HWIO
  // Args: O, G, Ph, Pw, Kh, Kw, Sh, Sw
  args.push_back(std::to_string(wshape[3]));
  args.push_back(std::to_string(conv2d_attr->groups));

  //args.push_back(std::to_string(conv2d_attr->padding[0].as<IntImmNode>()->value));
  //args.push_back(std::to_string(conv2d_attr->padding[1].as<IntImmNode>()->value));

  int pad_width = 0;
  int pad_height = 0;
  if (conv2d_attr->padding[0].as<IntImmNode>()->value
      || conv2d_attr->padding[2].as<IntImmNode>()->value) {
    pad_width = 1;
  }

  if (conv2d_attr->padding[1].as<IntImmNode>()->value
      || conv2d_attr->padding[3].as<IntImmNode>()->value) {
    pad_height = 1;
  }
  args.push_back(std::to_string(pad_width));
  args.push_back(std::to_string(pad_height));

  if (PDBG) std::cout<<"QConv2d_TINYKERNEL:"<<"pad0:"<<conv2d_attr->padding[0].as<IntImmNode>()->value<<" " \
    <<"pad1:"<<conv2d_attr->padding[1].as<IntImmNode>()->value<<" " \
    <<"pad2:"<<conv2d_attr->padding[2].as<IntImmNode>()->value<<" " \
    <<"pad3:"<<conv2d_attr->padding[3].as<IntImmNode>()->value<<std::endl;

  args.push_back(std::to_string(wshape[0]));
  args.push_back(std::to_string(wshape[1]));
  args.push_back(std::to_string(conv2d_attr->strides[0].as<IntImmNode>()->value));
  args.push_back(std::to_string(conv2d_attr->strides[1].as<IntImmNode>()->value));
  if (PDBG) std::cout<<"conv2d attribute group:"<<std::to_string(conv2d_attr->groups)<<std::endl;

  if (PDBG) std::cout<<"conv2d attribute wshape[0]:"<<std::to_string(wshape[0])<<std::endl;
  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::QDense_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  const auto* dense_attr = call->attrs.as<DenseAttrs>();
  CHECK(dense_attr);

  if (PDBG) std::cout<<"QDense_TINYKERNEL attribute setting called...."<<std::endl;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, C, H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  args.push_back(std::to_string(dense_attr->units.as<IntImmNode>()->value));

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Softmax_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  const auto* attr = call->attrs.as<SoftmaxAttrs>();
  CHECK(attr);

  if (PDBG) std::cout<<"Softmax_TINYKERNEL attribute setting called...."<<std::endl;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, H, W, C
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Reshape_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, H, W, C
  int size = 0;
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
    size++;
  }
  for (int idx = size; idx < 4 ; idx++) {
    args.push_back(std::to_string(1));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::MaxPool_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  const auto* attr = call->attrs.as<MaxPool2DAttrs>();
  CHECK(attr);

  if (PDBG) std::cout<<"MaxPool_TINYKERNEL attribute setting called...."<<std::endl;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, C, H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  args.push_back(std::to_string(attr->pool_size[0].as<IntImmNode>()->value));
  args.push_back(std::to_string(attr->pool_size[1].as<IntImmNode>()->value));

  args.push_back(std::to_string(attr->strides[0].as<IntImmNode>()->value));
  args.push_back(std::to_string(attr->strides[1].as<IntImmNode>()->value));

  if (attr->padding.size() == 1) {
    args.push_back(std::to_string(attr->padding[0].as<IntImmNode>()->value * 2));
    args.push_back(std::to_string(attr->padding[0].as<IntImmNode>()->value * 2));
  } else if (attr->padding.size() == 2) {
    args.push_back(std::to_string(attr->padding[0].as<IntImmNode>()->value * 2));
    args.push_back(std::to_string(attr->padding[1].as<IntImmNode>()->value * 2));
  } else {
    args.push_back(std::to_string(attr->padding[0].as<IntImmNode>()->value +
        attr->padding[2].as<IntImmNode>()->value));
    args.push_back(std::to_string(attr->padding[1].as<IntImmNode>()->value +
        attr->padding[3].as<IntImmNode>()->value));
  }

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::AvgPool_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;

  const auto* attr = call->attrs.as<AvgPool2DAttrs>();
  CHECK(attr);


  if (PDBG) std::cout<<"AvgPool_TINYKERNEL attribute setting called...."<<std::endl;

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, C, H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  args.push_back(std::to_string(attr->pool_size[0].as<IntImmNode>()->value));
  args.push_back(std::to_string(attr->pool_size[1].as<IntImmNode>()->value));

  args.push_back(std::to_string(attr->strides[0].as<IntImmNode>()->value));
  args.push_back(std::to_string(attr->strides[1].as<IntImmNode>()->value));

  args.push_back(std::to_string(attr->padding[0].as<IntImmNode>()->value));
  args.push_back(std::to_string(attr->padding[1].as<IntImmNode>()->value));

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::Dense_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  const auto* dense_attr = call->attrs.as<DenseAttrs>();
  CHECK(dense_attr);

  if (PDBG) std::cout<<"Dense_TINYKERNEL attribute setting called...."<<std::endl;

  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));

  auto ishape = GetShape(call->args[0]->checked_type());
  // Args: N, C, H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }

  args.push_back(std::to_string(dense_attr->units.as<IntImmNode>()->value));

  return args;
}

std::vector<std::string> DefaultCodegenTINYKERNEL::take_TINYKERNEL(const CallNode* call) {
  std::vector<std::string> args;
  std::string arg0_type = GetDtypeString(call->args[0]->checked_type().as<TensorTypeNode>()->dtype);
  args.push_back(std::to_string(OHOS::AI::GetTinyKernelDataTypeCode(arg0_type)));
  auto ishape = GetShape(call->args[0]->checked_type());
  auto indices_shape = GetShape(call->args[1]->checked_type());
  int size = 0;
  if (PDBG) std::cout<<"take_TINYKERNEL attribute setting called...."<<std::endl;
  for (auto s : ishape) {
    size++;
  }
  for (int idx = size; idx < 3; idx++) {
    args.push_back(std::to_string(1));
  }
  // Args: H, W
  for (auto s : ishape) {
    args.push_back(std::to_string(s));
  }
  for (auto s : indices_shape) {
    args.push_back(std::to_string(s));
  }

  return args;
}

}  // namespace contrib
}  // namespace relay
}  // namespace tvm

extern "C" tvm::relay::contrib::CodegenTINYKERNEL* ConstructCodegenImpl(const std::string& id){
  return new tvm::relay::contrib::DefaultCodegenTINYKERNEL(id);
}

extern "C" std::vector<std::string> generate_tinykernel_requantize_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Requantize_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_qbias_add_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->BiasAdd_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_softmax_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Softmax_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_qconv2d_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->QConv2d_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_quantize_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Quantize_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_maxpool_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->MaxPool_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_avgpool_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->AvgPool_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_dequantize_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Dequantize_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_reshape_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Reshape_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_cast_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Cast_TINYKERNEL(call);
}

extern "C" std::vector<std::string> generate_tinykernel_clip_attrs(const CallNode* call, tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);
    return codeGen_->Clip_TINYKERNEL(call);
}


extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_qconv2d_bias_requant_uint8_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* conv_call =
          GetRootCall(callee->body.as<tvm::relay::CallNode>(), 2, {"qnn.conv2d", "nn.bias_add", "qnn.requantize"});
      const auto* requant_call =
          GetRootCall(callee->body.as<tvm::relay::CallNode>(), 0, {"qnn.requantize"});
      codeGen_->SetConv2DTraspose(conv_call);
      if (PDBG) std::cout<<"called SetConv2DTraspose generate_tinykernel_fused_qconv2d_bias_requant_uint8_body"<<std::endl;

      return codeGen_->GenerateBodyComposite(requant_call, "tinykernel_fused_qconv2d_bias_requant_uint8", codeGen_->GetArgumentNames(caller),
             codeGen_->QConv2d_TINYKERNEL(conv_call), source_files, header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_qconv2d_bias_requant_int8_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* conv_call =
          GetRootCall(callee->body.as<CallNode>(), 2, {"qnn.conv2d", "nn.bias_add", "qnn.requantize"});
      const auto* requant_call =
          GetRootCall(callee->body.as<CallNode>(), 0, {"qnn.requantize"});
      codeGen_->SetConv2DTraspose(conv_call);
      if (PDBG) std::cout<<"called SetConv2DTraspose generate_tinykernel_fused_qconv2d_bias_requant_int8_body"<<std::endl;
      return codeGen_->GenerateBodyComposite(requant_call,
                                   "tinykernel_fused_qconv2d_bias_requant_int8",
                                   codeGen_->GetArgumentNames(caller),
                                   codeGen_->QConv2d_TINYKERNEL(conv_call),
                                   source_files,
                                   header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_dense_requant_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* dense_call =
        GetRootCall(callee->body.as<CallNode>(), 2, {"qnn.dense", "nn.bias_add", "qnn.requantize"});
    const auto* requant_call =
        GetRootCall(callee->body.as<CallNode>(), 0, {"qnn.requantize"});

    if (PDBG) std::cout<<"called SetConv2DTraspose generate_tinykernel_fused_dense_requant_body"<<std::endl;
    return codeGen_->GenerateBodyComposite(requant_call,
                                 "tinykernel_fused_dense_requant",
                                  codeGen_->GetArgumentNames(caller),
                                  codeGen_->QDense_TINYKERNEL(dense_call),
                                  source_files,
                                  header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_softmax_quant_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* softmax_call =
        GetRootCall(callee->body.as<CallNode>(), 2, {"qnn.dequantize", "nn.softmax", "qnn.quantize"});
    const auto* quant_call =
        GetRootCall(callee->body.as<CallNode>(), 0, {"qnn.quantize"});
    if (PDBG) std::cout<<"called SetConv2DTraspose generate_tinykernel_fused_dense_requant_body"<<std::endl;
    return codeGen_->GenerateBodyComposite(quant_call,
                                 "tinykernel_fused_softmax_quant",
                                  codeGen_->GetArgumentNames(caller),
                                  codeGen_->Dequantize_TINYKERNEL(softmax_call),
                                  source_files,
                                  header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_take_reshape_squeeze_batch_flatten_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* take_call =
        GetRootCall(callee->body.as<CallNode>(), 3, {"take", "reshape", "squeeze", "nn.batch_flatten"});
    const auto* batch_flatten_call =
        GetRootCall(callee->body.as<CallNode>(), 0, {"nn.batch_flatten"});
    if (PDBG) std::cout<<"called generate_tinykernel_fused_take_reshape_squeeze_batch_flatten_body"<<std::endl;
    return codeGen_->GenerateBodyComposite(batch_flatten_call,
                                 "tinykernel_splice",
                                  codeGen_->GetArgumentNames(caller),
                                  codeGen_->take_TINYKERNEL(take_call),
                                  source_files,
                                  header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_take_reshape_batch_flatten_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* take_call =
        GetRootCall(callee->body.as<CallNode>(), 2, {"take", "reshape", "nn.batch_flatten"});
    const auto* batch_flatten_call =
        GetRootCall(callee->body.as<CallNode>(), 0, {"nn.batch_flatten"});
    if (PDBG) std::cout<<"called generate_tinykernel_fused_take_reshape_batch_flatten_body"<<std::endl;
    return codeGen_->GenerateBodyComposite(batch_flatten_call,
                                 "tinykernel_splice",
                                  codeGen_->GetArgumentNames(caller),
                                  codeGen_->take_TINYKERNEL(take_call),
                                  source_files,
                                  header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_dense_bias_add_relu_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* dense_call =
        GetRootCall(callee->body.as<CallNode>(), 2, {"nn.dense", "nn.bias_add", "nn.relu"});
    const auto* relu_call =
        GetRootCall(callee->body.as<CallNode>(), 0, {"nn.relu"});

    if (PDBG) std::cout<<"called generate_tinykernel_fused_dense_bias_add_relu_body"<<std::endl;
    return codeGen_->GenerateBodyComposite(relu_call,
                                 "tinykernel_gemm_relu",
                                  codeGen_->GetArgumentNames(caller),
                                  codeGen_->Dense_TINYKERNEL(dense_call),
                                  source_files,
                                  header_files);
}

extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_fused_dense_bias_add_body(const FunctionNode* callee,
                                                   const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL *codeGen) {
    tvm::relay::contrib::DefaultCodegenTINYKERNEL *codeGen_ = dynamic_cast<tvm::relay::contrib::DefaultCodegenTINYKERNEL*>(codeGen);

    const auto* dense_call =
        GetRootCall(callee->body.as<CallNode>(), 1, {"nn.dense", "nn.bias_add"});
    const auto* bias_add_call =
        GetRootCall(callee->body.as<CallNode>(), 0, {"nn.bias_add"});

    if (PDBG) std::cout<<"called generate_tinykernel_fused_dense_bias_add_body"<<std::endl;
    return codeGen_->GenerateBodyComposite(bias_add_call,
                                 "tinykernel_gemm",
                                  codeGen_->GetArgumentNames(caller),
                                  codeGen_->Dense_TINYKERNEL(dense_call),
                                  source_files,
                                  header_files);
}

// extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_qconv2d_requant_body(const tvm::relay::FunctionNode* callee,
//                                                    const CallNode* caller,
//                                       std::vector<std::string> source_files,
//                                       std::vector<std::string> header_files) {
//     const auto* conv_call =
//         GetRootCall(callee->body.as<CallNode>(), 1, {"qnn.conv2d", "qnn.requantize"});
//     const auto* requant_call =
//         GetRootCall(callee->body.as<CallNode>(), 0, {"qnn.requantize"});
//     SetConv2DTraspose(conv_call);
//     if (PDBG) std::cout<<"called SetConv2DTraspose tinykernel.qconv2d_requant"<<std::endl;
//     function_name = "tinykernel_fused_qconv2d_requant";
//     if(true == Is_Depthwise(conv_call))
//     {
//         function_name = "tinykernel_fused_depthwise_qconv2d_requant";
//     }
//     return GenerateBodyComposite(requant_call, function_name, GetArgumentNames(caller),
//             QConv2d_TINYKERNEL(conv_call), source_files, header_files);
// }

// extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_dense_bias_requant_body(const FunctionNode* callee,
//                                                    const CallNode* caller,
//                                       std::vector<std::string> source_files,
//                                       std::vector<std::string> header_files) {
//     const auto* dense_call =
//         GetRootCall(callee->body.as<CallNode>(), 2, {"qnn.dense", "nn.bias_add", "qnn.requantize"});
//     const auto* requant_call =
//         GetRootCall(callee->body.as<CallNode>(), 0, {"qnn.requantize"});
//     return GenerateBodyComposite(requant_call, "tinykernel_fused_dense_requant", GetArgumentNames(caller),
//             QDense_TINYKERNEL(dense_call), source_files, header_files);
// }

// extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_avgpool_quant_body(const FunctionNode* callee,
//                                                    const CallNode* caller,
//                                       std::vector<std::string> source_files,
//                                       std::vector<std::string> header_files) {
//     const auto* avgpool_call =
//         GetRootCall(callee->body.as<CallNode>(), 2, {"cast", "nn.avg_pool2d", "cast"});
//     const auto* cast_call =
//         GetRootCall(callee->body.as<CallNode>(), 0, {"cast"});
//     return GenerateBodyComposite(cast_call, "tinykernel_avgpool", GetArgumentNames(caller),
//             Cast_AveragePool_TINYKERNEL(avgpool_call), source_files, header_files);
// }
