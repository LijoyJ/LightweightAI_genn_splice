/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*!
 * \file src/relay/backend/contrib/tinykernel/default_codegen.h
 * \brief default tiny kernel codegen.
 */

#ifndef DEFAULT_CODEGEN_H_
#define DEFAULT_CODEGEN_H_

#include "codegen.h"

using namespace tvm::relay;
using namespace tvm::relay::backend;

namespace tvm {
namespace relay {
namespace contrib {

// TODO(@zhiics, @comaniac): This is a basic implementation. We should implement
// all utilities and make a base class for users to implement.
class DefaultCodegenTINYKERNEL : public CodegenTINYKERNEL {
 public:
  std::string GetDtypeString(DLDataType dtype_code);

  explicit DefaultCodegenTINYKERNEL(const std::string& id);

  void SetConv2DTraspose(const CallNode* call);

  std::vector<std::string> Relu_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Add_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Requantize_TINYKERNEL(const CallNode* call);

  //TODO: To be verified
  std::vector<std::string> Quantize_TINYKERNEL(const CallNode* call);

  //TODO: To be verified
  std::vector<std::string> Dequantize_TINYKERNEL(const CallNode* call);

  std::vector<std::string> BiasAdd_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Clip_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Cast_TINYKERNEL(const CallNode* call);

  std::vector<std::string> QConv2d_TINYKERNEL(const CallNode* call);

  std::vector<std::string> QDense_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Softmax_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Reshape_TINYKERNEL(const CallNode* call);

  std::vector<std::string> MaxPool_TINYKERNEL(const CallNode* call);

  std::vector<std::string> AvgPool_TINYKERNEL(const CallNode* call);

  std::vector<std::string> Dense_TINYKERNEL(const CallNode* call);

  std::vector<std::string> take_TINYKERNEL(const CallNode* call);

};


}  // namespace contrib
}  // namespace relay
}  // namespace tvm


extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_qconv2d_bias_requant_body(
                                                    const tvm::relay::FunctionNode* callee,
                                                    const tvm::relay::CallNode* caller,
                                      std::vector<std::string> source_files,
                                      std::vector<std::string> header_files,
                                      tvm::relay::contrib::CodegenTINYKERNEL* codeGen);

// extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_qconv2d_requant_body(
//                                                     const tvm::relay::FunctionNode* callee,
//                                                     const tvm::relay::CallNode* caller,
//                                       std::vector<std::string> source_files,
//                                       std::vector<std::string> header_files,
//                                       tvm::relay::contrib::CodegenTINYKERNEL codeGen);

// extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_dense_bias_requant_body(
//                                                     const tvm::relay::FunctionNode* callee,
//                                                     const tvm::relay::CallNode* caller,
//                                       std::vector<std::string> source_files,
//                                       std::vector<std::string> header_files,
//                                       tvm::relay::contrib::CodegenTINYKERNEL codeGen);

// extern "C" tvm::relay::contrib::GenerateBodyOutput generate_tinykernel_avgpool_quant_body(
//                                                     const tvm::relay::FunctionNode* callee,
//                                                     const tvm::relay::CallNode* caller,
//                                       std::vector<std::string> source_files,
//                                       std::vector<std::string> header_files,
//                                       tvm::relay::contrib::CodegenTINYKERNEL codeGen);

#endif //DEFAULT_CODEGEN_H_
