#include <assert.h>
#include "flatbuffer/runtime_flatbuffer.h"
#include "graph.json.h"

namespace {
OHOS::AI::RuntimeFlatbuffer* runtime = nullptr;
}  // namespace

int main(int argc, char** argv) {
  assert(argc == 2);

  char* json_data = (char*)(graph_json);
  std::vector<OHOS::AI::OperatorFunction> operatorFunctions;
  runtime = new OHOS::AI::RuntimeFlatbuffer(json_data, nullptr, &operatorFunctions);
  runtime->SaveFlatBuffer(argv[1]);

  return 0;
}
