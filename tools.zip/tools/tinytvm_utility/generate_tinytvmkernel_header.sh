SRC_BIN_NAME=$1
KERNEL_HEADER_FILE=$2
NM="arm-none-eabi-nm"
NM="nm"
FUNC_PREFIX="int "
FUNC_POSTFIX="(TVMValue* args, int* type_codes, int num_args, TVMValue* out_ret_value, int* out_ret_tcode, void* resource_handle);"
FUNC_NAME_PREFIX_EXPORT="TVM_DLL_EXPORT_TYPED_FUNC("
FUNC_NAME_EXCLUDE="__tvm_module_ctx"
FUNC_NAME_REGISTER="void get_operator_funcs(std::vector<OHOS::AI::OperatorFunction>* operator_funcs) {"
FUNC_ADD_KERNEL="void add_operator_func(std::vector<OHOS::AI::OperatorFunction>* operator_funcs, std::string func_name, void* func_ptr) {"

rm -f ${KERNEL_HEADER_FILE}

echo "#ifndef TVM_KERNEL_H_"                                                    >> ${KERNEL_HEADER_FILE}
echo "#define TVM_KERNEL_H_"                                                    >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "#include <string>"                                                        >> ${KERNEL_HEADER_FILE}
echo "#include <vector>"                                                        >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "#include \"runtime.h\""                                                   >> ${KERNEL_HEADER_FILE}
echo "#include \"external/packed_func.h\""                                      >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "#ifdef __cplusplus"                                                       >> ${KERNEL_HEADER_FILE}
echo "extern \"C\" {"                                                           >> ${KERNEL_HEADER_FILE}
echo "#endif"                                                                   >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

echo "using namespace OHOS::AI;"                                                >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

func_names=()

if [[ -f "${SRC_BIN_NAME}" ]]
then
    filename=$(basename -- "${SRC_BIN_NAME}")
    extension="${filename##*.}"
    if [[ ${extension} == "o" || ${extension} == "a" ]]
    then
        ##Prepare header file from *.o file
        while read SRC_LINE
        do
            FUNC_NAME=`echo $SRC_LINE | awk -F " " '{print $3}'`
            if [[ ${FUNC_NAME} != "${FUNC_NAME_EXCLUDE}" ]]
            then
                func_names+=(${FUNC_NAME})
                echo -n "$FUNC_PREFIX"                                          >> ${KERNEL_HEADER_FILE}
                echo -n "$FUNC_NAME"                                            >> ${KERNEL_HEADER_FILE}
                echo "$FUNC_POSTFIX"                                            >> ${KERNEL_HEADER_FILE}
                echo ""                                                         >> ${KERNEL_HEADER_FILE}
            fi
        done <<<$(${NM} --defined-only ${SRC_BIN_NAME} | grep " V\|T ")
    elif [[ ${extension} == "cc" ]]
    then
        ##Prepare header file from *.cc file
        while read -r SRC_LINE
        do
            if [[ $SRC_LINE == *"${FUNC_NAME_PREFIX_EXPORT}"* ]]
            then
                FUNC_NAME=${SRC_LINE%,*}
                FUNC_NAME=${FUNC_NAME//${FUNC_NAME_PREFIX_EXPORT}/""}
                func_names+=(${FUNC_NAME})
                echo -n "$FUNC_PREFIX"                                          >> ${KERNEL_HEADER_FILE}
                echo -n "$FUNC_NAME"                                            >> ${KERNEL_HEADER_FILE}
                echo "$FUNC_POSTFIX"                                            >> ${KERNEL_HEADER_FILE}
                echo ""                                                         >> ${KERNEL_HEADER_FILE}
            fi
        done < ${SRC_BIN_NAME}
    fi
fi

echo "$FUNC_ADD_KERNEL"                                                         >> ${KERNEL_HEADER_FILE}
echo "  OHOS::AI::OperatorFunction operatorFunction;"                           >> ${KERNEL_HEADER_FILE}
echo "  operatorFunction.func_name = func_name;"                                >> ${KERNEL_HEADER_FILE}
echo "  operatorFunction.func_ptr = func_ptr;"                                  >> ${KERNEL_HEADER_FILE}
echo "  operator_funcs->push_back(operatorFunction);"                             >> ${KERNEL_HEADER_FILE}
echo "}"                                                                        >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

if [[ ${#func_names[@]} > 0 ]]
then
    echo "$FUNC_NAME_REGISTER"                                                  >> ${KERNEL_HEADER_FILE}

    for func_name in "${func_names[@]}"
    do
        echo "  add_operator_func(operator_funcs,"                              >> ${KERNEL_HEADER_FILE}
        echo "        \"${func_name}\","                                        >> ${KERNEL_HEADER_FILE}
        echo "        (void*)&${func_name});"                                   >> ${KERNEL_HEADER_FILE}
    done

    echo "}"                                                                    >> ${KERNEL_HEADER_FILE}
    echo ""                                                                     >> ${KERNEL_HEADER_FILE}
fi

echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "int TVMBackendRegisterSystemLibSymbol(const char* name, void* ptr)"       >> ${KERNEL_HEADER_FILE}
echo "{"                                                                        >> ${KERNEL_HEADER_FILE}
echo "    return 0;"                                                            >> ${KERNEL_HEADER_FILE}
echo "}"                                                                        >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "int TVMBackendParallelLaunch(FTVMParallelLambda flambda, void* cdata,"    >> ${KERNEL_HEADER_FILE}
echo "                             int num_task)"                               >> ${KERNEL_HEADER_FILE}
echo "{"                                                                        >> ${KERNEL_HEADER_FILE}
echo "    TVMParallelGroupEnv env;"                                             >> ${KERNEL_HEADER_FILE}
echo "    env.num_task = 1;"                                                    >> ${KERNEL_HEADER_FILE}
echo "    flambda(0, &env, cdata);"                                             >> ${KERNEL_HEADER_FILE}
echo "    return 0;"                                                            >> ${KERNEL_HEADER_FILE}
echo "}"                                                                        >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "void* TVMBackendAllocWorkspace(int device_type, int device_id,"           >> ${KERNEL_HEADER_FILE}
echo "                               uint64_t nbytes, int dtype_code_hint,"     >> ${KERNEL_HEADER_FILE}
echo "                               int dtype_bits_hint)"                      >> ${KERNEL_HEADER_FILE}
echo "{"                                                                        >> ${KERNEL_HEADER_FILE}
echo "    void* ptr = 0;"                                                       >> ${KERNEL_HEADER_FILE}
echo "    unsigned int dtype_bytes = dtype_bits_hint / 8;"                      >> ${KERNEL_HEADER_FILE}
echo "    ptr = malloc(nbytes * dtype_bytes);"                                  >> ${KERNEL_HEADER_FILE}
#echo "    printf(\"BackendAllocWorkspace size:%zu\n\", (nbytes * dtype_bytes));">> ${KERNEL_HEADER_FILE}
echo "    return ptr;"                                                          >> ${KERNEL_HEADER_FILE}
echo "}"                                                                        >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

echo ""                                                                         >> ${KERNEL_HEADER_FILE}
echo "int TVMBackendFreeWorkspace(int device_type, int device_id, void* ptr)"   >> ${KERNEL_HEADER_FILE}
echo "{"                                                                        >> ${KERNEL_HEADER_FILE}
echo "    free(ptr);"                                                           >> ${KERNEL_HEADER_FILE}
echo "    return 0;"                                                            >> ${KERNEL_HEADER_FILE}
echo "}"                                                                        >> ${KERNEL_HEADER_FILE}
echo ""                                                                         >> ${KERNEL_HEADER_FILE}

echo "#ifdef __cplusplus"                                                       >> ${KERNEL_HEADER_FILE}
echo "}"                                                                        >> ${KERNEL_HEADER_FILE}
echo "#endif"                                                                   >> ${KERNEL_HEADER_FILE}

echo "#endif /* #define TVM_KERNEL_H_ */"                                       >> ${KERNEL_HEADER_FILE}
