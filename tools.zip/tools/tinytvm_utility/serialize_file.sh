#!/bin/bash

TARG_PATH=$1
SRC_FILE=$2
cd $TARG_PATH
if [[ -f $SRC_FILE ]]
then
    xxd -i $SRC_FILE > $SRC_FILE.h
    ex -s -c '%s/unsigned char/extern "C" const unsigned char/g|x' $SRC_FILE.h
    ex -s -c '%s/unsigned int/extern "C" const unsigned int/g|x' $SRC_FILE.h
fi
