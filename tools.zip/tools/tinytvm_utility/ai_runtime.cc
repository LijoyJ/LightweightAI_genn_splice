/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "../../src/runtime/runtime/src/json_parser/json_parser.cpp"
#include "../../src/runtime/runtime/src/logger/debug_log.cpp"
#include "../../src/runtime/runtime/src/logger/logger.cpp"
#include "../../src/runtime/runtime/src/ndarray/ndarray.cpp"
#include "../../src/runtime/runtime/src/runtime.cpp"
#include "../../src/runtime/runtime/src/runtime_internal/runtime_impl.cpp"

#include "../../src/runtime/runtime/src/runtime_internal/tiny_tvm_config.cpp"
#include "../../src/runtime/runtime/src/runtime_internal/tiny_tvm.cpp"
#include "../../src/runtime/runtime/src/runtime_internal/tiny_tvm_wrapper.cpp"

#include "../../src/runtime/runtime/src/memory/greedy_memory_planner.cpp"
#include "../../src/runtime/runtime/src/memory/memory_allocator.cpp"
#include "../../src/runtime/runtime/src/memory/simple_memory_allocator.cpp"
