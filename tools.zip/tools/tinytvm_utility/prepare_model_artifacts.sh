#!/bin/bash

TVM_ROOT=$1
TARG_PATH=$2
MODEL_PATH=$3
BUILD_TARGET=$4
TVM_KERNEL=$5
GPP_CROSSCOMPILE=$6
GPP_ARCHIVE=$7
PKG_CXXFLAGS=$8
ADDITION_FLAGS=$9

set -x

function main(){
    mkdir -p ${TARG_PATH}
    python3 ${TVM_ROOT}/tools/tinytvm_utility/build_tinytvm_model.py -o ${TARG_PATH} -m ${MODEL_PATH} -t "$BUILD_TARGET" -cc ${GPP_CROSSCOMPILE} ${TVM_KERNEL} -cf "$PKG_CXXFLAGS"

    /bin/bash ${TVM_ROOT}/tools/tinytvm_utility/serialize_file.sh ${TARG_PATH} params.bin
    /bin/bash ${TVM_ROOT}/tools/tinytvm_utility/serialize_file.sh ${TARG_PATH} graph.json

    g++ -Wall -std=c++14 -O2 -fPIC ${ADDITION_FLAGS} -I${TVM_ROOT}/src/runtime/runtime/includes -I${TVM_ROOT}/src/runtime/runtime/src/includes -DFLATBUFFER=0 -I${TARG_PATH} -o ${TARG_PATH}/graph_to_flatbuffer ${TVM_ROOT}/tools/tinytvm_utility/ai_runtime.cc ${TVM_ROOT}/tools/tinytvm_utility/flatbuffer/runtime_flatbuffer.cpp ${TVM_ROOT}/tools/tinytvm_utility/flatbuffer/runtime_impl_flatbuffer.cpp ${TVM_ROOT}/tools/tinytvm_utility/convert_graph_json_to_flatbuffer.cc -ldl

    ${TARG_PATH}/graph_to_flatbuffer ${TARG_PATH}/graph.flatbuffer

    /bin/bash ${TVM_ROOT}/tools/tinytvm_utility/serialize_file.sh ${TARG_PATH} graph.flatbuffer

    if [ "${TVM_KERNEL}" == "--tvmkernel" ];then
        /bin/bash ${TVM_ROOT}/tools/tinytvm_utility/generate_tinytvmkernel_header.sh ${TARG_PATH}/model_kernel.o ${TARG_PATH}/model_kernel.h
        echo "#include \"model_kernel.h\"" >> ${TARG_PATH}/model_graph_param.cc
    fi

    echo "#include \"params.bin.h\"" >> ${TARG_PATH}/model_graph_param.cc
    echo "#include \"graph.flatbuffer.h\"" >> ${TARG_PATH}/model_graph_param.cc
    ${GPP_CROSSCOMPILE} -c ${PKG_CXXFLAGS} -o ${TARG_PATH}/model_graph_param.o ${TARG_PATH}/model_graph_param.cc
    ${GPP_ARCHIVE} rcs ${TARG_PATH}/modelkernel.a ${TARG_PATH}/model_kernel.o ${TARG_PATH}/model_graph_param.o

    ${GPP_CROSSCOMPILE} -c ${PKG_CXXFLAGS} ${ADDITION_FLAGS} -o ${TARG_PATH}/tinyruntime.o ${TVM_ROOT}/tools/tinytvm_utility/ai_runtime.cc
    ${GPP_ARCHIVE} rcs ${TARG_PATH}/tinyruntime.a ${TARG_PATH}/tinyruntime.o
    rm -rf ${TARG_PATH}/tinyruntime.o
}

main "$@"
