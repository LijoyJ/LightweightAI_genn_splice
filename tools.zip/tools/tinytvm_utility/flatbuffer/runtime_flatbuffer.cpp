#include "runtime_flatbuffer.h"
#include "runtime_impl_flatbuffer.h"

namespace OHOS {
namespace AI {

RuntimeImplFlatbuffer* runtimeImplFlatbuffer_ = nullptr;

RuntimeFlatbuffer::RuntimeFlatbuffer(
        const char* graph_byte, const char* params_byte,
        std::vector<OperatorFunction>* operator_funcs,
        MemoryPoolManager* memPoolMgr)
{
  runtimeImplFlatbuffer_ = new RuntimeImplFlatbuffer(graph_byte, params_byte,
      operator_funcs, memPoolMgr);
}

void RuntimeFlatbuffer::SaveFlatBuffer(const char* dest_file)
{
  runtimeImplFlatbuffer_->SaveFlatBuffer(dest_file);
}

RuntimeFlatbuffer::~RuntimeFlatbuffer()
{
  if (runtimeImplFlatbuffer_) {
    delete runtimeImplFlatbuffer_;
    runtimeImplFlatbuffer_ = 0;
  }
}

}  // AI
}  // OHOS
