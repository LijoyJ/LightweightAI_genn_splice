#include "runtime_impl_flatbuffer.h"

#include <fstream>

namespace OHOS {
namespace AI {

using namespace flatbuffers;

Offset<GraphRuntimeGraphAttr> RuntimeImplFlatbuffer::FlatternRuntimeGraphAttr(
    FlatBufferBuilder* builder) 
{
  uint32_t dltype_count = attrs->dltype_count;
  uint32_t shape_count = attrs->shape_count;

// by defalut, flattern 64bit size shape attribute to 32bit
  uint32_t shape[shape_count * RUNTIME_MAX_NDIM];
  for (uint32_t i=0; i<(shape_count * RUNTIME_MAX_NDIM);i++) {
    shape[i]= attrs->shape[i];
  }

  Offset<GraphRuntimeGraphAttr> attr = CreateGraphRuntimeGraphAttr(
      *builder,
      builder->CreateVector(attrs->storage_id, shape_count),
      builder->CreateVector(
          (int8_t*)attrs->dltype, RUNTIME_STRLEN_DLTYPE * dltype_count),
      dltype_count,
      builder->CreateVector(shape, (shape_count * RUNTIME_MAX_NDIM)),
      builder->CreateVector(attrs->ndim, shape_count),
      shape_count);
// flattern 64bit size shape attribute to 64bit
//  Offset<RuntimeGraphAttr> attr = CreateGraphRuntimeGraphAttr(
//#if RUNTIME_ADVANCE_STORAGE
//      *builder,
//      builder->CreateVector(attrs->advance_storage_id, shape_count),
//#else
//      *builder,
//      builder->CreateVector(attrs->storage_id, shape_count),
//#endif
//      builder->CreateVector(
//          (int8_t*)attrs->dltype, RUNTIME_STRLEN_DLTYPE * dltype_count),
//      dltype_count,
//      builder->CreateVector(attrs->shape, (shape_count * RUNTIME_MAX_NDIM)),
//      builder->CreateVector(attrs->ndim, shape_count),
//      shape_count);
  return attr;
}

Offset<GraphRuntimeNodeEntry> RuntimeImplFlatbuffer::FlatternRuntimeNodeEntry(
    FlatBufferBuilder* builder, RuntimeNodeEntry* node_entry)
{
  Offset<GraphRuntimeNodeEntry> entry = CreateGraphRuntimeNodeEntry(*builder,
      node_entry->node_id, node_entry->index);
  return entry;
}

Offset<GraphRuntimeNode> RuntimeImplFlatbuffer::FlatternRuntimeNode(
    FlatBufferBuilder* builder, RuntimeNode* node) 
{
  Offset<GraphRuntimeNodeEntry> inputs[node->inputs_count];
  for (uint32_t i = 0; i < node->inputs_count; i++) {
    inputs[i] = FlatternRuntimeNodeEntry(builder, &node->inputs[i]);
  }

  Offset<GraphOpParam> param;
  if (node->param) {
    param = CreateOpParam(
        *builder,
        builder->CreateVector(
            (int8_t*)node->param->func_name, strlen(node->param->func_name)+1),
        node->param->num_inputs,
        node->param->num_outputs);
  } else {
    param = CreateOpParam(*builder);
  }

  Offset<GraphRuntimeNode> node_ret = CreateGraphRuntimeNode(
      *builder,
      builder->CreateVector((int8_t*)node->op_type, strlen(node->op_type)+1),
      builder->CreateVector((int8_t*)node->name, strlen(node->name)+1),
      param,
      builder->CreateVector(inputs, node->inputs_count),
      node->inputs_count);
  return node_ret;
}

void RuntimeImplFlatbuffer::SaveFlatBuffer(const char* dest_file)
{
  FlatBufferBuilder builder;
  Offset<GraphRuntimeGraphAttr> attr = FlatternRuntimeGraphAttr(&builder);

  Offset<GraphRuntimeNodeEntry> output_nodes_entry_[output_nodes_size];
  for (uint32_t i = 0; i < output_nodes_size; i++) {
    output_nodes_entry_[i] = FlatternRuntimeNodeEntry(&builder, &output_nodes_entry[i]);
  }

  Offset<GraphRuntimeNode> nodes_[nodes_size];
  for (uint32_t i = 0; i < nodes_size; i++) {
    nodes_[i] = FlatternRuntimeNode(&builder, &nodes[i]);
  }

  Offset<GraphRuntime> run = CreateGraphRuntime(
      builder,
      builder.CreateVector(nodes_, nodes_size),
      nodes_size,
      builder.CreateVector(input_nodes, input_nodes_size),
      input_nodes_size,
      builder.CreateVector(node_row_ptr, nodes_size+1),
      builder.CreateVector(output_nodes_entry_, output_nodes_size),
      output_nodes_size,
      attr);

  const Offset<Monster> mon = CreateMonster(builder, run);
  FinishMonsterBuffer(builder, mon);
  int size = builder.GetSize();
  std::ofstream ofile(dest_file, std::ofstream::binary);
  ofile.write((char*)builder.GetBufferPointer(), size);
  ofile.close();
}

}  // AI
}  // OHOS
