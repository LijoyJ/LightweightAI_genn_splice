#ifndef RUNTIME_RUNTIME_FLATBUFFER_H_
#define RUNTIME_RUNTIME_FLATBUFFER_H_

#include "runtime.h"

namespace OHOS {
namespace AI {

class RuntimeFlatbuffer {
public:
  RuntimeFlatbuffer(const char* graph_byte, const char* params_byte,
                    std::vector<OperatorFunction>* operator_funcs,
                    MemoryPoolManager* memPoolMgr = NULL);
  ~RuntimeFlatbuffer();
  void SaveFlatBuffer(const char* dest_file);
};

}  // AI
}  // OHOS
#endif  // RUNTIME_RUNTIME_FLATBUFFER_H_
