#ifndef RUNTIME_RUNTIME_IMPL_FLATBUFFER_H_
#define RUNTIME_RUNTIME_IMPL_FLATBUFFER_H_

#include "runtime_impl.h"

namespace OHOS {
namespace AI {

class RuntimeImplFlatbuffer : public RuntimeImpl {
public:
  RuntimeImplFlatbuffer(const char* graph_byte, const char* params_byte,
                        std::vector<OperatorFunction>* operator_funcs,
                        MemoryPoolManager* memPoolMgr)
      : RuntimeImpl(graph_byte, params_byte, operator_funcs, memPoolMgr)
   {}

  void SaveFlatBuffer(const char* dest_file);

private:

  flatbuffers::Offset<GraphRuntimeGraphAttr> FlatternRuntimeGraphAttr(
      flatbuffers::FlatBufferBuilder* builder);
  flatbuffers::Offset<GraphRuntimeNodeEntry> FlatternRuntimeNodeEntry(
      flatbuffers::FlatBufferBuilder* builder,
      RuntimeNodeEntry* node_entry);
  flatbuffers::Offset<GraphRuntimeNode> FlatternRuntimeNode(
      flatbuffers::FlatBufferBuilder* builder, RuntimeNode* node);
};
}  // AI
}  // OHOS
#endif  // RUNTIME_RUNTIME_IMPL_FLATBUFFER_H_
