import argparse
import numpy as np
import os
import sys
import tvm
from tvm.contrib import cc
from tvm import relay


#######################################################################
# Generic run functions for TVM & TFLite
# --------------------------------------
"""def convert_to_list(x):
    if not isinstance(x, list):
        x = [x]
    return x"""
def convert_to_list(x):
    if not isinstance(x, list):
        x = [x]
    return x

def update_lib(lib, lib_path, fcompile, cxxflags):
    test_dir = os.path.dirname(os.path.realpath(os.path.expanduser(__file__)))
    kwargs = {}
    kwargs["save_path"] = [test_dir]
    options = ["-O2", "-std=c++14"]
    options = options + cxxflags.split(" ")
    kwargs["options"] = options
    lib.export_library(lib_path, fcompile, **kwargs)
    return lib

def get_partitoned_mod(mod, params, pattern_table):
    # This is required for constant folding
    mod["main"] = tvm.relay.build_module.bind_params_by_name(mod["main"], params)

    remove_bn_pass = tvm.transform.Sequential([
        tvm.relay.transform.InferType(),
        tvm.relay.transform.SimplifyInference(),
        tvm.relay.transform.FoldConstant(),
        tvm.relay.transform.FoldScaleAxis(),
    ])
    composite_partition = tvm.transform.Sequential([
        remove_bn_pass,
        tvm.relay.transform.MergeComposite(pattern_table),
        tvm.relay.transform.AnnotateTarget("tinykernel"),
        tvm.relay.transform.PartitionGraph()
    ])
    with relay.build_config(opt_level=3, disabled_pass=["AlterOpLayout"]):
        return composite_partition(mod)

#######################################################################
def import_tflite_model(tflite_model):
    try:
        import tensorflow.compat.v1 as tf
    except ImportError:
        import tensorflow as tf
    try:
        from tensorflow import lite as interpreter_wrapper
    except ImportError:
        from tensorflow.contrib import lite as interpreter_wrapper
    try:
        import tflite.Model
    except ImportError:
        raise ImportError("The tflite package must be installed")

    shape_dict = {}
    dtype_dict = {}
    input_data = []
    output_idx = []

    with open(tflite_model, "rb") as f:
        tflite_model_buf = f.read()

    # get TFLite model from buffer
    tflite_model = tflite.Model.GetRootAsModel(tflite_model_buf, 0)
    interpreter = interpreter_wrapper.Interpreter(model_content=tflite_model_buf)
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    for i in range(len(input_details)):
        input_data_ = np.full(input_details[i]['shape'], 127, dtype=input_details[i]['dtype'])
        input_data.append(input_data_)
        key = input_details[i]['name']
        shape_dict[key] = input_data_.shape
        dtype_dict[key] = input_data[i].dtype.name
    for i in range(len(output_details)):
        output_idx.append(i)

    mod, params = relay.frontend.from_tflite(tflite_model,
                                             shape_dict=shape_dict,
                                             dtype_dict=dtype_dict)
    return mod, params, input_data, output_idx, shape_dict


# Prepare tflite build variants and verify
# --------------------------------
def run_tflite_graph(tflite_model_buf, input_data):
    """ Generic function to execute TFLite """
    input_data = convert_to_list(input_data)

    interpreter = interpreter_wrapper.Interpreter(model_content=tflite_model_buf)
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # set input
    for i in range(len(input_details)):
        interpreter.set_tensor(input_details[i]['index'], input_data[i])

    # Run
    interpreter.invoke()

    # get output
    tflite_output = list()
    for i in range(len(output_details)):
        tflite_output.append(interpreter.get_tensor(output_details[i]['index']))
    return tflite_output

#######################################################################
def import_onnx_model(onnx_model):
    try:
        import onnx
    except ImportError:
        raise ImportError("The onnx package must be installed")

    shape_dict = {}
    input_data = []
    output_idx = []

    def get_node_info(info_proto):
        """Extract the shape from a ValueInfoProto."""
        shape = []
        shape_name = []
        for dim in info_proto.type.tensor_type.shape.dim:
            name = dim.dim_param
            value = dim.dim_value
            if value is None or value == 0:
                value = 0;
                shape_name.append(value)
            else:
                shape_name.append(value)
            shape.append(value)

        name = info_proto.name
        dtype = onnx.TensorProto.DataType.Name(info_proto.type.tensor_type.elem_type).lower()
        return name, shape, dtype, shape_name

    onnx_model = onnx.load(onnx_model)

    cons_input = set([node.name for node in onnx_model.graph.initializer])
    for node in onnx_model.graph.input:
        name, shape, dtype, shape_name = get_node_info(node)
        if name not in cons_input:
            print(name, shape, dtype, shape_name)
            if dtype == 'float':
                dtype = 'float32'
            input_data_ = np.full(shape, 127, dtype=dtype)
            input_data.append(input_data_)
            shape_dict[name] = input_data_.shape
    for i in range(len(onnx_model.graph.output)):
        output_idx.append(i)

    mod, params = relay.frontend.from_onnx(onnx_model,
                                           shape=shape_dict)
    return mod, params, input_data, output_idx, shape_dict

def run_onnx_graph(model, inputs):
    try:
        import onnx
    except ImportError:
        raise ImportError("The onnx package must be installed")
    import onnxruntime.backend

    onnx_model = onnx.load(model)
    rep = onnxruntime.backend.prepare(onnx_model, "CPU")
    if isinstance(inputs, list) and len(inputs) == 1:
        inp = inputs[0]
    else:
        inp = inputs
    output = rep.run(inp)
    return output

#######################################################################
# Prepare tvm/tinytvm build variants and verify
# --------------------------------

def build_model(opts):

    if opts.model.endswith('.tflite'):
        mod, params, input_data, output_idx, shape_dict = import_tflite_model(opts.model)
        if (opts.run) :
            fw_output = run_tflite_graph(tflite_model_buf, input_data)
    elif opts.model.endswith('.onnx'):
        mod, params, input_data, output_idx, shape_dict = import_onnx_model(opts.model)
        if (opts.run) :
            fw_output = run_onnx_graph(opts.model, input_data)
    else :
        raise ValueError('Unknown model type')


    save_fmt = 'model_kernel.o'
    if not opts.tvmkernel:
        cxxflags = opts.cxxflags + " -c"

    if opts.tvmkernel:
      #skip for tvm kernel
      mod = mod
    else:
      tinykernel_patterns = tvm.relay.op.contrib.register.get_pattern_table("tinykernel")
      tvm.relay.backend.compile_engine.get().clear()
      mod = get_partitoned_mod(mod, params, tinykernel_patterns)

    with relay.build_config(opt_level=3):
        graph, lib, params = relay.build(mod, opts.target, params=params)

        build_dir = os.path.abspath(opts.out_dir)
        if not os.path.isdir(build_dir):
            os.makedirs(build_dir)

        if opts.tvmkernel:
          lib.save(os.path.join(build_dir, save_fmt))
        else:
          lib = update_lib(lib, os.path.join(build_dir, save_fmt), cc.cross_compiler(opts.crosscompiler), cxxflags)
          params = {}
        with open(os.path.join(build_dir, 'graph.json'), 'w') as f_graph_json:
            f_graph_json.write(graph)
        with open(os.path.join(build_dir, 'params.bin'), 'wb') as f_params:
            f_params.write(relay.save_param_dict(params))

    if (opts.run) :
      ctx = tvm.context(opts.target, 0)
      from tvm.contrib import graph_runtime
      m = graph_runtime.create(graph, lib, ctx)

      # set inputs
      for i, e in enumerate(shape_dict):
          m.set_input(e, tvm.nd.array(input_data[i].astype(input_data[i].dtype)))
      m.set_input(**params)

      # execute
      m.run()

      # get outputs
      tvm_output = list()
      for i in range(len(output_idx)):
          tvm_output.append(m.get_output(output_idx[i]).asnumpy())

      fw_predictions = np.squeeze(fw_output)
      tvm_predictions = np.squeeze(tvm_output)
      print('fw_predictions:', fw_predictions)
      print('tvm_predictions:', tvm_predictions)

#######################################################################
if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-o', '--out-dir', default='./build')
    parser.add_argument('-m', '--model', default='')
    parser.add_argument('-t', '--target', default='llvm')
    parser.add_argument('-cc', '--crosscompiler', default='g++')
    parser.add_argument('-r', '--run', action='store_true')
    parser.add_argument('-k', '--tvmkernel', action='store_true', default=False)
    parser.add_argument('-cf', '--cxxflags', default='')
    opts = parser.parse_args()
    build_model(opts)
