/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file runtime_config.h
 *
 * @brief Declares macros for customizing different options for ai lite runtime.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef RUNTIME_RUNTIME_CONFIG_H_
#define RUNTIME_RUNTIME_CONFIG_H_

#include <stdint.h>
#if defined(ARDUINO)
#include "Arduino.h"
#endif

/*************runtime customizable flag controls, begin************/
#define RUNTIME_ADVANCE_STORAGE 1
#define RUNTIME_MINIMUM_RAM_RUN 1
#define RUNTIME_PARAMETER_READ 1
#ifndef FLATBUFFER
#define FLATBUFFER 1
#endif
/*************runtime customizable flag controls, end************/

/*************runtime predefined constant flags, begin************/
#define RUNTIME_MAX_ARGS 12
#define RUNTIME_VIRT_MEM_VALUE 1
#ifndef RUNTIME_VIRT_MEM_SIZE
#define RUNTIME_VIRT_MEM_SIZE 22
#endif

#ifndef RUNTIME_MAX_SEQ_LENGTH
#define RUNTIME_MAX_SEQ_LENGTH 200
#endif

#define RUNTIME_MEMORY_BUFFER_SIZE 300 * 1024

#define RUNTIME_PAGE_BYTES 256
#define RUNTIME_DEBUG_LEVEL 0

#ifndef RUNTIME_MAX_NDIM
#define RUNTIME_MAX_NDIM 4
#endif
#define RUNTIME_STRLEN_DLTYPE 12
#define RUNTIME_CONST_STRLEN_NAME 80
#define RUNTIME_FUNC_STRLEN_NAME 120
#define FLATBUFFERS_LOCALE_INDEPENDENT 1
/*************runtime predefined constant flags, end************/

namespace OHOS {
namespace AI {

/*! \brief type of array index. */
#if defined(ARDUINO) || defined(__LITEOS__)
typedef int32_t intcb_t;
typedef uint32_t uintcb_t;
typedef int32_t index_t;
typedef int16_t index_t_16;
typedef int32_t index_t_32;
#else
typedef int64_t intcb_t;
typedef uint64_t uintcb_t;
typedef int64_t index_t;
typedef int64_t index_t_16;
typedef int64_t index_t_32;
#endif

}  // namespace AI
}  // namespace OHOS
#endif  // RUNTIME_RUNTIME_CONFIG_H_
