/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file tiny_tvm_config.h
 *
 * @brief Declares model config details.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef TINY_TVM_CONFIG_H
#define TINY_TVM_CONFIG_H

namespace OHOS::AI::tinytvm {

class TinyTvmConfig {
 public:
  TinyTvmConfig(std::string m_modelName_, std::string m_modelPath_);
  ~TinyTvmConfig() {}

  std::string m_modelName;
  std::string m_modelPath;
};

}  // namespace OHOS::AI::tinytvm
#endif  // TINY_TVM_CONFIG_H