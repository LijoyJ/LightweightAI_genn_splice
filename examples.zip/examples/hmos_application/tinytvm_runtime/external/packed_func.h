/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE.tvm file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/* ------------------------------------------------
 * Changes  |   Date       |   Change Description
 * ------------------------------------------------
   Deleted  |   13-03-2021 |  Unwanted part removed.
 * ------------------------------------------------
 * Copyright (c) 2021 Huawei Technologies Co., Ltd.
 * Mail Id: <***@huawei.com>
 * ------------------------------------------------
 */

#ifndef RUNTIME_PACKED_FUNC_H_
#define RUNTIME_PACKED_FUNC_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "runtime_config.h"

namespace OHOS {
namespace AI {

#define TVM_DLL_EXPORT_TYPED_FUNC(ExportName, Function)                                  \
  extern "C" int ExportName(OHOS::AI::TVMValue* args, int* type_code, int num_args,      \
                            OHOS::AI::TVMValue* out_value, int* out_type_code,           \
                            void* resource_handle) {                                     \
    if (args != 0) {                                                                     \
      Function((DLTensor*)args[0].v_handle, (DLTensor*)args[1].v_handle, out_type_code); \
      return 0;                                                                          \
    }                                                                                    \
    return -1;                                                                           \
  }

/*!
 * \brief Union type of values
 *  being passed through API and function calls.
 */
// TODO:: union member further can be optimised
typedef union {
  void* v_handle;
  int64_t v_int64;
  double v_float64;
  const char* v_str;
  DLDataType v_type;
} TVMValue;

/*!
 * \brief C type of packed function.
 *
 * \param args The arguments
 * \param type_codes The type codes of the arguments
 * \param num_args Number of arguments.
 * \param ret The return value handle.
 * \param resource_handle The handle additional resouce handle from fron-end.
 * \return 0 if success, -1 if failure happens, set error via
 * TVMAPISetLastError. \sa TVMCFuncSetReturn
 */
typedef int (*PackedCFunc)(TVMValue* args, int* type_codes, int num_args, TVMValue* out_ret_value,
                           int* out_ret_tcode, void* resource_handle);

typedef struct TVMArgs {
  TVMValue values[RUNTIME_MAX_ARGS];
  uint32_t values_count;
} TVMArgs;

typedef struct PackedFunc {
  PackedCFunc fexec;
  TVMArgs args;
  uint32_t nbidx;
  uint32_t input_eids[RUNTIME_MAX_ARGS];
  uint32_t num_inputs;
  uint32_t output_eids[RUNTIME_MAX_ARGS];
  uint32_t num_outputs;
  void (*Call)(struct PackedFunc* pf);
  void (*SetArgs)(struct PackedFunc* pf, const struct TVMArgs* args, uint32_t* input_eids,
                  int num_inputs, uint32_t* output_eids, int num_outputs);
} PackedFunc;

typedef struct RegisterPackedFunc {
  char name[RUNTIME_FUNC_STRLEN_NAME];
  PackedCFunc fexec;
} RegisterPackedFunc;

/*!
 * \brief Environment for TVM parallel task.
 */
typedef struct {
  /*!
   * \brief Auxiliary used for synchronization
   */
  void* sync_handle;
  /*! \brief total amount of task */
  int32_t num_task;
} TVMParallelGroupEnv;

/*!
 * \brief The callback function to execute a parallel lambda
 * \param task_id the task id of the function.
 * \param penv The parallel environment backs the execution.
 * \param cdata The supporting closure data.
 */
typedef int (*FTVMParallelLambda)(int task_id, TVMParallelGroupEnv* penv, void* cdata);

static inline DLDataType String2DLDataType(const char* s) {
  DLDataType t;
  // handle None type
  if (strlen(s) == 0) {
    t.bits = 0;
    t.lanes = 0;
    t.code = 0;
    return t;
  }
  t.bits = 32;
  t.lanes = 1;
  const char* scan;
  if (!strncmp(s, "int", 3)) {
    t.code = kDLInt;
    scan = s + 3;
  } else if (!strncmp(s, "uint", 4)) {
    t.code = kDLUInt;
    scan = s + 4;
  } else if (!strncmp(s, "float", 5)) {
    t.code = kDLFloat;
    scan = s + 5;
  } else if (!strncmp(s, "handle", 6)) {
    t.code = 0;
    t.bits = 64;  // handle uses 64 bit by default.
    scan = s + 6;
  } else if (!strcmp(s, "bool")) {
    t.code = kDLUInt;
    t.bits = 1;
    t.lanes = 1;
    return t;
  } else {
    scan = s;
    fprintf(stderr, "unknown type %s\n", s);
  }
  char* xdelim;
  uint8_t bits = (uint8_t)(strtoul(scan, &xdelim, 10));
  if (bits != 0) t.bits = bits;
  char* endpt = xdelim;
  if (*xdelim == 'x') {
    t.lanes = (uint16_t)(strtoul(xdelim + 1, &endpt, 10));
  }
  if (!(endpt == s + strlen(s))) {
    fprintf(stderr, "unknown type %s\n", s);
  }
  return t;
}

static inline TVMArgs TVMArgs_Create(TVMValue* values, uint32_t values_count) {
  uint32_t idx;
  TVMArgs args;
  memset(&args, 0, sizeof(args));
  for (idx = 0; idx < values_count; idx++) {
    memcpy(args.values + idx, values + idx, sizeof(TVMValue));
  }
  args.values_count = values_count;
  return args;
}

static inline int TVMNoOperation(TVMValue* args, int* type_codes, int num_args,
                                 TVMValue* out_ret_value, int* out_ret_tcode,
                                 void* resource_handle) {
  return 0;
}

static inline void PackedFunc_Call(PackedFunc* pf) {
  pf->fexec(pf->args.values, 0, pf->args.values_count, 0, 0, 0);
}

static inline void PackedFunc_SetArgs(PackedFunc* pf, const TVMArgs* args, uint32_t* input_eids,
                                      int num_inputs, uint32_t* output_eids, int num_outputs) {
  memcpy(&(pf->args), args, sizeof(TVMArgs));
  for (int i = 0; i < num_inputs; i++) {
    pf->input_eids[i] = input_eids[i];
  }
  pf->num_inputs = num_inputs;
  for (int i = 0; i < num_outputs; i++) {
    pf->output_eids[i] = output_eids[i];
  }
  pf->num_outputs = num_outputs;
}

}  // namespace AI
}  // namespace OHOS
#endif  // RUNTIME_PACKED_FUNC_H_
