/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file InferFramework.h
 *
 * @brief Declares inference framework interface.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef DLLITE_INFER_FRAMEWORK_H
#define DLLITE_INFER_FRAMEWORK_H

#include "ModelConfig.h"

namespace OHOS::AI::dllite {

/**
 *
 * @brief Declares Interfaces to be supported by the inference framework.
 *
 *
 * @since 1.0
 * @version 1.0
 */
class InferFramework {
 public:
  /**
   * @brief Constructor, initializes the inference framework with the model.
   *
   */
  explicit InferFramework() {}

  /**
   * @brief destructor, frees all the resources used for inferencing.
   */
  ~InferFramework() {}

  /**
   * @brief  Apart from any initialization in the constructor if there are any
   *         additional setup required for inferencinf it can be prepared.
   */
  virtual ReturnCode Load() = 0;

  /**
   * @brief  Get Input tensors to which the input values needs to be set.
   */
  virtual ReturnCode GetInputBuffers(std::vector<IOTensor>& inputs) const = 0;

  /**
   * @brief  Infer the model for the set input
   */
  virtual ReturnCode Invoke() = 0;

  /**
   * @brief  Get Output tensors from which the inference output can be retrieved.
   */
  virtual ReturnCode GetOutputBuffers(std::vector<IOTensor>& outputs) const = 0;

  /**
   * @brief  Free the resources setup for inferencing the model
   */
  virtual ReturnCode Unload() = 0;

  /**
   * @brief  Create the Input tensor buffer which will be used for inferencing
   */
  virtual ReturnCode CreateInputBuffers(std::vector<IOTensor>& inputs) = 0;

  /**
   * @brief  Create the Output tensor buffer which will be used for inferencing
   */
  virtual ReturnCode CreateOutputBuffers(std::vector<IOTensor>& outputs) = 0;

  /**
   * @brief  Destroy the input / output tensor buffers which were created.
   */
  virtual ReturnCode DestroyIOBuffers(std::vector<IOTensor>& tensors) = 0;
};

}  // namespace OHOS::AI::dllite
#endif  // DLLITE_INFER_FRAMEWORK_H