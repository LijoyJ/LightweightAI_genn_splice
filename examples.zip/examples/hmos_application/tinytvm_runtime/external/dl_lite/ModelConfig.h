/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file ModelConfig.h
 *
 * @brief Declares model config details.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef DLLITE_MODEL_CONFIG_H
#define DLLITE_MODEL_CONFIG_H

#include <map>
#include <utility>
#include <vector>

#include "TypeDefine.h"

namespace OHOS::AI::dllite {

const INT32 UINT8_ENUM = 0;
const INT32 INT8_ENUM = 1;
const INT32 INT16_ENUM = 2;
const INT32 UINT32_ENUM = 3;
const INT32 INT32_ENUM = 4;
const INT32 FP16_ENUM = 5;
const INT32 FP32_ENUM = 6;
const INT32 FLOAT_ENUM = 7;
const INT32 FLOAT16_ENUM = 8;
const INT32 INT64_ENUM = 9;
const INT32 UINT16_ENUM = 10;

enum class TensorType {
  FLOAT = FLOAT_ENUM,
  FLOAT_16 = FLOAT16_ENUM,
  INT8 = INT8_ENUM,
  INT32 = INT32_ENUM,
  UINT8 = UINT8_ENUM,
  INT16 = INT16_ENUM,
  UINT32 = UINT32_ENUM,
  INT64 = INT64_ENUM,
  UINT16 = UINT16_ENUM,
};

const INT32 NONE_ENUM = -1;
const INT32 NCHW_ENUM = 0;
const INT32 NHWC_ENUM = 1;
const INT32 NCHWC8_ENUM = 2;
const INT32 ROW_MAJOR_ENUM = 3;
const INT32 LSTM_MTK_ENUM = 4;
const INT32 HWKC_ENUM = 5;
const INT32 HWCK_ENUM = 6;
const INT32 KCHW_ENUM = 7;
const INT32 CKHW_ENUM = 8;
const INT32 KHWC_ENUM = 9;
const INT32 CHWK_ENUM = 10;
const INT32 HC4HW4_ENUM = 11;

enum class TensorLayout {
  NONE = NONE_ENUM,
  NCHW = NCHW_ENUM,
  NHWC = NHWC_ENUM,
  HWKC = HWKC_ENUM,
  HWCK = HWCK_ENUM,
  KCHW = KCHW_ENUM,
  CKHW = CKHW_ENUM,
  NC4HW4 = HC4HW4_ENUM,
  NCHWC8 = NCHWC8_ENUM,
  ROW_MAJOR = ROW_MAJOR_ENUM,
  LSTM_MTK = LSTM_MTK_ENUM,
};

struct QuantArgs {
  double in_scale;
  double out_scale;
  int32_t in_zero_point;
  int32_t out_zero_point;
};

struct IOTensor {
  STRING name;
  TensorType type;
  TensorLayout layout;
  std::vector<size_t> shape;
  std::pair<void*, size_t> buffer;
  QuantArgs quantParam;
};

const INT32 INFER_ENUM = -1;
const INT32 TINY_TVM_ENUM = 2;

enum class InferFrameworkType {
  INFER = INFER_ENUM,
  TINY_TVM = TINY_TVM_ENUM,
};

class ModelConfig {
 public:
  ModelConfig() {}
  ~ModelConfig() {}

  std::string m_modelName;
  std::string m_modelPath;
  InferFrameworkType m_inferFrameworkType;
};

}  // namespace OHOS::AI::dllite
#endif  // DLLITE_MODEL_CONFIG_H
