/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file TypeDefine.h
 *
 * @brief Declares data types.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef DLLITE_TYPE_DEFINE_H
#define DLLITE_TYPE_DEFINE_H

#include <string>

namespace OHOS::AI::dllite {

using VOID = void;
using BOOL = bool;
using INT8 = char;
using UINT8 = unsigned char;
using INT32 = int;
using UINT32 = unsigned int;
using iNT64 = long long;
using UINT64 = unsigned long long;

#if __ARM_FP16_ARGS
using FP16 = __fp16;
#endif

using FP32 = float;
using FP64 = double;
using STRING = std::string;

enum class ReturnCode {
  SUCCESS,
  UNKNOWN,
};

}  // namespace OHOS::AI::dllite
#endif  // DLLITE_TYPE_DEFINE_H
