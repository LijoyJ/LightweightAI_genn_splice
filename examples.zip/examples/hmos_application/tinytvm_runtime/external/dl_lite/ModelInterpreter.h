/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file ModelInterpreter.h
 *
 * @brief Declares model interpreter interface.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef DL_LITE_MODEL_INTERPRETER_H
#define DL_LITE_MODEL_INTERPRETER_H

#include <memory>

#include "ModelConfig.h"

namespace OHOS::AI::dllite {

/**
 * IOFlag
 */
enum class IOFlag {
  INPUT,
  OUTPUT,
};

#if 0
/**
 * Model Interpreter
 */
class ModelInterpreter{
public:
    /**
     * Constructor
     */
    explicit ModelInterpreter(const ModelConfig &ModelConfig){}

    /**
     * Destructor
     */
    ~ModelInterpreter(){}

    ReturnCode Load();
    ReturnCode Invoke();
    ReturnCode Unload();

    /**
     * @brief  Create the Input / Output tensor buffer which will be used for inferencing
     */
    ReturnCode CreateTensors(std::vector<IOTensor> &Tensors, IOFlag flag);

    /**
     * @brief  Destroy the input / output tensor buffers which were created.
     */
    ReturnCode DestroyTensors(std::vector<IOTensor> &tensors);

    /**
     * @brief  Get Input / Output tensors .
     */
    ReturnCode GetTensors(std::vector<IOTensor> &tensors, IOFlag flag) const;

};

#endif

}  // namespace OHOS::AI::dllite

#endif