/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file runtime.h
 *
 * @brief Declares functions in the ai lite runtime class to run models.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef RUNTIME_RUNTIME_H_
#define RUNTIME_RUNTIME_H_

#include <string>
#include <vector>

#include "external/dlpack.h"
// TODO: runtime_config should be a config file not .h
#include "runtime_config.h"

namespace OHOS {
namespace AI {

/**
 *
 * @brief Kernel information which will be used for run.
 *
 *
 * @since 1.0
 * @version 1.0
 */
class OperatorFunction {
 public:
  /*! \brief The function name of the kernel. */
  std::string func_name;

  /*! \brief The pointer of kernel function. */
  void* func_ptr;
};

/**
 *
 * @brief Declares Interfaces to be supported by the memory manager.
 *
 *
 * @since 1.0
 * @version 1.0
 */
class MemoryPoolManager {
 public:
  virtual ~MemoryPoolManager(){};

  /**
   * @brief  allocates the memory requested by the infer framework
   * @param  size memory size required
   * @return memory allocated for the request
   */
  virtual void* AllocateMemoryPool(size_t size) = 0;

  /**
   * @brief frees the memory allocated by the pool manager
   * @param addr memory allocated by the pool manager
   *
   */
  virtual void FreeMemoryPool(void* addr) = 0;
};

/**
 *
 * @brief Declares functions in the ai lite runtime class to run models.
 *
 *
 * @since 1.0
 * @version 1.0
 */
class Runtime {
 public:
  /**
   * @brief Constructor, initializes the runtime and allocate necessary memory.
   *
   * @param graph_byte Pointer to the graph data of the model.
   * @param param_byte Pointer to the param data of the model.
   * @param operator_funcs The list of kernel functions used for this model.
   *
   */
  Runtime(const char* graph_byte, const char* params_byte,
          std::vector<OperatorFunction>* operator_funcs, MemoryPoolManager* mem_pool_mgr = NULL);

  /**
   * @brief Function to set the input tensor to the model.
   *
   * @param name The name of the input tensor for which input need to set.
   * @param tensor The input tensor value to be set for execution of model.
   *
   */
  void SetInput(const char* name, DLTensor* tensor);

  /**
   * @brief Function to execute the model.
   *
   */
  void Run();

  /**
   * @brief Return tensor for given output index after execution.
   *
   * @param index The output index.
   * @param tensor The output pointer where the data is copied.
   *
   */
  void GetOutput(int32_t index, DLTensor* tensor);

  /**
   * @brief A destructor used to delete the runtime instance..
   *
   */
  ~Runtime();
};

}  // namespace AI
}  // namespace OHOS
#endif  // RUNTIME_RUNTIME_H_
