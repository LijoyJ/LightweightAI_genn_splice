/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * @file runtime_config.h
 *
 * @brief Declares model config details.
 *
 *
 * @since 1.0
 * @version 1.0
 */

#ifndef TINY_TVM_H
#define TINY_TVM_H

#include "external/dl_lite/InferFramework.h"
#include "external/dl_lite/ModelConfig.h"
#include "external/dl_lite/ModelInterpreter.h"
#include "runtime.h"
#include "tiny_tvm_config.h"

namespace OHOS::AI::tinytvm {

// TODO unify to move to runtime and delete runtime_ex
/**
 *
 * @brief Declares functions in the ai lite runtime class to run models for infer framework.
 *
 * @since 1.0
 * @version 1.0
 */
class TinyTvmRuntime : public Runtime {
 public:
  /**
   * @brief Constructor, initializes the runtime and allocate necessary memory.
   *
   * @param graph_byte Pointer to the graph data of the model.
   * @param weights_byte Pointer to the weight data of the model.
   * @param operator_funcs The list of kernel functions used for this model.
   *
   */
  TinyTvmRuntime(const char* graph_byte, const char* weights_byte,
                 std::vector<OperatorFunction>* operator_funcs, MemoryPoolManager* mem_pool_mgr);

  /**
   * @brief Get all the model input tensors which used by the application to set the inference input
   *
   * @param vector in which the input tensors are set
   */
  OHOS::AI::dllite::ReturnCode GetInputTensors(
      std::vector<OHOS::AI::dllite::IOTensor>& inputs) const;

  /**
   * @brief Get all the model output tensors which used by the application to process the inference output
   *
   * @param vector in which the output tensors are set
   */
  OHOS::AI::dllite::ReturnCode GetOutputTensors(
      std::vector<OHOS::AI::dllite::IOTensor>& outputs) const;

  /**
   * @brief A destructor used to delete the runtime instance.
   *
   */
  ~TinyTvmRuntime();
};

/**
 *
 * @brief Declares Interface of Tiny TVM.
 *
 *
 * @since 1.0
 * @version 1.0
 */
class TinyTvm {
 public:
  /**
   * @brief Constructor, initializes the inference framework with the model.
   *
   * @param config model details which will be used for inferencing.
   * @param mem_pool_mgr memory manager used by the inference framework,
   *                   for Tiny TVM, the memory buffer will be alloated
   *                   once and managed internally for inferencing. For
   *                   TVM's memory requirement, it will be invoked for
   *                   each memory requirement. If this paramere is not
   *                   passed, malloc and free will be used for the memory
   *                   requirement.
   */
  explicit TinyTvm(const TinyTvmConfig& config, MemoryPoolManager* mem_pool_mgr = NULL);

  /**
   * @brief destructor, frees all the resources used for inferencing.
   */
  ~TinyTvm();

  /**
   * @brief  The model is prepared for inferencing in the constructor,
   *         there is no additional initialization done.
   */
  OHOS::AI::dllite::ReturnCode Load();

  /**
   * @brief  Infer the model for the set input
   */
  OHOS::AI::dllite::ReturnCode Invoke();

  /**
   * @brief  The model and the tensors will be freed in the destructor,
   *         no resources are freed here
   *
   */
  OHOS::AI::dllite::ReturnCode Unload();

  /**
   * @brief  Get the Inout / Output tensors to set the input / output of inference.
   */
  OHOS::AI::dllite::ReturnCode GetTensors(std::vector<OHOS::AI::dllite::IOTensor>& tensors,
                                          OHOS::AI::dllite::IOFlag flag) const;

  /**
   * @brief  This interface is not supported and should not be used
   */
  OHOS::AI::dllite::ReturnCode CreateTensors(std::vector<OHOS::AI::dllite::IOTensor>& outputs,
                                             OHOS::AI::dllite::IOFlag flag);

  /**
   * @brief  This interface is not supported and should not be used
   */
  OHOS::AI::dllite::ReturnCode DestroyTensors(std::vector<OHOS::AI::dllite::IOTensor>& tensors);

 private:
  std::string modelPath_;
  char* json_data_;
  char* weights_data_;
  std::vector<OHOS::AI::OperatorFunction> operatorFuncs_;
  TinyTvmRuntime* tinyTvmRuntime_;
  void* lib;

  /**
   * @brief  Get Input tensor buffers to which the input values needs to be set.
   */
  OHOS::AI::dllite::ReturnCode GetInputTensors(
      std::vector<OHOS::AI::dllite::IOTensor>& inputs) const;

  /**
   * @brief  Get Output tensor buffer from which the inference output can be retrieved.
   */
  OHOS::AI::dllite::ReturnCode GetOutputTensors(
      std::vector<OHOS::AI::dllite::IOTensor>& outputs) const;
};

}  // namespace OHOS::AI::tinytvm
#endif  // TINY_TVM_H
