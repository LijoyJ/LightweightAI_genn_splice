/*
 * Copyright (c) 2020 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <cstdint>
#include <ctime>
#include <limits>

#include "person_not_present_image_data.h"
#include "person_present_image_data.h"
#include "runtime.h"
static constexpr int kPersonPresentIndex = 1;
static constexpr int kPersonNotPresentIndex = 2;

#include "tiny_tvm.h"
#include "tiny_tvm_config.h"
#include "tiny_tvm_wrapper.h"

uint32_t GetCurrentTime() {
  struct timespec time;
  clock_gettime(CLOCK_MONOTONIC, &time);
  return time.tv_sec * 1000 * 1000 + time.tv_nsec / 1000;  // us
}

class MemoryPoolManagerImpl : public OHOS::AI::MemoryPoolManager {
 public:
  void* AllocateMemoryPool(const size_t size) { return malloc(size); }

  void FreeMemoryPool(void* addr) { free(addr); }
};

int main(int argc, char* argv[]) {
  int itr_cnt = 100;

  if (argc < 2) {
    printf("missing required parameters");
    return -1;
  }

  if (argc == 3) {
    itr_cnt = atoi(argv[2]);
  }

  printf("Sample app running on mcu using AI::Runtime\n");

  uint32_t t0, t1, t2, t3, t4, t5;
  t0 = GetCurrentTime();
  OHOS::AI::dllite::ModelConfig config;
  config.m_modelPath = argv[1];
  printf("Model used for inference %s\n", argv[1]);

  OHOS::AI::MemoryPoolManager* memoryPoolManager = new MemoryPoolManagerImpl();

  OHOS::AI::tinytvm::TinyTvm* runtime = new OHOS::AI::tinytvm::TinyTvm(
      OHOS::AI::tinytvm::TinyTvmConfig(config.m_modelName, config.m_modelPath), memoryPoolManager);

  t1 = GetCurrentTime();

  printf("Running for person present data test\n");

  std::vector<OHOS::AI::dllite::IOTensor> inputs;
  uint8_t* input_storage = NULL;
  uint8_t* output_storage = NULL;
  std::vector<OHOS::AI::dllite::IOTensor> outputs;

  runtime->GetTensors(inputs, OHOS::AI::dllite::IOFlag::INPUT);
  runtime->GetTensors(outputs, OHOS::AI::dllite::IOFlag::OUTPUT);

  for (auto input = inputs.begin(); input != inputs.end(); ++input) {
    input_storage = (uint8_t*)input->buffer.first;
    for (int i = 0; i < g_person_present_data_size; i++) {
      input_storage[i] = g_person_present_data[i];
    }
  }

  t2 = GetCurrentTime();

  runtime->Invoke();

  t3 = GetCurrentTime();

  for (auto output = outputs.begin(); output != outputs.end(); ++output) {
    output_storage = (uint8_t*)output->buffer.first;
  }

  t4 = GetCurrentTime();

  float max_iter = -std::numeric_limits<float>::max();
  int32_t max_index = -1;
  for (int i = 0; i < 3; ++i) {
    printf("output_storage[%d]:%d\n", i, output_storage[i]);
    if (output_storage[i] > max_iter) {
      max_iter = output_storage[i];
      max_index = i;
    }
  }

  t5 = GetCurrentTime();

  printf(
      "The maximum position in output vector is: %d, with"
      " max-value %f.\n",
      max_index, max_iter);
  printf(
      "timing: %f us (create), %f us (set_input), %f us (run), "
      "%f us (get_output), %f us (destroy)\n",
      (t1 - t0) / 1.f, (t2 - t1) / 1.f, (t3 - t2) / 1.f, (t4 - t3) / 1.f, (t5 - t4) / 1.f);

  printf("person present data.  person present score: %d, person not present score: %d\n", output_storage[kPersonPresentIndex],
         output_storage[kPersonNotPresentIndex]);

  printf("Running for person not present data test\n");

  for (auto input = inputs.begin(); input != inputs.end(); ++input) {
    input_storage = (uint8_t*)input->buffer.first;
    for (int i = 0; i < g_person_not_present_data_size; i++) {
      input_storage[i] = g_person_not_present_data[i];
    }
  }

  runtime->Invoke();

  max_iter = -std::numeric_limits<float>::max();
  max_index = -1;
  for (int i = 0; i < 3; ++i) {
    printf("output_storage[%d]:%d\n", i, output_storage[i]);
    if (output_storage[i] > max_iter) {
      max_iter = output_storage[i];
      max_index = i;
    }
  }
  printf(
      "The maximum position in output vector is: %d, with"
      " max-value %f.\n",
      max_index, max_iter);
  printf("person not present data.  person present score: %d, person not present score: %d\n", output_storage[kPersonPresentIndex],
         output_storage[kPersonNotPresentIndex]);

  if (itr_cnt > 0) {
    t0 = GetCurrentTime();
    for (int i = 0; i < itr_cnt; ++i) {
      for (auto input = inputs.begin(); input != inputs.end(); ++input) {
        input_storage = (uint8_t*)input->buffer.first;
        for (int i = 0; i < g_person_not_present_data_size; i++) {
          input_storage[i] = g_person_not_present_data[i];
        }
      }

      runtime->Invoke();

      max_iter = -std::numeric_limits<float>::max();
      max_index = -1;
      for (int j = 0; j < 3; ++j) {
        if (output_storage[j] > max_iter) {
          max_iter = output_storage[j];
          max_index = j;
        }
      }
      // printf("%d iteration op max_val:%f max_val_position:%d",
      //    i, max_iter, max_index);
    }
    t1 = GetCurrentTime();

    printf("inference for %d run consume : %f us\n", itr_cnt, (t1 - t0) / 1.f / itr_cnt);
  }

  delete runtime;
  delete memoryPoolManager;
  return 0;
}
